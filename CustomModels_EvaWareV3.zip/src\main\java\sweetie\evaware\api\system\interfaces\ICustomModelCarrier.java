package sweetie.evaware.api.system.interfaces;

public interface ICustomModelCarrier {
    String evaware$getCustomModel();
    void evaware$setCustomModel(String model);
}
