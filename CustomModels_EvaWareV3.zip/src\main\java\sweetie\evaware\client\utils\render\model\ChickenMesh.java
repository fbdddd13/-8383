package sweetie.evaware.client.utils.render.model;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

public final class ChickenMesh {

    private static final String[] PARTS = {"body", "head", "right_arm", "left_arm", "right_leg", "left_leg"};
    private static final Identifier[] TEXTURES = {
            Identifier.of("evaware", "models/chicken/rudy_sc_1.png"),
            Identifier.of("evaware", "models/chicken/bruce_col.png")
    };
    /** Rotation pivots of each part, measured from the converted mesh, in the model's own space. */
    private static final float[][] PIVOTS = {
            {0, 0, 0}, {0, 0.55f, 0}, {-0.52f, 0.55f, 0}, {0.52f, 0.55f, 0},
            {-0.18f, 1.12f, 0}, {0.18f, 1.12f, 0}
    };

    private static float[][][] vertices;

    private ChickenMesh() {
    }

    private static float[][][] geometry() {
        if (vertices == null) {
            float[][][] all = new float[PARTS.length][TEXTURES.length][];
            for (int part = 0; part < PARTS.length; part++) {
                for (int material = 0; material < TEXTURES.length; material++) {
                    all[part][material] = load(PARTS[part], material);
                }
            }
            vertices = all;
        }
        return vertices;
    }

    private static float[] load(String part, int material) {
        String path = "/assets/evaware/models/chicken/mesh_" + part + "_" + material + ".bin";
        try (InputStream raw = ChickenMesh.class.getResourceAsStream(path)) {
            if (raw == null) {
                return new float[0];
            }
            try (DataInputStream in = new DataInputStream(raw)) {
                int count = in.readInt();
                if (count < 0 || count > 1_000_000 || count % 3 != 0) {
                    throw new IOException("Invalid vertex count");
                }
                float[] data = new float[count * 8];
                for (int i = 0; i < data.length; i++) {
                    data[i] = in.readFloat();
                }
                return data;
            }
        } catch (IOException | RuntimeException exception) {
            System.err.println("EvaWare: failed to load " + path + ": " + exception);
            return new float[0];
        }
    }

    public static void render(PlayerEntityRenderState state, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, int overlay) {
        float[][][] data = geometry();
        float stride = Math.min(state.limbAmplitudeMultiplier, 1.0f);
        float swing = (float) Math.cos(state.limbFrequency * 0.6662f) * 1.2f * stride;
        float rightArm = -swing;
        float leftArm = swing;
        if (state.handSwingProgress > 0) {
            float hit = (float) Math.sin(Math.sqrt(state.handSwingProgress) * Math.PI) * 1.3f;
            if (state.preferredArm == Arm.RIGHT) {
                rightArm -= hit;
            } else {
                leftArm -= hit;
            }
        }
        if (state.isUsingItem) {
            boolean mainHand = state.activeHand == Hand.MAIN_HAND;
            boolean rightHanded = state.mainArm == Arm.RIGHT;
            if (mainHand == rightHanded) {
                rightArm = -0.8f;
            } else {
                leftArm = -0.8f;
            }
        }
        float[] angles = {0, 0, rightArm, leftArm, swing, -swing};
        for (int part = 0; part < PARTS.length; part++) {
            matrices.push();
            rotatePart(matrices, part, angles[part]);
            for (int material = 0; material < TEXTURES.length; material++) {
                float[] triangles = data[part][material];
                if (triangles.length == 0) {
                    continue;
                }
                VertexConsumer consumer = vertexConsumers.getBuffer(RenderLayer.getEntityCutout(TEXTURES[material]));
                MatrixStack.Entry entry = matrices.peek();
                for (int triangle = 0; triangle < triangles.length; triangle += 24) {
                    vertex(entry, consumer, triangles, triangle, light, overlay);
                    vertex(entry, consumer, triangles, triangle + 8, light, overlay);
                    vertex(entry, consumer, triangles, triangle + 16, light, overlay);
                    vertex(entry, consumer, triangles, triangle + 16, light, overlay);
                }
            }
            matrices.pop();
        }
        renderItem(state.rightHandItemState, matrices, vertexConsumers, light, 2, rightArm);
        renderItem(state.leftHandItemState, matrices, vertexConsumers, light, 3, leftArm);
    }

    public static void renderArm(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, boolean right) {
        float[][][] data = geometry();
        int part = right ? 2 : 3;
        float[] pivot = PIVOTS[part];
        matrices.push();
        matrices.translate(-pivot[0], -pivot[1], -pivot[2]);
        for (int material = 0; material < TEXTURES.length; material++) {
            float[] triangles = data[part][material];
            if (triangles.length == 0) {
                continue;
            }
            VertexConsumer consumer = vertexConsumers.getBuffer(RenderLayer.getEntityCutout(TEXTURES[material]));
            MatrixStack.Entry entry = matrices.peek();
            for (int triangle = 0; triangle < triangles.length; triangle += 24) {
                vertex(entry, consumer, triangles, triangle, light, OverlayTexture.DEFAULT_UV);
                vertex(entry, consumer, triangles, triangle + 8, light, OverlayTexture.DEFAULT_UV);
                vertex(entry, consumer, triangles, triangle + 16, light, OverlayTexture.DEFAULT_UV);
                vertex(entry, consumer, triangles, triangle + 16, light, OverlayTexture.DEFAULT_UV);
            }
        }
        matrices.pop();
    }

    private static void rotatePart(MatrixStack matrices, int part, float angle) {
        if (angle == 0) {
            return;
        }
        float[] pivot = PIVOTS[part];
        matrices.translate(pivot[0], pivot[1], pivot[2]);
        matrices.multiply(RotationAxis.POSITIVE_X.rotation(angle));
        matrices.translate(-pivot[0], -pivot[1], -pivot[2]);
    }

    private static void renderItem(ItemRenderState item, MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                   int light, int arm, float angle) {
        if (item.isEmpty()) {
            return;
        }
        matrices.push();
        rotatePart(matrices, arm, angle);
        matrices.translate(arm == 2 ? -0.57f : 0.57f, 0.92f, -0.02f);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180));
        matrices.translate(arm == 2 ? 0.0625f : -0.0625f, 0.125f, 0);
        item.render(matrices, vertexConsumers, light, OverlayTexture.DEFAULT_UV);
        matrices.pop();
    }

    private static void vertex(MatrixStack.Entry entry, VertexConsumer consumer, float[] data, int i, int light, int overlay) {
        consumer.vertex(entry, data[i], data[i + 1], data[i + 2])
                .color(-1)
                .texture(data[i + 3], data[i + 4])
                .overlay(overlay)
                .light(light)
                .normal(entry, data[i + 5], data[i + 6], data[i + 7]);
    }
}
