package sweetie.evaware.client.features.modules.render;

import lombok.Getter;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import sweetie.evaware.api.module.Category;
import sweetie.evaware.api.module.Module;
import sweetie.evaware.api.module.ModuleRegister;
import sweetie.evaware.api.module.setting.BooleanSetting;
import sweetie.evaware.api.module.setting.ModeSetting;
import sweetie.evaware.api.module.setting.SliderSetting;
import sweetie.evaware.api.system.configs.FriendManager;

@Getter
@ModuleRegister(name = "Custom Models", category = Category.RENDER)
public class CustomModelsModule extends Module {
    @Getter private static final CustomModelsModule instance = new CustomModelsModule();

    public static final String CHICKEN = "Chicken";
    public static final String VERITY = "Verity";
    public static final String RABBIT = "Rabbit";

    private final ModeSetting model = new ModeSetting("Модель").values(CHICKEN, VERITY, RABBIT).value(CHICKEN);
    private final BooleanSetting self = new BooleanSetting("На себя").value(true);
    private final BooleanSetting friends = new BooleanSetting("На друзей").value(false);
    private final BooleanSetting others = new BooleanSetting("На всех игроков").value(false);
    private final BooleanSetting hand = new BooleanSetting("Рука от модели").value(true)
            .setVisible(() -> model.is(CHICKEN) && self.getValue());
    private final SliderSetting size = new SliderSetting("Размер").value(1.0f).range(0.3f, 3.0f).step(0.05f)
            .setVisible(() -> model.is(VERITY));
    private final ModeSetting face = new ModeSetting("Лицо")
            .values("Обычное", "Говорит", "Странное", "Странное говорит", "Странное кричит", "Плохое", "Очень плохое")
            .value("Обычное")
            .setVisible(() -> model.is(VERITY));

    public CustomModelsModule() {
        addSettings(model, self, friends, others, hand, size, face);
    }

    public boolean handFromModel() {
        return isEnabled() && model.is(CHICKEN) && self.getValue() && hand.getValue();
    }

    public String modelFor(PlayerEntity player) {
        if (!isEnabled() || player == null || mc.player == null) {
            return null;
        }
        boolean wanted;
        if (player.getUuid().equals(mc.player.getUuid())) {
            wanted = self.getValue();
        } else if (FriendManager.getInstance().contains(player.getName().getString())) {
            wanted = friends.getValue();
        } else {
            wanted = others.getValue();
        }
        return wanted ? model.getValue() : null;
    }

    public float getSizeValue() {
        return size.getValue();
    }

    public Identifier verityTexture() {
        String file = switch (face.getValue()) {
            case "Говорит" -> "veritytalk";
            case "Странное" -> "veritydisturbing";
            case "Странное говорит" -> "veritydisturbingtalk";
            case "Странное кричит" -> "veritydisturbingyell";
            case "Плохое" -> "veritybad";
            case "Очень плохое" -> "verityverybad";
            default -> "verity";
        };
        return Identifier.of("evaware", "models/verity/" + file + ".png");
    }

    @Override
    public void onEvent() {
    }
}
