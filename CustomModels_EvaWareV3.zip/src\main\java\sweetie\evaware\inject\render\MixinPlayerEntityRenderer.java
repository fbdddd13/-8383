package sweetie.evaware.inject.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.scoreboard.*;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sweetie.evaware.api.system.interfaces.ICustomModelCarrier;
import sweetie.evaware.client.features.modules.other.HealthResolverModule;
import sweetie.evaware.client.features.modules.render.CustomModelsModule;
import sweetie.evaware.client.utils.render.model.ChickenMesh;

@Mixin(PlayerEntityRenderer.class)
public abstract class MixinPlayerEntityRenderer extends LivingEntityRenderer<AbstractClientPlayerEntity, PlayerEntityRenderState, PlayerEntityModel> {
    public MixinPlayerEntityRenderer(EntityRendererFactory.Context ctx, PlayerEntityModel model, float shadowRadius) {
        super(ctx, model, shadowRadius);
    }

    @Inject(method = "updateRenderState(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V", at = @At("HEAD"))
    private void rwHealthFix(AbstractClientPlayerEntity abstractClientPlayerEntity, PlayerEntityRenderState playerEntityRenderState, float f, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (client == null || client.player == null || client.world == null) return;

        if (!HealthResolverModule.getInstance().isRW()) return;


        Scoreboard scoreboard = abstractClientPlayerEntity.getScoreboard();
        ScoreboardObjective scoreboardObjective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.BELOW_NAME);

        if (scoreboardObjective != null) {
            for (PlayerEntity player : client.world.getPlayers()) {
                if (player == null || player.equals(client.player)) continue;

                try {
                    ScoreAccess score = scoreboard.getOrCreateScore(player, scoreboardObjective);
                    String scoreText = (score == null ? 20 : score.getScore()) + " " + scoreboardObjective.getDisplayName().getString();
                    String scoreNumber = scoreText.replaceAll("[^0-9]", "");
                    int hp = Integer.parseInt(scoreNumber);

                    if (hp >= 0 && hp <= player.getMaxHealth()) {
                        player.setHealth((float) hp);
                    }
                } catch (Exception ignored) {}
            }
        }
    }

    @Inject(method = "updateRenderState(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V", at = @At("TAIL"))
    private void captureCustomModel(AbstractClientPlayerEntity player, PlayerEntityRenderState state, float f, CallbackInfo ci) {
        CustomModelsModule models = CustomModelsModule.getInstance();
        if (state instanceof ICustomModelCarrier carrier) {
            carrier.evaware$setCustomModel(models == null ? null : models.modelFor(player));
        }
    }

    @Inject(method = "shouldRenderFeatures(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)Z", at = @At("HEAD"), cancellable = true)
    private void hideFeaturesOnCustomModel(PlayerEntityRenderState state, CallbackInfoReturnable<Boolean> cir) {
        if (state instanceof ICustomModelCarrier carrier && carrier.evaware$getCustomModel() != null) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "renderRightArm", at = @At("HEAD"), cancellable = true)
    private void customModelsRightArm(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, Identifier playerSkin, boolean sleeve, CallbackInfo ci) {
        CustomModelsModule models = CustomModelsModule.getInstance();
        if (models != null && models.handFromModel()) {
            ChickenMesh.renderArm(matrices, vertexConsumers, light, true);
            ci.cancel();
        }
    }

    @Inject(method = "renderLeftArm", at = @At("HEAD"), cancellable = true)
    private void customModelsLeftArm(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, Identifier playerSkin, boolean sleeve, CallbackInfo ci) {
        CustomModelsModule models = CustomModelsModule.getInstance();
        if (models != null && models.handFromModel()) {
            ChickenMesh.renderArm(matrices, vertexConsumers, light, false);
            ci.cancel();
        }
    }
}
