package sweetie.evaware.client.utils.render.model;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

public final class RabbitModel {

    private static final Identifier TEXTURE = Identifier.of("evaware", "models/rabbit.png");
    private static final float ARM_TILT = 0.0873f;

    private static final Map<Integer, RabbitModel> MODELS = new HashMap<>();

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;

    private RabbitModel() {
        ModelData mesh = new ModelData();
        ModelPartData data = mesh.getRoot();
        ModelPartData rabbit = data.addChild("rabbit",
                box(28, 45, -5.0f, -13.0f, -5.0f, 10.0f, 11.0f, 8.0f),
                ModelTransform.pivot(0.0f, 24.0f, 0.0f));
        rabbit.addChild("right_leg", box(0, 32, -2.0f, 0.0f, -2.0f, 4.0f, 2.0f, 4.0f),
                ModelTransform.pivot(-3.0f, -2.0f, -1.0f));
        rabbit.addChild("left_leg", box(0, 32, -2.0f, 0.0f, -2.0f, 4.0f, 2.0f, 4.0f),
                ModelTransform.pivot(3.0f, -2.0f, -1.0f));
        rabbit.addChild("left_arm", box(24, 16, 0.0f, 0.0f, -2.0f, 2.0f, 8.0f, 4.0f),
                ModelTransform.of(5.0f, -13.0f, -1.0f, 0.0f, 0.0f, -ARM_TILT));
        rabbit.addChild("right_arm", box(24, 16, -2.0f, 0.0f, -2.0f, 2.0f, 8.0f, 4.0f),
                ModelTransform.of(-5.0f, -13.0f, -1.0f, 0.0f, 0.0f, ARM_TILT));
        rabbit.addChild("head", ModelPartBuilder.create()
                        .uv(0, 0).cuboid(-3.0f, 0.0f, -4.0f, 6.0f, 1.0f, 6.0f)
                        .uv(0, 45).cuboid(-4.0f, -11.0f, -4.0f, 8.0f, 11.0f, 8.0f)
                        .uv(56, 0).cuboid(-5.0f, -9.0f, -5.0f, 2.0f, 3.0f, 2.0f)
                        .uv(56, 0).cuboid(3.0f, -9.0f, -5.0f, 2.0f, 3.0f, 2.0f)
                        .uv(46, 0).cuboid(1.0f, -20.0f, 0.0f, 3.0f, 9.0f, 1.0f)
                        .uv(46, 0).cuboid(-4.0f, -20.0f, 0.0f, 3.0f, 9.0f, 1.0f),
                ModelTransform.pivot(0.0f, -14.0f, -1.0f));

        this.root = TexturedModelData.of(mesh, 64, 64).createModel();
        this.body = this.root.getChild("rabbit");
        this.head = this.body.getChild("head");
        this.leftArm = this.body.getChild("left_arm");
        this.rightArm = this.body.getChild("right_arm");
        this.leftLeg = this.body.getChild("left_leg");
        this.rightLeg = this.body.getChild("right_leg");
    }

    public static RabbitModel of(int entityId) {
        if (MODELS.size() > 128) {
            MODELS.clear();
        }
        return MODELS.computeIfAbsent(entityId, ignored -> new RabbitModel());
    }

    public void render(PlayerEntityModel vanilla, PlayerEntityRenderState state, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light, int overlay, int color) {
        vanilla.setAngles(state);
        copyAngles(vanilla);

        matrices.push();
        matrices.scale(1.25f, 1.25f, 1.25f);
        matrices.translate(0.0f, -0.3f, 0.0f);
        VertexConsumer vertexConsumer = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucent(TEXTURE));
        this.root.render(matrices, vertexConsumer, light, overlay, color);
        matrices.pop();
    }

    private void copyAngles(PlayerEntityModel vanilla) {
        this.head.pitch = vanilla.head.pitch;
        this.head.yaw = vanilla.head.yaw;
        this.head.roll = vanilla.head.roll;

        this.body.pitch = 0.0f;
        this.body.yaw = 0.0f;
        this.body.roll = 0.0f;

        this.leftArm.pitch = vanilla.leftArm.pitch;
        this.leftArm.yaw = vanilla.leftArm.yaw;
        this.leftArm.roll = vanilla.leftArm.roll - ARM_TILT;

        this.rightArm.pitch = vanilla.rightArm.pitch;
        this.rightArm.yaw = vanilla.rightArm.yaw;
        this.rightArm.roll = vanilla.rightArm.roll + ARM_TILT;

        this.leftLeg.pitch = vanilla.leftLeg.pitch;
        this.leftLeg.yaw = vanilla.leftLeg.yaw;
        this.leftLeg.roll = vanilla.leftLeg.roll;

        this.rightLeg.pitch = vanilla.rightLeg.pitch;
        this.rightLeg.yaw = vanilla.rightLeg.yaw;
        this.rightLeg.roll = vanilla.rightLeg.roll;
    }

    private static ModelPartBuilder box(int u, int v, float x, float y, float z, float width, float height, float depth) {
        return ModelPartBuilder.create().uv(u, v).cuboid(x, y, z, width, height, depth);
    }
}
