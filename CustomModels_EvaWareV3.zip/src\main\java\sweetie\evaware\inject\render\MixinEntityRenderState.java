package sweetie.evaware.inject.render;

import net.minecraft.client.render.entity.state.EntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import sweetie.evaware.api.system.interfaces.ICustomModelCarrier;

@Mixin(EntityRenderState.class)
public abstract class MixinEntityRenderState implements ICustomModelCarrier {
    @Unique
    private String evaware$customModel;

    @Override
    public String evaware$getCustomModel() {
        return this.evaware$customModel;
    }

    @Override
    public void evaware$setCustomModel(String model) {
        this.evaware$customModel = model;
    }
}
