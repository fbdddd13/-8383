package sweetie.evaware.client.utils.render.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class VerityMesh {

    /** Where the avatar sits on the player, in entity model space (y grows downwards). */
    private static final float CENTER_Y = 0.75f;
    /** Blockbench units are sixteenths of a block. */
    private static final float UNIT = 2.2f / 16.0f;

    /** Quads as position (3), uv (2), normal (3) per vertex (32 floats per quad). */
    private static float[] quads;
    private static boolean parsed;

    private VerityMesh() {
    }

    public static void render(PlayerEntityRenderState state, MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                              int light, int overlay, Identifier texture, float scale) {
        float[] data = geometry();
        if (data.length == 0) {
            return;
        }

        matrices.push();

        // Sneaking offset to match player crouch
        if (state.isInSneakingPose) {
            matrices.translate(0.0f, 0.25f, 0.0f);
        }

        // Center on avatar
        matrices.translate(0.0f, CENTER_Y, 0.0f);

        // Head tracking: rotate with player head yaw and pitch
        float headYaw = state.yawDegrees - state.bodyYaw;
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(headYaw));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(state.pitch));

        matrices.scale(scale, scale, scale);

        // Use getEntityCutoutNoCull so backfaces and interior walls are never culled
        VertexConsumer consumer = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(texture));
        MatrixStack.Entry entry = matrices.peek();

        // Each quad is 32 floats (4 vertices * 8 floats)
        for (int q = 0; q < data.length; q += 32) {
            vertex(entry, consumer, data, q, light, overlay);
            vertex(entry, consumer, data, q + 8, light, overlay);
            vertex(entry, consumer, data, q + 16, light, overlay);
            vertex(entry, consumer, data, q + 24, light, overlay);
        }

        matrices.pop();
    }

    private static synchronized float[] geometry() {
        if (!parsed) {
            parsed = true;
            quads = parse();
        }
        return quads;
    }

    private static float[] parse() {
        try (InputStream stream = VerityMesh.class.getResourceAsStream("/assets/evaware/models/verity/verity.bbmodel")) {
            if (stream == null) {
                return new float[0];
            }
            JsonObject root = JsonParser.parseReader(new InputStreamReader(stream, StandardCharsets.UTF_8)).getAsJsonObject();
            float uvWidth = 64.0f;
            float uvHeight = 64.0f;
            if (root.has("resolution")) {
                JsonObject resolution = root.getAsJsonObject("resolution");
                uvWidth = resolution.get("width").getAsFloat();
                uvHeight = resolution.get("height").getAsFloat();
            }

            List<Float> out = new ArrayList<>(1 << 16);

            for (JsonElement entry : root.getAsJsonArray("elements")) {
                JsonObject element = entry.getAsJsonObject();
                if (!element.has("vertices") || !element.has("faces")) {
                    continue;
                }

                JsonObject vertices = element.getAsJsonObject("vertices");
                for (Map.Entry<String, JsonElement> face : element.getAsJsonObject("faces").entrySet()) {
                    JsonObject data = face.getValue().getAsJsonObject();
                    JsonArray order = data.getAsJsonArray("vertices");
                    JsonObject uv = data.getAsJsonObject("uv");
                    int corners = order.size();
                    if (corners < 3) {
                        continue;
                    }

                    if (corners == 4) {
                        String id0 = order.get(0).getAsString();
                        String id1 = order.get(1).getAsString();
                        String id2 = order.get(2).getAsString();
                        String id3 = order.get(3).getAsString();

                        // 1. Outside quad: wound CCW (0, 3, 2, 1) with outward normal
                        appendQuad(out, vertices, uv, uvWidth, uvHeight, id0, id3, id2, id1);

                        // 2. Inside quad: wound CW (0, 1, 2, 3) with inward normal (makes interior solid, not transparent)
                        appendQuad(out, vertices, uv, uvWidth, uvHeight, id0, id1, id2, id3);
                    } else if (corners == 3) {
                        String id0 = order.get(0).getAsString();
                        String id1 = order.get(1).getAsString();
                        String id2 = order.get(2).getAsString();

                        // 1. Outside triangle quad: wound CCW (0, 2, 1, 1) with outward normal
                        appendTriQuad(out, vertices, uv, uvWidth, uvHeight, id0, id2, id1);

                        // 2. Inside triangle quad: wound CW (0, 1, 2, 2) with inward normal
                        appendTriQuad(out, vertices, uv, uvWidth, uvHeight, id0, id1, id2);
                    }
                }
            }

            float[] packed = new float[out.size()];
            for (int i = 0; i < packed.length; i++) {
                packed[i] = out.get(i);
            }
            return packed;
        } catch (Exception exception) {
            System.err.println("EvaWare: failed to read the Verity model: " + exception);
            return new float[0];
        }
    }

    private static void appendQuad(List<Float> out, JsonObject vertices, JsonObject uv,
                                   float uvWidth, float uvHeight,
                                   String id0, String id1, String id2, String id3) {
        float[] p0 = point(vertices, id0);
        float[] p1 = point(vertices, id1);
        float[] p2 = point(vertices, id2);
        float[] p3 = point(vertices, id3);
        if (p0 == null || p1 == null || p2 == null || p3 == null) {
            return;
        }

        float[] normal = normal(p0, p1, p2);
        String[] ids = {id0, id1, id2, id3};
        float[][] pts = {p0, p1, p2, p3};
        for (int i = 0; i < 4; i++) {
            float[] pos = pts[i];
            float[] tex = uvOf(uv, ids[i], uvWidth, uvHeight);
            out.add(pos[0]);
            out.add(pos[1]);
            out.add(pos[2]);
            out.add(tex[0]);
            out.add(tex[1]);
            out.add(normal[0]);
            out.add(normal[1]);
            out.add(normal[2]);
        }
    }

    private static void appendTriQuad(List<Float> out, JsonObject vertices, JsonObject uv,
                                      float uvWidth, float uvHeight,
                                      String id0, String id1, String id2) {
        float[] p0 = point(vertices, id0);
        float[] p1 = point(vertices, id1);
        float[] p2 = point(vertices, id2);
        if (p0 == null || p1 == null || p2 == null) {
            return;
        }

        float[] normal = normal(p0, p1, p2);
        String[] ids = {id0, id1, id2, id2};
        float[][] pts = {p0, p1, p2, p2};
        for (int i = 0; i < 4; i++) {
            float[] pos = pts[i];
            float[] tex = uvOf(uv, ids[i], uvWidth, uvHeight);
            out.add(pos[0]);
            out.add(pos[1]);
            out.add(pos[2]);
            out.add(tex[0]);
            out.add(tex[1]);
            out.add(normal[0]);
            out.add(normal[1]);
            out.add(normal[2]);
        }
    }

    /** One vertex of the model moved into entity model space (facing forward -Z). */
    private static float[] point(JsonObject vertices, String id) {
        if (!vertices.has(id)) {
            return null;
        }
        JsonArray raw = vertices.getAsJsonArray(id);
        float x = raw.get(0).getAsFloat();
        float y = raw.get(1).getAsFloat();
        float z = raw.get(2).getAsFloat();

        // Blockbench has y growing upwards, entity model space has it growing down.
        // Raw coords naturally face -Z (forward in Minecraft), perfect for head orientation.
        return new float[]{x * UNIT, -y * UNIT, z * UNIT};
    }

    private static float[] uvOf(JsonObject uv, String id, float uvWidth, float uvHeight) {
        if (uv == null || !uv.has(id)) {
            return new float[]{0.0f, 0.0f};
        }
        JsonArray raw = uv.getAsJsonArray(id);
        return new float[]{raw.get(0).getAsFloat() / uvWidth, raw.get(1).getAsFloat() / uvHeight};
    }

    private static float[] normal(float[] a, float[] b, float[] c) {
        float ux = b[0] - a[0];
        float uy = b[1] - a[1];
        float uz = b[2] - a[2];
        float vx = c[0] - a[0];
        float vy = c[1] - a[1];
        float vz = c[2] - a[2];
        float nx = uy * vz - uz * vy;
        float ny = uz * vx - ux * vz;
        float nz = ux * vy - uy * vx;
        float length = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (length < 1.0e-6f) {
            return new float[]{0.0f, -1.0f, 0.0f};
        }
        return new float[]{nx / length, ny / length, nz / length};
    }

    private static void vertex(MatrixStack.Entry entry, VertexConsumer consumer, float[] data, int i, int light, int overlay) {
        consumer.vertex(entry, data[i], data[i + 1], data[i + 2])
                .color(-1)
                .texture(data[i + 3], data[i + 4])
                .overlay(overlay)
                .light(light)
                .normal(entry, data[i + 5], data[i + 6], data[i + 7]);
    }
}
