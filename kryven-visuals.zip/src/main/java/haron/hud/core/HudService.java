package haron.hud.core;

import haron.events.EventDispatcher;

public abstract class HudService {
   private boolean enabled;

   public void toggle() {
      this.setEnabled(!this.enabled);
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void initialize() {
      HudServiceInfo geskfq2 = this.getClass().getAnnotation(HudServiceInfo.class);
      this.setEnabled(geskfq2 == null || geskfq2.enabledByDefault());
   }

   public void setEnabled(boolean bl) {
      if (this.enabled != bl) {
         this.enabled = bl;
         if (bl) {
            EventDispatcher.EVENT_BUS.subscribe(this);
         } else {
            EventDispatcher.EVENT_BUS.unsubscribe(this);
         }
      }
   }
}
