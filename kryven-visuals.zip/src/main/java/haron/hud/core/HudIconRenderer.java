package haron.hud.core;

import haron.render.ShapeRenderer;
import haron.render.icons.HaronIcons;
import java.awt.Color;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.opengl.GL11;
import ru.haron.Kryven;

public final class HudIconRenderer {
   private static boolean loggedWatermarkIcon = false;

   public static void drawHaronMark(ShapeRenderer s7swsm2, MatrixStack matrixStack, float f, float f2, float f3, Color color) {
      Identifier identifier = HaronIcons.get("pulse_ico");
      if (identifier == null) {
         identifier = HaronIcons.get("logo");
      }

      if (identifier != null && color.getAlpha() >= 1) {
         s7swsm2.a(identifier, f, f2, f3, f3, 0.0F, 1.0F, 1.0F, -1.0F, -1.0F, color, matrixStack);
      }
   }

   private static void logWatermarkIcon(Identifier identifier, float f, Color color) {
      if (!loggedWatermarkIcon) {
         loggedWatermarkIcon = true;
         Kryven.getLOGGER()
            .info(
               "[PulseIcons] drawWatermarkIcon -> identifier={} size={} tint=rgba({},{},{},{})",
               identifier,
               f,
               color.getRed(),
               color.getGreen(),
               color.getBlue(),
               color.getAlpha()
            );
      }
   }

   private static void tryEnableStencil() {
      try {
         Framebuffer framebuffer = MinecraftClient.getInstance().getFramebuffer();

         try {
            framebuffer.getClass().getMethod("enableStencil").invoke(framebuffer);
            return;
         } catch (NoSuchMethodException noSuchMethodException) {
            try {
               framebuffer.getClass().getMethod("enableStencilTest").invoke(framebuffer);
            } catch (NoSuchMethodException var3) {
            }
         }
      } catch (Exception var5) {
      }
   }

   public static void drawRotated180(ShapeRenderer s7swsm2, MatrixStack matrixStack, Identifier identifier, float f, float f2, float f3, Color color) {
      if (s7swsm2 != null && identifier != null && color.getAlpha() >= 1) {
         float f4 = f + f3 / 2.0F;
         float f5 = f2 + f3 / 2.0F;
         matrixStack.push();
         matrixStack.translate(f4, f5, 0.0F);
         matrixStack.scale(-1.0F, -1.0F, 1.0F);
         matrixStack.translate(-f4, -f5, 0.0F);
         s7swsm2.a(identifier, f, f2, f3, f3, color, matrixStack);
         matrixStack.pop();
      }
   }

   public static void drawWatermarkIcon(ShapeRenderer s7swsm2, MatrixStack matrixStack, float f, float f2, float f3, Color color) {
      Identifier identifier = HaronIcons.get("logo");
      if (s7swsm2 != null && identifier != null && color.getAlpha() >= 1) {
         logWatermarkIcon(identifier, f3, color);
         s7swsm2.a(identifier, f, f2, f3, f3, 0.0F, 1.0F, 1.0F, -1.0F, -1.0F, color, matrixStack);
      }
   }

   public static Identifier clickGui(String string) {
      Identifier identifier = HaronIcons.get(string);
      return identifier != null ? identifier : Identifier.of("haron", $sf$0(string));
   }

   public static void draw(ShapeRenderer s7swsm2, MatrixStack matrixStack, Identifier identifier, float f, float f2, float f3, Color color) {
      if (s7swsm2 != null && identifier != null && color.getAlpha() >= 1) {
         s7swsm2.a(identifier, f, f2, f3, f3, color, matrixStack);
      }
   }

   public static void drawFlippedVertical(ShapeRenderer s7swsm2, MatrixStack matrixStack, Identifier identifier, float f, float f2, float f3, Color color) {
      if (s7swsm2 != null && identifier != null && color.getAlpha() >= 1) {
         float f4 = f2 + f3 / 2.0F;
         matrixStack.push();
         matrixStack.translate(0.0F, f4, 0.0F);
         matrixStack.scale(1.0F, -1.0F, 1.0F);
         matrixStack.translate(0.0F, -f4, 0.0F);
         s7swsm2.a(identifier, f, f2, f3, f3, color, matrixStack);
         matrixStack.pop();
      }
   }

   public static void drawWatermarkIconRounded(ShapeRenderer s7swsm2, MatrixStack matrixStack, float f, float f2, float f3, float f4, Color color) {
      Identifier identifier = HaronIcons.get("logo");
      if (s7swsm2 != null && identifier != null && color.getAlpha() >= 1) {
         logWatermarkIcon(identifier, f3, color);

         try {
            tryEnableStencil();
            GL11.glEnable(2960);
            GL11.glStencilMask(255);
            GL11.glClearStencil(0);
            GL11.glClear(1024);
            GL11.glStencilFunc(519, 1, 255);
            GL11.glStencilOp(7681, 7681, 7681);
            GL11.glColorMask(false, false, false, false);
            Color color2 = new Color(255, 255, 255, 255);
            s7swsm2.a(f, f2, f3, f3, f4, color2, color2, color2, color2, matrixStack);
            GL11.glColorMask(true, true, true, true);
            GL11.glStencilMask(0);
            GL11.glStencilFunc(514, 1, 255);
            GL11.glStencilOp(7680, 7680, 7680);
            s7swsm2.a(identifier, f, f2, f3, f3, 0.0F, 1.0F, 1.0F, -1.0F, -1.0F, color, matrixStack);
         } finally {
            GL11.glStencilMask(255);
            GL11.glDisable(2960);
            GL11.glColorMask(true, true, true, true);
         }
      }
   }

   private HudIconRenderer() {
   }

   private static String $sf$0(String string) {
      return "textures/clickgui/" + string;
   }
}
