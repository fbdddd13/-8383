package haron.hud.notifications;

public enum oo89jz {
   HOME("home", "\ue90f"),
   REPAIR("repair", "\ue91f"),
   FAST("fast", "\ue90b"),
   SHIELD("shield", "\ue923"),
   DEATH("death", "\ue907"),
   DIAMOND("diamond", "\ue908"),
   LOCKED("locked", "\ue914"),
   MOUNTAIN("mountain", "\ue917"),
   CALENDAR("calendar", "\ue90a"),
   EVENT("calendar", "\ue90a");

   private final String id;
   private final String icon;

   public String glyph() {
      return this.icon;
   }

   oo89jz(String string2, String string3) {
      this.id = string2;
      this.icon = string3;
   }

   public String b() {
      return this.icon;
   }

   public String a() {
      return this.id;
   }

   public String id() {
      return this.id;
   }
}
