package haron.hud.notifications;

import java.util.Collections;
import java.util.List;

public final class gv8nup {
   public static void pruneExpired() {
   }

   public static List<eq8z6w> savedNotifications() {
      return Collections.emptyList();
   }

   public static List<eq8z6w> allNotifications() {
      return Collections.emptyList();
   }

   public static eq8z6w hitTest(int n, int n2, int n3) {
      return null;
   }

   public static List<eq8z6w> visibleNotifications() {
      return Collections.emptyList();
   }

   private gv8nup() {
   }

   public static void remove(eq8z6w eq8z6w2) {
   }

   public static void reset() {
   }

   public static void clear() {
   }

   public static void e() {
      pruneExpired();
   }

   public static boolean isEmpty() {
      return true;
   }

   public static void add(eq8z6w eq8z6w2) {
   }

   public static void b(eq8z6w eq8z6w2) {
      remove(eq8z6w2);
   }

   public static void b() {
      clear();
   }

   public static void c() {
      reset();
   }

   public static List<eq8z6w> f() {
      return savedNotifications();
   }

   public static boolean d() {
      return isEmpty();
   }

   public static eq8z6w a(int n, int n2, int n3) {
      int n4 = 587;
      return hitTest(n, n2, n3);
   }

   public static List<eq8z6w> a() {
      return visibleNotifications();
   }

   public static void a(eq8z6w eq8z6w2) {
      add(eq8z6w2);
   }

   public static List<eq8z6w> g() {
      return allNotifications();
   }
}
