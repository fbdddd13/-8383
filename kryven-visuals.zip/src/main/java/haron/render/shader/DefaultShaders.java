package haron.render.shader;

public final class DefaultShaders {
   private static final ShaderRegistry REGISTRY = new ShaderRegistry();

   public static void loadDefaultShaders() {
      if (!REGISTRY.find("round_rect").isPresent()) {
         register("round_rect", "fragment/round_rect.fsh");
         register("round_rect_outline", "fragment/round_rect_outline.fsh");
         register("drop_shadow", "fragment/drop_shadow.fsh");
         register("rect_glow", "fragment/rect_glow.fsh");
         register("round_texture", "fragment/round_texture.fsh");
         register("gradient", "fragment/gradient.fsh");
         register("hue_bar", "fragment/hue_bar.fsh");
         register("hand_shader", "fragment/hand_shader.fsh");
         register("block_nebula", "fragment/block_nebula.fsh");
         register("block_starfield", "fragment/block_starfield.fsh");
         register("block_cobweb", "fragment/block_cobweb.fsh");
         register("block_plasma", "fragment/block_plasma.fsh");
      }
   }

   public static ShaderRegistry getRegistry() {
      return REGISTRY;
   }

   private DefaultShaders() {
   }

   private static void register(String string, String string2) {
      REGISTRY.register(
         string, ShaderProgramBuilder.create().attach("vertex/passthrough.vsh", ShaderStage.VERTEX).attach(string2, ShaderStage.FRAGMENT).link().build()
      );
   }
}
