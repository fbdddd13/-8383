package haron.render.shader;

import com.google.common.collect.Maps;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.nio.FloatBuffer;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL30;
import ru.haron.Kryven;

public class ShaderProgram {
   private static final int a = 0;
   private static final int b = 1;
   private static int e = -1;
   private static int f = -1;
   private static final FloatBuffer g = BufferUtils.createFloatBuffer(16);
   private boolean d = true;
   private final Map<String, Integer> h = Maps.newLinkedHashMap();
   private final int c = GL30.glCreateProgram();

   public void e() {
      GL30.glUseProgram(0);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   public void b(String string, int n) {
      GL30.glUniform1i(this.a(string), n);
   }

   public boolean b() {
      return this.d;
   }

   public void b(String string, FloatBuffer floatBuffer) {
      RenderSystem.glUniform1(this.a(string), floatBuffer);
   }

   public void c(String string, FloatBuffer floatBuffer) {
      GL30.glUniformMatrix4fv(this.a(string), false, floatBuffer);
   }

   public void c() {
      GL30.glBindAttribLocation(this.c, 0, "Position");
      GL30.glBindAttribLocation(this.c, 1, "UV0");
      GL30.glLinkProgram(this.c);
      if (GL30.glGetProgrami(this.c, 35714) == 0) {
         Kryven.getLOGGER().error("ShaderProgram {} link error: \n{}", this.c, GL30.glGetProgramInfoLog(this.c));
         this.d = false;
      }
   }

   private static void f() {
      int n = GL30.glGetInteger(34229);
      e = GL30.glGenVertexArrays();
      f = GL30.glGenBuffers();
      GL30.glBindVertexArray(e);
      GL30.glBindBuffer(34962, f);
      GL30.glEnableVertexAttribArray(0);
      GL30.glVertexAttribPointer(0, 3, 5126, false, 20, 0L);
      GL30.glEnableVertexAttribArray(1);
      GL30.glVertexAttribPointer(1, 2, 5126, false, 20, 12L);
      GL30.glBindVertexArray(n);
   }

   public void d() {
      if (this.d) {
         GL30.glUseProgram(this.c);
         Matrix4f matrix4f = RenderSystem.getProjectionMatrix();
         Matrix4f matrix4f2 = RenderSystem.getModelViewMatrix();
         g.clear();
         matrix4f.get(g);
         g.rewind();
         int n = this.a("ProjMat");
         if (n != -1) {
            GL30.glUniformMatrix4fv(n, false, g);
         }

         g.clear();
         matrix4f2.get(g);
         g.rewind();
         int n2 = this.a("ModelViewMat");
         if (n2 != -1) {
            GL30.glUniformMatrix4fv(n2, false, g);
         }

         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         this.a("resolution", minecraftClient.getWindow().getScaledWidth(), minecraftClient.getWindow().getScaledHeight());
      }
   }

   public void a(String string, int n, int n2) {
      GL30.glUniform2i(this.a(string), n, n2);
   }

   public void a(String string, FloatBuffer floatBuffer) {
      int n = 532;
      GL30.glUniform1fv(this.a(string), floatBuffer);
   }

   public void a(String string, float f, float f2, float f3) {
      GL30.glUniform3f(this.a(string), f, f2, f3);
   }

   public void a(String string, int n, int n2, int n3) {
      int n4 = 960;
      GL30.glUniform3i(this.a(string), n, n2, n3);
   }

   public void a(String string, int n, int n2, int n3, int n4) {
      GL30.glUniform4i(this.a(string), n, n2, n3, n4);
   }

   public void a(String string, float[] fArray) {
      GL30.glUniformMatrix4fv(this.a(string), false, fArray);
   }

   public void a(String string, float f) {
      GL30.glUniform1f(this.a(string), f);
   }

   public int a(String string) {
      if (!this.h.containsKey(string)) {
         this.h.put(string, GL30.glGetUniformLocation(this.c, string));
      }

      return this.h.get(string);
   }

   public static void a(float[] fArray, int n) {
      if (e == -1) {
         f();
      }

      int n2 = GL30.glGetInteger(34229);
      GL30.glBindVertexArray(e);
      GL30.glBindBuffer(34962, f);
      GL30.glBufferData(34962, fArray, 35048);
      GL30.glDrawArrays(4, 0, n);
      GL30.glBindVertexArray(n2);
   }

   public static void a(float f, float f2, float f3, float f4) {
      if (e == -1) {
         f();
      }

      int n = GL30.glGetInteger(34229);
      GL30.glBindVertexArray(e);
      GL30.glBindBuffer(34962, ShaderProgram.f);
      GL30.glBufferData(
         34962,
         new float[]{
            f,
            f2 + f4,
            0.0F,
            0.0F,
            1.0F,
            f + f3,
            f2 + f4,
            0.0F,
            1.0F,
            1.0F,
            f + f3,
            f2,
            0.0F,
            1.0F,
            0.0F,
            f,
            f2 + f4,
            0.0F,
            0.0F,
            1.0F,
            f + f3,
            f2,
            0.0F,
            1.0F,
            0.0F,
            f,
            f2,
            0.0F,
            0.0F,
            0.0F
         },
         35048
      );
      GL30.glDrawArrays(4, 0, 6);
      GL30.glBindVertexArray(n);
   }

   public void a(String string, int n) {
      int n2 = GL30.glCreateShader(n);
      GL30.glShaderSource(n2, string);
      GL30.glCompileShader(n2);
      if (GL30.glGetShaderi(n2, 35713) != 0) {
         GL30.glAttachShader(this.c, n2);
      } else {
         Kryven.getLOGGER().error("Shader {} compile error: \n{}", n2, GL30.glGetShaderInfoLog(n2));
         this.d = false;
      }
   }

   public void a(String string, Color color) {
      GL30.glUniform4f(this.a(string), color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
   }

   public void a(String string, float f, float f2, float f3, float f4) {
      GL30.glUniform4f(this.a(string), f, f2, f3, f4);
   }

   public int a() {
      return this.c;
   }

   public void a(String string, float f, float f2) {
      GL30.glUniform2f(this.a(string), f, f2);
   }
}
