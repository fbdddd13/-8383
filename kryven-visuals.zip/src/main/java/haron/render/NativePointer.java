package haron.render;

public interface NativePointer {
   long pointer();
}
