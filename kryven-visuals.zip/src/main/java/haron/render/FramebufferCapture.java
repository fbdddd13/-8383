package haron.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.VertexFormat;
import org.lwjgl.opengl.GL14;

public class FramebufferCapture {
   private static final MinecraftClient a = MinecraftClient.getInstance();
   private static Framebuffer b = null;
   private static int c = 0;
   private static int d = 0;
   private static boolean e = false;
   private static float f = 0.0F;
   private static float g = 0.0F;
   private static float h = 0.0F;
   private static float i = 0.0F;

   private static void drawCaptured(float f) {
      RenderSystem.enableBlend();
      RenderSystem.blendFuncSeparate(GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
      GlStateManager._bindTexture(b.getColorAttachment());
      RenderSystem.setShaderTexture(0, b.getColorAttachment());
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      float f2 = ScaledGuiProjection.d();
      float f3 = a.getWindow().getFramebufferWidth();
      float f4 = a.getWindow().getFramebufferHeight();
      float f5 = FramebufferCapture.f * f2 / f3;
      float f6 = 1.0F - (g + i) * f2 / f4;
      float f7 = (FramebufferCapture.f + h) * f2 / f3;
      float f8 = 1.0F - g * f2 / f4;
      int n = (int)(f * 255.0F);
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
      bufferBuilder.vertex(FramebufferCapture.f, g, 0.0F).texture(f5, f8).color(n, n, n, n);
      bufferBuilder.vertex(FramebufferCapture.f, g + i, 0.0F).texture(f5, f6).color(n, n, n, n);
      bufferBuilder.vertex(FramebufferCapture.f + h, g + i, 0.0F).texture(f7, f6).color(n, n, n, n);
      bufferBuilder.vertex(FramebufferCapture.f + h, g, 0.0F).texture(f7, f8).color(n, n, n, n);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      GlStateManager._bindTexture(0);
      RenderSystem.defaultBlendFunc();
   }

   public static boolean isCapturing() {
      return e;
   }

   public static void applyBlendState() {
      if (e) {
         GL14.glBlendFuncSeparate(770, 771, 1, 771);
      } else {
         RenderSystem.defaultBlendFunc();
      }
   }

   public static void begin(float f, float f2, float f3, float f4) {
      if (!e) {
         int n = a.getWindow().getFramebufferWidth();
         int n2 = a.getWindow().getFramebufferHeight();
         if (c != n || d != n2) {
            b.delete();
            b = new SimpleFramebuffer(n, n2, true);
            b.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            c = n;
            d = n2;
         }

         FramebufferCapture.f = f;
         g = f2;
         h = f3;
         i = f4;
         b.clear();
         b.beginWrite(true);
         e = true;
      }
   }

   public static void end(ShapeRenderer s7swsm2, float f, MatrixStack matrixStack) {
      if (e) {
         e = false;
         a.getFramebuffer().beginWrite(true);
         if (f > 0.001F) {
            drawCaptured(f);
         }
      }
   }

   public static void dispose() {
      b.delete();
      b = null;
      e = false;
   }
}
