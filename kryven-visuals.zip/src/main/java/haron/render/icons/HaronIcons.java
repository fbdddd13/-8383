package haron.render.icons;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.util.Identifier;
import ru.haron.Kryven;

public final class HaronIcons {
   public static final String WATER = "water";
   public static final String ARROW_V = "arrow_v";
   public static final String KEYBOARD = "keyboard";
   public static final String ICON = "icon";
   public static final String BUBBLE_1 = "bubble_1";
   public static final String BUBBLE_2 = "bubble_2";
   public static final String LIGHTNING = "lightning";
   public static final String PULSE_ICON = "pulse_icon";
   public static final String SEARCH = "search";
   public static final String ARROW = "arrow";
   public static final String UP_ARROW = "up_arrow";
   public static final String LOGO = "logo";
   public static final String CALENDAR = "calendar";
   public static final String DEATH = "death";
   public static final String DIAMOND = "diamond";
   public static final String FAST = "fast";
   public static final String HOME = "home";
   public static final String LOCKED = "locked";
   public static final String MOUNTAIN = "mountain";
   public static final String REPAIR = "repair";
   public static final String SHIELD = "shield";
   public static final String TRASH = "trash";
   public static final String PLAY = "play";
   public static final String SHARE = "share";
   public static final String SAVE = "save";
   public static final String PLUS = "plus";
   public static final String KEY = "key";
   public static final String EDIT = "edit";
   public static final String LOAD = "load";
   public static final String PULSE_ICO = "pulse_ico";
   private static final String DEFAULT_KEY = "icon";
   private static final Map<String, IconTexture> TEXTURES = new HashMap<>();

   private static void registerPotionAliases() {
      IconTexture hclqea2 = TEXTURES.get("potions");

      for (String string : new String[]{
         "absorption",
         "bad_omen",
         "blindness",
         "conduit_power",
         "dolphins_grace",
         "fire_resistance",
         "glowing",
         "haste",
         "health_boost",
         "hero_of_the_village",
         "hunger",
         "instant_damage",
         "instant_health",
         "invisibility",
         "jump_boost",
         "levitation",
         "luck",
         "mining_fatigue",
         "nausea",
         "night_vision",
         "poison",
         "regeneration",
         "resistance",
         "saturation",
         "slow_falling",
         "slowness",
         "speed",
         "strength",
         "unluck",
         "water_breathing",
         "weakness",
         "wither"
      }) {
         TEXTURES.put(string, hclqea2);
      }
   }

   private HaronIcons() {
   }

   public static Identifier get(String string) {
      IconTexture hclqea2 = getInfo(string);
      return hclqea2 == null ? Identifier.of("haron", "textures/icon.png") : hclqea2.a();
   }

   public static void load() {
      if (TEXTURES.isEmpty()) {
         register("shadow", "textures/shadow.png");
         register("logo", "textures/logo.png");
         register("logo_menu", "textures/logo_menu.png");
         register("icon", "textures/icon.png");
         register("bubble_1", "textures/bubble_1.png");
         register("bubble_2", "textures/bubble_2.png");
         register("up_arrow", "textures/up_arrow.png");
         register("arrow", "textures/arrow.png");
         register("target", "textures/target.png");
         register("search", "textures/clickgui/search.png");
         register("keyboard", "textures/clickgui/keyboard.png");
         register("calendar", "textures/clickgui/calendar.png");
         register("death", "textures/clickgui/death.png");
         register("diamond", "textures/clickgui/diamond.png");
         register("fast", "textures/clickgui/fast.png");
         register("home", "textures/clickgui/home.png");
         register("locked", "textures/clickgui/locked.png");
         register("mountain", "textures/clickgui/mountain.png");
         register("repair", "textures/clickgui/repair.png");
         register("shield", "textures/clickgui/shield.png");
         register("trash", "textures/clickgui/trash.png");
         register("play", "textures/clickgui/play.png");
         register("share", "textures/clickgui/share.png");
         register("save", "textures/clickgui/save.png");
         register("plus", "textures/clickgui/plus.png");
         register("key", "textures/clickgui/key.png");
         register("edit", "textures/clickgui/edit.png");
         register("load", "textures/clickgui/load.png");
         register("bell", "textures/clickgui/bell.png");
         register("warning", "textures/clickgui/warning.png");
         register("music", "textures/clickgui/music.png");
         register("arrows_left", "textures/clickgui/arrows_left.png");
         register("arrows_right", "textures/clickgui/arrows_right.png");
         register("pause", "textures/clickgui/pause.png");
         register("play_button", "textures/clickgui/play_button.png");
         register("hotkeys", "textures/clickgui/hotkeys.png");
         register("cooldowns", "textures/clickgui/cooldowns.png");
         register("configs", "textures/clickgui/configs.png");
         register("events", "textures/clickgui/events.png");
         register("friends", "textures/clickgui/friends.png");
         register("hud", "textures/clickgui/hud.png");
         register("markers", "textures/clickgui/markers.png");
         register("modules", "textures/clickgui/modules.png");
         register("utilities", "textures/clickgui/utilities.png");
         register("visuals", "textures/clickgui/visuals.png");
         register("example_group", "textures/clickgui/example_group.png");
         registerPotionAliases();
      }
   }

   private static void register(String string, String string2) {
      Identifier identifier = Identifier.of("haron", string2);
      int n = 1;
      int n2 = 1;

      try {
         InputStream inputStream = HaronIcons.class.getResourceAsStream($sf$0(string2));
         if (inputStream == null) {
            Kryven.getLOGGER().warn("[HaronIcons] Texture file NOT FOUND on classpath: /assets/haron/{} (key={}, id={})", string2, string, identifier);
         } else {
            NativeImage nativeImage = NativeImage.read(inputStream);
            n = nativeImage.getWidth();
            n2 = nativeImage.getHeight();
            nativeImage.close();
            if (string.equals("logo")) {
               Kryven.getLOGGER().info("[HaronIcons] Loaded LOGO texture: path=/assets/haron{} id={} size={}x{}", string2, identifier, n, n2);
            }
         }

         if (inputStream != null) {
            inputStream.close();
         }
      } catch (IOException iOException) {
         Kryven.getLOGGER().warn("[HaronIcons] Failed to read texture: /assets/haron/{}", string2, iOException);
      }

      TEXTURES.put(string, new IconTexture(identifier, n, n2));
   }

   private static String normalizeKey(String string) {
      return string != null && !string.isBlank() && string.matches("[a-z0-9_./-]+") ? string : "icon";
   }

   public static IconTexture getInfo(String string) {
      load();
      IconTexture hclqea2 = TEXTURES.get(normalizeKey(string));
      return hclqea2 != null ? hclqea2 : TEXTURES.get("icon");
   }

   private static String $sf$0(String string) {
      int n = 272;
      return "/assets/haron/" + string;
   }
}
