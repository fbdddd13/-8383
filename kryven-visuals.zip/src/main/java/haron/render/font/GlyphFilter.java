package haron.render.font;

@FunctionalInterface
public interface GlyphFilter {
   boolean a(int var1, char var2);
}
