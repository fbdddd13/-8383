package haron.render.font;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.render.FramebufferCapture;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.ObjectList;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import java.awt.Color;
import java.awt.Font;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexFormat;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

public class FontRenderer {
   private static final FontRenderContext a = new FontRenderContext(new AffineTransform(), true, true);
   private final Object2ObjectMap<Identifier, ObjectList<GlyphDrawEntry>> b = new Object2ObjectOpenHashMap();
   private final Object2ObjectMap<Identifier, ObjectList<GradientGlyphDrawEntry>> c = new Object2ObjectOpenHashMap();
   private final ObjectList<FontAtlas> d = new ObjectArrayList();
   private Font e;
   private float f;

   public FontRenderer(Font font, float f) {
      this.a(font, f);
   }

   private FontGlyph b(char c) {
      ObjectListIterator c2 = this.d.iterator();

      while (c2.hasNext()) {
         FontAtlas ahdbxt2 = (FontAtlas)c2.next();
         if (ahdbxt2.b(c)) {
            return ahdbxt2.a(c);
         }
      }

      char c2x = (char)a((int)c);
      return this.a(c2x, (char)(c2x + 256)).a(c);
   }

   public float b(String string) {
      float f = 0.0F;
      float f2 = 0.0F;

      for (char c : (string.isEmpty() ? " " : string).toCharArray()) {
         float f3;
         if (c == '\n') {
            f2 += f == 0.0F ? this.b(' ').d() : f;
            f3 = 0.0F;
         } else {
            FontGlyph wvyq9n2 = this.b(c);
            f3 = Math.max(wvyq9n2 == null ? 0.0F : wvyq9n2.d(), f);
         }

         f = f3;
      }

      return f + f2;
   }

   public String b(String string, int n) {
      return string.substring(0, this.d(string, n));
   }

   public void b(String string, double d, double d2, Color color, MatrixStack matrixStack) {
      this.a(string, d - this.a(string) / 2.0, d2, color, matrixStack);
   }

   public void b(MatrixStack matrixStack, String string, double d, double d2, int n) {
      this.a(matrixStack, string, (float)(d - this.a(string) / 2.0F), (float)d2, n);
   }

   private void b(Matrix4f matrix4f) {
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      ObjectIterator var2 = this.c.keySet().iterator();

      while (var2.hasNext()) {
         Identifier identifier = (Identifier)var2.next();
         RenderSystem.setShaderTexture(0, identifier);
         GL11.glTexParameteri(3553, 10241, 9728);
         GL11.glTexParameteri(3553, 10240, 9728);
         BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
         ObjectListIterator var5 = ((ObjectList)(Object)this.c.get(identifier)).iterator();

         while (var5.hasNext()) {
            GradientGlyphDrawEntry sb7dbt2 = (GradientGlyphDrawEntry)var5.next();
            float f = sb7dbt2.a();
            float f2 = sb7dbt2.b();
            FontGlyph wvyq9n2 = sb7dbt2.e();
            FontAtlas ahdbxt2 = wvyq9n2.f();
            float f3 = wvyq9n2.c();
            float f4 = wvyq9n2.d();
            float f5 = (float)wvyq9n2.a() / ahdbxt2.b;
            float f6 = (float)wvyq9n2.b() / ahdbxt2.c;
            float f7 = (float)(wvyq9n2.a() + wvyq9n2.c()) / ahdbxt2.b;
            float f8 = (float)(wvyq9n2.b() + wvyq9n2.d()) / ahdbxt2.c;
            int n = sb7dbt2.c();
            int n2 = sb7dbt2.d();
            bufferBuilder.vertex(matrix4f, f, f2 + f4, 0.0F).texture(f5, f8).color(n2);
            bufferBuilder.vertex(matrix4f, f + f3, f2 + f4, 0.0F).texture(f7, f8).color(n2);
            bufferBuilder.vertex(matrix4f, f + f3, f2, 0.0F).texture(f7, f6).color(n);
            bufferBuilder.vertex(matrix4f, f, f2, 0.0F).texture(f5, f6).color(n);
         }

         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      }
   }

   public Font b() {
      return this.e;
   }

   public void c(String string, double d, double d2, Color color, MatrixStack matrixStack) {
      this.a(string, d, d2 - this.b(string) / 2.0, color, matrixStack);
   }

   public static Identifier c() {
      int n = 796;
      return Identifier.of("haron", $sf$0(d()));
   }

   private float[] c(String string) {
      if (string.isEmpty()) {
         return new float[0];
      }

      String string2 = string.split("\n")[0];
      float[] fArray = new float[string2.length()];
      GlyphVector glyphVector = this.e.createGlyphVector(a, string2);
      fArray[0] = 0.0F;
      float f = 0.0F;

      for (int i = 1; i < string2.length(); i++) {
         fArray[i] = f += Math.round((float)glyphVector.getGlyphPosition(i).getX() - (float)glyphVector.getGlyphPosition(i - 1).getX());
      }

      return fArray;
   }

   public String c(String string, int n) {
      if (string.isEmpty()) {
         return string;
      }

      GlyphVector glyphVector = this.e.createGlyphVector(a, string);
      float f = n * 2.0F;
      float[] fArray = new float[string.length() + 1];
      fArray[0] = 0.0F;

      for (int i = 1; i <= string.length(); i++) {
         float f2 = (float)glyphVector.getGlyphPosition(i - 1).getX();
         fArray[i] = fArray[i - 1] + Math.round((float)glyphVector.getGlyphPosition(i).getX() - f2);
      }

      float f3 = fArray[string.length()];
      if (f3 <= f) {
         return string;
      }

      for (int i = 1; i < string.length(); i++) {
         if (f3 - fArray[i] <= f) {
            return string.substring(i);
         }
      }

      return "";
   }

   private static String d() {
      Random random = new Random();
      return IntStream.range(0, 32).mapToObj(n -> String.valueOf((char)(97 + random.nextInt(26)))).collect(Collectors.joining());
   }

   private int d(String string, int n) {
      if (string.isEmpty()) {
         return 0;
      }

      GlyphVector glyphVector = this.e.createGlyphVector(a, string);
      float f = n * 2.0F;
      float f2 = 0.0F;

      for (int i = 1; i <= string.length(); i++) {
         float f3 = (float)glyphVector.getGlyphPosition(i - 1).getX();
         if ((f2 += Math.round((float)glyphVector.getGlyphPosition(i).getX() - f3)) > f) {
            return i - 1;
         }
      }

      return string.length();
   }

   public float a(String string) {
      if (string.isEmpty()) {
         return 0.0F;
      }

      float f = 0.0F;

      for (String string2 : string.split("\n")) {
         if (!string2.isEmpty()) {
            GlyphVector glyphVector = this.e.createGlyphVector(a, string2);
            float f2 = 0.0F;

            for (int i = 1; i <= string2.length(); i++) {
               float f3 = (float)glyphVector.getGlyphPosition(i - 1).getX();
               f2 += Math.round((float)glyphVector.getGlyphPosition(i).getX() - f3);
            }

            f = Math.max(f, f2);
         }
      }

      return (float)(Math.round(f / 2.0F * 2.0) / 2.0);
   }

   public String a(String string, int n, boolean bl) {
      return bl ? this.c(string, n) : this.b(string, n);
   }

   public float a(char c) {
      return (float)(Math.round(Math.round((float)this.e.createGlyphVector(a, String.valueOf(c)).getGlyphPosition(1).getX()) / 2.0F * 2.0) / 2.0);
   }

   public float a(String string, int n) {
      if (!string.isEmpty() && n > 0) {
         if (n > string.length()) {
            n = string.length();
         }

         GlyphVector glyphVector = this.e.createGlyphVector(a, string);
         float f = 0.0F;

         for (int i = 1; i <= n; i++) {
            float f2 = (float)glyphVector.getGlyphPosition(i - 1).getX();
            f += Math.round((float)glyphVector.getGlyphPosition(i).getX() - f2);
         }

         return (float)(Math.round(f / 2.0F * 2.0) / 2.0);
      } else {
         return 0.0F;
      }
   }

   public int a(String string, float f) {
      if (!string.isEmpty() && !(f <= 0.0F)) {
         GlyphVector glyphVector = this.e.createGlyphVector(a, string);
         float f2 = f * 2.0F;
         float[] fArray = new float[string.length() + 1];
         fArray[0] = 0.0F;

         for (int n = 1; n <= string.length(); n++) {
            float f3 = (float)glyphVector.getGlyphPosition(n - 1).getX();
            fArray[n] = fArray[n - 1] + Math.round((float)glyphVector.getGlyphPosition(n).getX() - f3);
         }

         for (int var8 = 0; var8 < string.length(); var8++) {
            if (f2 < (fArray[var8] + fArray[var8 + 1]) / 2.0F) {
               return var8;
            }
         }

         return string.length();
      } else {
         return 0;
      }
   }

   private void a(Font font, float f) {
      int n = 988;
      this.f = f;
      this.e = font.deriveFont(f * 2.0F);
   }

   private FontAtlas a(char c, char c2) {
      FontAtlas ahdbxt2 = new FontAtlas(c, c2, this.e, c(), 5);
      this.d.add(ahdbxt2);
      return ahdbxt2;
   }

   private static int a(int n) {
      return 256 * (int)Math.floor(n / 256.0);
   }

   public void a(String string, double d, double d2, MatrixStack matrixStack) {
      this.a(string, d, d2, Color.WHITE, matrixStack);
   }

   private static void a(String string, GlyphFilter qr595b2) {
      int n = string.length();

      for (int i = 0; i < n; i++) {
         if (!qr595b2.a(i, string.charAt(i))) {
            return;
         }
      }
   }

   public float a() {
      int n = 230;
      return this.f;
   }

   public void a(float f) {
      int n = 993;
      this.f = f;
   }

   public void a(MatrixStack matrixStack, String string, double d, double d2, int n, int n2, float f) {
      matrixStack.push();
      matrixStack.translate(Math.round(d * 2.0) / 2.0, Math.round(d2 * 2.0) / 2.0, 0.0);
      matrixStack.scale(0.5F, 0.5F, 0.5F);
      RenderSystem.enableBlend();
      FramebufferCapture.applyBlendState();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      char[] cArray = string.toCharArray();
      float[] fArray = this.c(string);
      float f2 = 0.0F;
      int n3 = 0;

      for (int i = 0; i < cArray.length; i++) {
         char c = cArray[i];
         if (c == '\n') {
            f2 += this.b(string.substring(n3, i)) - 2.0F;
            n3 = i + 1;
            if (n3 < cArray.length) {
               fArray = this.c(string.substring(n3));
            }
         } else {
            FontGlyph wvyq9n2 = this.b(c);
            if (wvyq9n2 != null && wvyq9n2.e() != ' ') {
               ((ObjectList)(Object)this.c.computeIfAbsent(wvyq9n2.f().a, key -> new ObjectArrayList()))
                  .add(new GradientGlyphDrawEntry(fArray[i - n3], f2, n, n2, wvyq9n2, f));
            }
         }
      }

      this.b(matrix4f);
      RenderSystem.disableBlend();
      this.c.clear();
      matrixStack.pop();
   }

   private Color a(Color color, Color color2, float f) {
      return new Color(
         (int)(color.getRed() + (color2.getRed() - color.getRed()) * f),
         (int)(color.getGreen() + (color2.getGreen() - color.getGreen()) * f),
         (int)(color.getBlue() + (color2.getBlue() - color.getBlue()) * f),
         (int)(color.getAlpha() + (color2.getAlpha() - color.getAlpha()) * f)
      );
   }

   public void a(Font font) {
      this.e = font;
   }

   private void a(Matrix4f matrix4f) {
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      ObjectIterator var2 = this.b.keySet().iterator();

      while (var2.hasNext()) {
         Identifier identifier = (Identifier)var2.next();
         RenderSystem.setShaderTexture(0, identifier);
         GL11.glTexParameteri(3553, 10241, 9728);
         GL11.glTexParameteri(3553, 10240, 9728);
         BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
         ObjectListIterator var5 = ((ObjectList)(Object)this.b.get(identifier)).iterator();

         while (var5.hasNext()) {
            GlyphDrawEntry as21iw2 = (GlyphDrawEntry)var5.next();
            float f = as21iw2.a();
            float f2 = as21iw2.b();
            FontGlyph wvyq9n2 = as21iw2.d();
            FontAtlas ahdbxt2 = wvyq9n2.f();
            float f3 = wvyq9n2.c();
            float f4 = wvyq9n2.d();
            float f5 = (float)wvyq9n2.a() / ahdbxt2.b;
            float f6 = (float)wvyq9n2.b() / ahdbxt2.c;
            float f7 = (float)(wvyq9n2.a() + wvyq9n2.c()) / ahdbxt2.b;
            float f8 = (float)(wvyq9n2.b() + wvyq9n2.d()) / ahdbxt2.c;
            int n = as21iw2.c();
            bufferBuilder.vertex(matrix4f, f, f2 + f4, 0.0F).texture(f5, f8).color(n);
            bufferBuilder.vertex(matrix4f, f + f3, f2 + f4, 0.0F).texture(f7, f8).color(n);
            bufferBuilder.vertex(matrix4f, f + f3, f2, 0.0F).texture(f7, f6).color(n);
            bufferBuilder.vertex(matrix4f, f, f2, 0.0F).texture(f5, f6).color(n);
         }

         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      }
   }

   public void a(MatrixStack matrixStack, String string, double d, double d2, int n) {
      matrixStack.push();
      matrixStack.translate(Math.round(d * 2.0) / 2.0, Math.round(d2 * 2.0) / 2.0, 0.0);
      matrixStack.scale(0.5F, 0.5F, 0.5F);
      RenderSystem.enableBlend();
      FramebufferCapture.applyBlendState();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      char[] cArray = string.toCharArray();
      float[] fArray = this.c(string);
      float f = 0.0F;
      int n2 = 0;

      for (int i = 0; i < cArray.length; i++) {
         char c = cArray[i];
         if (c == '\n') {
            f += this.b(string.substring(n2, i)) - 2.0F;
            n2 = i + 1;
            if (n2 < cArray.length) {
               fArray = this.c(string.substring(n2));
            }
         } else {
            FontGlyph wvyq9n2 = this.b(c);
            if (wvyq9n2 != null && wvyq9n2.e() != ' ') {
               ((ObjectList)(Object)this.b.computeIfAbsent(wvyq9n2.f().a, key -> new ObjectArrayList())).add(new GlyphDrawEntry(fArray[i - n2], f, n, wvyq9n2));
            }
         }
      }

      this.a(matrix4f);
      RenderSystem.disableBlend();
      this.b.clear();
      matrixStack.pop();
   }

   public void a(String string, double d, double d2, Color color, Color color2, MatrixStack matrixStack) {
      this.a(matrixStack, string, d, d2, color.getRGB(), color2.getRGB(), this.b(string));
   }

   public void a(String string, double d, double d2, Color color, MatrixStack matrixStack) {
      this.a(matrixStack, string, d, d2, color.getRGB());
   }

   private static String $sf$0(String string) {
      int n = 259;
      return "temp/" + string;
   }
}
