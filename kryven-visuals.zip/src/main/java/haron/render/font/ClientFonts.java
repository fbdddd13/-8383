package haron.render.font;

import java.awt.Font;
import java.awt.FontFormatException;
import java.io.IOException;
import java.io.InputStream;

public class ClientFonts {
   public static final FontRenderer[] REGULAR = new FontRenderer[65];
   public static final FontRenderer[] MEDIUM;
   public static final FontRenderer[] ICONS;
   public static final FontRenderer[] PULSE_ICONS;
   public static final FontRenderer[] SMALL_ICONS;
   public static final FontRenderer[] a;
   public static final FontRenderer[] b;
   public static final FontRenderer[] c;
   public static final FontRenderer[] d;
   public static final FontRenderer[] e;

   private static FontRenderer load(float f, String string) {
      try {
         InputStream inputStream = ClientFonts.class.getResourceAsStream("/assets/haron/font/".concat(string));

         try {
            assert inputStream != null;
            FontRenderer v6hnga2 = new FontRenderer(Font.createFont(0, inputStream).deriveFont(0, f / 2.0F), f / 2.0F);
            if (inputStream != null) {
               inputStream.close();
            }

            return v6hnga2;
         } catch (Throwable throwable) {
            if (inputStream != null) {
               try {
                  inputStream.close();
               } catch (Throwable throwable2) {
                  throwable.addSuppressed(throwable2);
               }
            }

            throw throwable;
         }
      } catch (FontFormatException | IOException exception) {
         throw new RuntimeException(exception);
      }
   }

   static {
      for (int n = 6; n < 65; n++) {
         REGULAR[n] = load(n, "sfprodisplayregular.ttf");
      }

      MEDIUM = new FontRenderer[65];

      for (int var1 = 6; var1 < 65; var1++) {
         MEDIUM[var1] = load(var1, "sfprodisplay-medium-test.ttf");
      }

      ICONS = new FontRenderer[65];

      for (int var2 = 6; var2 < 65; var2++) {
         ICONS[var2] = load(var2, "icons.ttf");
      }

      PULSE_ICONS = new FontRenderer[265];

      for (int var3 = 6; var3 < 265; var3++) {
         PULSE_ICONS[var3] = load(var3, "pulseicon.ttf");
      }

      SMALL_ICONS = new FontRenderer[65];

      for (int var4 = 6; var4 < 65; var4++) {
         SMALL_ICONS[var4] = load(var4, "pulse_icons.ttf");
      }

      a = REGULAR;
      b = MEDIUM;
      c = ICONS;
      d = PULSE_ICONS;
      e = SMALL_ICONS;
   }
}
