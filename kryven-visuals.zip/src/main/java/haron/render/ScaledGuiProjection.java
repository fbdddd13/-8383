package haron.render;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.client.MinecraftClientAccess;
import com.mojang.blaze3d.systems.ProjectionType;
import net.minecraft.client.util.Window;
import org.joml.Matrix4f;

public final class ScaledGuiProjection implements MinecraftClientAccess {
   private static float e = 1.0F;
   private static Matrix4f f;
   private static Matrix4f g;
   public static int a;
   public static boolean b;

   public static void b(float f, float f2, float f3) {
      RenderSystem.getModelViewStack().translate(f, f2, f3);
   }

   public static void b() {
      RenderSystem.getModelViewStack().pushMatrix();
   }

   public static void c() {
      RenderSystem.getModelViewStack().popMatrix();
   }

   public static float d() {
      return e;
   }

   public static void a() {
      RenderSystem.getModelViewStack().popMatrix();
      RenderSystem.setProjectionMatrix(f, ProjectionType.ORTHOGRAPHIC);
      e = (float)c.getWindow().getScaleFactor();
   }

   public static ScreenPoint a(int n, int n2) {
      double d = c.getWindow().getScaleFactor();
      return new ScreenPoint((int)(n * d / 2.0), (int)(n2 * d / 2.0));
   }

   public static ScreenPoint a(double d, double d2) {
      double d3 = c.getWindow().getScaleFactor();
      return new ScreenPoint((int)(d * d3 / 2.0), (int)(d2 * d3 / 2.0));
   }

   public static void a(double d) {
      e = (float)d;
      Window window = c.getWindow();
      f = new Matrix4f(RenderSystem.getProjectionMatrix());
      g = new Matrix4f(RenderSystem.getModelViewMatrix());
      RenderSystem.setProjectionMatrix(
         new Matrix4f().setOrtho(0.0F, (float)(window.getFramebufferWidth() / d), (float)(window.getFramebufferHeight() / d), 0.0F, 1000.0F, 21000.0F), ProjectionType.ORTHOGRAPHIC
      );
      RenderSystem.getModelViewStack().pushMatrix();
      RenderSystem.getModelViewStack().identity();
      RenderSystem.getModelViewStack().translate(0.0F, 0.0F, -11000.0F);
   }

   public static void a(float f, float f2, float f3) {
      RenderSystem.getModelViewStack().scale(f, f2, f3);
   }
}
