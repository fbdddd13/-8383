package haron.render;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.FloatBuffer;
import java.util.Objects;
import java.util.stream.Collectors;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public class SkyShaderProgram {
   private static final SkyShaderProgram INSTANCE = new SkyShaderProgram();
   private int programId = -1;
   private int vaoId = -1;
   private int vboId = -1;
   private boolean initFailed = false;
   private int uTime;
   private int uSpeed;
   private int uDensity;
   private int uScale;
   private int uSkyColor;
   private int uScreenSize;
   private int uCamYaw;
   private int uCamPitch;
   private int uCamFov;
   private int uSkyMode;
   private final float startTime = (float)System.nanoTime() / 1.0E9F;

   public void render(float f, float f2, float f3, Color color, float f4, float f5, float f6, int n) {
      this.init();
      if (!this.initFailed && this.programId != -1) {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         int n2 = minecraftClient.getWindow().getFramebufferWidth();
         int n3 = minecraftClient.getWindow().getFramebufferHeight();
         boolean bl = GL11.glIsEnabled(2929);
         boolean bl2 = GL11.glIsEnabled(3042);
         boolean bl3 = GL11.glGetBoolean(2930);
         int n4 = GL11.glGetInteger(2932);
         int n5 = GL11.glGetInteger(35725);
         GL11.glEnable(2929);
         GL11.glDepthFunc(515);
         GL11.glDepthMask(false);
         GL11.glDisable(3042);
         GL20.glUseProgram(this.programId);
         float f7 = (float)System.nanoTime() / 1.0E9F - this.startTime;
         GL20.glUniform1f(this.uTime, f7);
         GL20.glUniform1f(this.uSpeed, f);
         GL20.glUniform1f(this.uDensity, f2);
         GL20.glUniform1f(this.uScale, f3);
         GL20.glUniform3f(this.uSkyColor, color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F);
         GL20.glUniform2f(this.uScreenSize, n2, n3);
         GL20.glUniform1f(this.uCamYaw, (float)Math.toRadians(f4));
         GL20.glUniform1f(this.uCamPitch, (float)Math.toRadians(f5));
         GL20.glUniform1f(this.uCamFov, (float)Math.toRadians(f6));
         GL20.glUniform1i(this.uSkyMode, n);
         GL30.glBindVertexArray(this.vaoId);
         GL11.glDrawArrays(4, 0, 3);
         GL30.glBindVertexArray(0);
         GL20.glUseProgram(n5);
         GL11.glDepthFunc(n4);
         GL11.glDepthMask(bl3);
         if (!bl) {
            GL11.glDisable(2929);
         }

         if (bl2) {
            GL11.glEnable(3042);
         }
      }
   }

   private int compileShader(int n, String string) {
      int n2 = GL20.glCreateShader(n);
      GL20.glShaderSource(n2, this.readShaderSource(string));
      GL20.glCompileShader(n2);
      if (GL20.glGetShaderi(n2, 35713) == 0) {
         System.err.println($sf$2(string, GL20.glGetShaderInfoLog(n2)));
      }

      return n2;
   }

   private String readShaderSource(String string) {
      try {
         BufferedReader bufferedReader = new BufferedReader(
            new InputStreamReader(Objects.requireNonNull(SkyShaderProgram.class.getResourceAsStream($sf$3(string))))
         );
         String string2 = bufferedReader.lines().collect(Collectors.joining("\n"));
         bufferedReader.close();
         return string2;
      } catch (IOException iOException) {
         throw new RuntimeException($sf$4(string), iOException);
      }
   }

   public static SkyShaderProgram get() {
      return INSTANCE;
   }

   private void init() {
      if (this.programId == -1 && !this.initFailed) {
         try {
            int n = this.compileShader(35633, "sky_shader.vert");
            int n2 = this.compileShader(35632, "sky_shader.frag");
            this.programId = GL20.glCreateProgram();
            GL20.glAttachShader(this.programId, n);
            GL20.glAttachShader(this.programId, n2);
            GL20.glLinkProgram(this.programId);
            if (GL20.glGetProgrami(this.programId, 35714) == 0) {
               System.err.println($sf$0(GL20.glGetProgramInfoLog(this.programId)));
               this.initFailed = true;
               return;
            }

            GL20.glDeleteShader(n);
            GL20.glDeleteShader(n2);
            this.uTime = GL20.glGetUniformLocation(this.programId, "Time");
            this.uSpeed = GL20.glGetUniformLocation(this.programId, "Speed");
            this.uDensity = GL20.glGetUniformLocation(this.programId, "Density");
            this.uScale = GL20.glGetUniformLocation(this.programId, "Scale");
            this.uSkyColor = GL20.glGetUniformLocation(this.programId, "SkyColor");
            this.uScreenSize = GL20.glGetUniformLocation(this.programId, "ScreenSize");
            this.uCamYaw = GL20.glGetUniformLocation(this.programId, "CamYaw");
            this.uCamPitch = GL20.glGetUniformLocation(this.programId, "CamPitch");
            this.uCamFov = GL20.glGetUniformLocation(this.programId, "CamFovRad");
            this.uSkyMode = GL20.glGetUniformLocation(this.programId, "SkyMode");
            float[] fArray = new float[]{-1.0F, -1.0F, 3.0F, -1.0F, -1.0F, 3.0F};
            this.vaoId = GL30.glGenVertexArrays();
            GL30.glBindVertexArray(this.vaoId);
            this.vboId = GL15.glGenBuffers();
            GL15.glBindBuffer(34962, this.vboId);
            FloatBuffer floatBuffer = BufferUtils.createFloatBuffer(fArray.length);
            floatBuffer.put(fArray).flip();
            GL15.glBufferData(34962, floatBuffer, 35044);
            GL20.glVertexAttribPointer(0, 2, 5126, false, 0, 0L);
            GL20.glEnableVertexAttribArray(0);
            GL30.glBindVertexArray(0);
            GL15.glBindBuffer(34962, 0);
         } catch (Exception exception) {
            System.err.println($sf$1(String.valueOf(exception)));
            this.initFailed = true;
         }
      }
   }

   private static String $sf$0(String string) {
      return "[Kryven] SkyShader link failed: " + string;
   }

   private static String $sf$4(String string) {
      return "Failed to load shader source: " + string;
   }

   private static String $sf$3(String string) {
      return "/assets/haron/shaders/" + string;
   }

   private static String $sf$1(String string) {
      return "[Kryven] SkyShader init failed: " + string;
   }

   private static String $sf$2(String string, String string2) {
      return "[Kryven] SkyShader compile failed (" + string + "): " + string2;
   }
}
