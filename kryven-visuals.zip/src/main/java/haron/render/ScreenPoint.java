package haron.render;

public record ScreenPoint(int x, int y) {
}
