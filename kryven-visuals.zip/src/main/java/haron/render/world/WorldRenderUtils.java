package haron.render.world;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.client.MinecraftClientAccess;
import java.util.HashSet;
import java.util.Iterator;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.client.render.VertexFormat;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

public final class WorldRenderUtils implements MinecraftClientAccess {
   private static final Tessellator e = Tessellator.getInstance();
   private static final Identifier f = Identifier.of("haron", "textures/bloom.png");
   public static int a;
   public static boolean b;

   public static void drawBillboardGlow(MatrixStack matrices, Vec3d position, float size, int color) {
      a(matrices, position, size, color);
   }

   public static void drawTexturedBillboard(
      MatrixStack matrices, Vec3d position, float size, int color, Identifier texture, float rotationDegrees, boolean visibleThroughWalls
   ) {
      a(matrices, position, size, color, texture, rotationDegrees, visibleThroughWalls);
   }

   private WorldRenderUtils() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static void b(MatrixStack matrixStack, Box box, int n) {
      matrixStack.push();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.disableCull();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      Tessellator tessellator = Tessellator.getInstance();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      Vec3d vec3d = c.gameRenderer.getCamera().getPos();
      double d = box.minX - vec3d.x;
      double d2 = box.minY - vec3d.y;
      double d3 = box.minZ - vec3d.z;
      double d4 = box.maxX - vec3d.x;
      double d5 = box.maxY - vec3d.y;
      double d6 = box.maxZ - vec3d.z;
      int n2 = n >> 16;
      float f = ((~n2 | 0xFF) - ~n2) / 255.0F;
      int n3 = n >> 8;
      float f2 = ((~n3 | 0xFF) - ~n3) / 255.0F;
      float f3 = ((~n | 0xFF) - ~n) / 255.0F;
      int n4 = n >> 24;
      float f4 = ((~n4 | 0xFF) - ~n4) / 255.0F;
      if (f4 == 0.0F) {
         f4 = 1.0F;
      }

      float f5 = f4 * 0.11F;
      BufferBuilder bufferBuilder = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d3).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d6).color(f, f2, f3, f5);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d5, (float)d3).color(f, f2, f3, f5);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      GL11.glEnable(10754);
      GL11.glPolygonOffset(-1.0F, -1.0F);
      RenderSystem.lineWidth(1.5F);
      BufferBuilder bufferBuilder2 = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
      bufferBuilder2.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f4);
      bufferBuilder2.vertex(matrix4f, (float)d4, (float)d2, (float)d3).color(f, f2, f3, f4);
      bufferBuilder2.vertex(matrix4f, (float)d4, (float)d2, (float)d6).color(f, f2, f3, f4);
      bufferBuilder2.vertex(matrix4f, (float)d, (float)d2, (float)d6).color(f, f2, f3, f4);
      bufferBuilder2.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f4);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
      BufferBuilder bufferBuilder3 = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
      bufferBuilder3.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f4);
      bufferBuilder3.vertex(matrix4f, (float)d4, (float)d5, (float)d3).color(f, f2, f3, f4);
      bufferBuilder3.vertex(matrix4f, (float)d4, (float)d5, (float)d6).color(f, f2, f3, f4);
      bufferBuilder3.vertex(matrix4f, (float)d, (float)d5, (float)d6).color(f, f2, f3, f4);
      bufferBuilder3.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f4);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder3.end());
      BufferBuilder bufferBuilder4 = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
      bufferBuilder4.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f4);
      bufferBuilder4.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f4);
      bufferBuilder4.vertex(matrix4f, (float)d4, (float)d2, (float)d3).color(f, f2, f3, f4);
      bufferBuilder4.vertex(matrix4f, (float)d4, (float)d5, (float)d3).color(f, f2, f3, f4);
      bufferBuilder4.vertex(matrix4f, (float)d4, (float)d2, (float)d6).color(f, f2, f3, f4);
      bufferBuilder4.vertex(matrix4f, (float)d4, (float)d5, (float)d6).color(f, f2, f3, f4);
      bufferBuilder4.vertex(matrix4f, (float)d, (float)d2, (float)d6).color(f, f2, f3, f4);
      bufferBuilder4.vertex(matrix4f, (float)d, (float)d5, (float)d6).color(f, f2, f3, f4);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder4.end());
      GL11.glPolygonOffset(0.0F, 0.0F);
      GL11.glDisable(10754);
      RenderSystem.lineWidth(1.0F);
      RenderSystem.disableBlend();
      matrixStack.pop();
   }

   public static void b(MatrixStack matrixStack, Iterable<BlockPos> iterable, int n) {
      matrixStack.push();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.disableCull();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      Tessellator tessellator = Tessellator.getInstance();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      Vec3d vec3d = c.gameRenderer.getCamera().getPos();
      int n2 = n >> 16;
      float f12 = ((~n2 | 0xFF) - ~n2) / 255.0F;
      int n3 = n >> 8;
      float f13 = ((~n3 | 0xFF) - ~n3) / 255.0F;
      float f14 = ((~n | 0xFF) - ~n) / 255.0F;
      int n4 = n >> 24;
      float f15 = ((~n4 | 0xFF) - ~n4) / 255.0F;
      if (f15 == 0.0F) {
         f15 = 1.0F;
      }

      float f16 = f15 * 0.2F;
      HashSet<BlockPos> hashSet = new HashSet<>();
      int n5 = Integer.MAX_VALUE;
      int n6 = Integer.MAX_VALUE;
      int n7 = Integer.MAX_VALUE;
      int n8 = Integer.MIN_VALUE;
      int n9 = Integer.MIN_VALUE;
      int n10 = Integer.MIN_VALUE;

      for (BlockPos object2 : iterable) {
         hashSet.add(object2);
         n5 = Math.min(n5, object2.getX());
         n6 = Math.min(n6, object2.getY());
         n7 = Math.min(n7, object2.getZ());
         n8 = Math.max(n8, object2.getX());
         n9 = Math.max(n9, object2.getY());
         n10 = Math.max(n10, object2.getZ());
      }

      BufferBuilder bufferBuilder = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

      for (BlockPos blockPos : hashSet) {
         float f17 = blockPos.getX() != n5 ? 0.0F : 0.01F;
         float f11 = blockPos.getY() != n6 ? 0.0F : 0.01F;
         float f10 = blockPos.getZ() != n7 ? 0.0F : 0.01F;
         float f18 = blockPos.getX() != n8 ? 0.0F : 0.01F;
         float f9 = f18;
         float f19 = blockPos.getY() != n9 ? 0.0F : 0.01F;
         float f8 = f19;
         float f7 = blockPos.getZ() != n10 ? 0.0F : 0.01F;
         float f6 = blockPos.getX() - (float)vec3d.x + f17;
         float f5 = blockPos.getY() - (float)vec3d.y + f11;
         float f4 = blockPos.getZ() - (float)vec3d.z + f10;
         float f3 = f6 + 1.0F - f17 - f9;
         float f2 = f5 + 1.0F - f11 - f8;
         float f = f4 + 1.0F - f10 - f7;
         if (!hashSet.contains(blockPos.down())) {
            bufferBuilder.vertex(matrix4f, f6, f5, f4).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f3, f5, f4).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f3, f5, f).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f6, f5, f).color(f12, f13, f14, f16);
         }

         if (!hashSet.contains(blockPos.up())) {
            bufferBuilder.vertex(matrix4f, f6, f2, f4).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f6, f2, f).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f3, f2, f).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f3, f2, f4).color(f12, f13, f14, f16);
         }

         if (!hashSet.contains(blockPos.north())) {
            bufferBuilder.vertex(matrix4f, f6, f5, f4).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f6, f2, f4).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f3, f2, f4).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f3, f5, f4).color(f12, f13, f14, f16);
         }

         if (!hashSet.contains(blockPos.south())) {
            bufferBuilder.vertex(matrix4f, f6, f5, f).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f3, f5, f).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f3, f2, f).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f6, f2, f).color(f12, f13, f14, f16);
         }

         if (!hashSet.contains(blockPos.west())) {
            bufferBuilder.vertex(matrix4f, f6, f5, f4).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f6, f5, f).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f6, f2, f).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f6, f2, f4).color(f12, f13, f14, f16);
         }

         if (!hashSet.contains(blockPos.east())) {
            bufferBuilder.vertex(matrix4f, f3, f5, f4).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f3, f2, f4).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f3, f2, f).color(f12, f13, f14, f16);
            bufferBuilder.vertex(matrix4f, f3, f5, f).color(f12, f13, f14, f16);
         }
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      GL11.glEnable(10754);
      GL11.glPolygonOffset(-1.0F, -1.0F);
      RenderSystem.lineWidth(1.5F);
      BufferBuilder bufferBuilder2 = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

      for (BlockPos blockPos : hashSet) {
         float f11 = blockPos.getX() != n5 ? 0.0F : 0.01F;
         float f10 = blockPos.getY() != n6 ? 0.0F : 0.01F;
         float f9 = blockPos.getZ() != n7 ? 0.0F : 0.01F;
         float f8 = blockPos.getX() != n8 ? 0.0F : 0.01F;
         float f7 = blockPos.getY() != n9 ? 0.0F : 0.01F;
         float f20 = blockPos.getZ() != n10 ? 0.0F : 0.01F;
         float f6 = blockPos.getX() - (float)vec3d.x + f11;
         float f5 = blockPos.getY() - (float)vec3d.y + f10;
         float f4 = blockPos.getZ() - (float)vec3d.z + f9;
         float f3 = f6 + 1.0F - f11 - f8;
         float f2 = f5 + 1.0F - f10 - f7;
         float f = f4 + 1.0F - f9 - f20;
         if (!hashSet.contains(blockPos.down())) {
            if (!hashSet.contains(blockPos.west())) {
               bufferBuilder2.vertex(matrix4f, f6, f5, f4).color(f12, f13, f14, f15);
               bufferBuilder2.vertex(matrix4f, f6, f5, f).color(f12, f13, f14, f15);
            }

            if (!hashSet.contains(blockPos.east())) {
               bufferBuilder2.vertex(matrix4f, f3, f5, f4).color(f12, f13, f14, f15);
               bufferBuilder2.vertex(matrix4f, f3, f5, f).color(f12, f13, f14, f15);
            }

            if (!hashSet.contains(blockPos.north())) {
               bufferBuilder2.vertex(matrix4f, f6, f5, f4).color(f12, f13, f14, f15);
               bufferBuilder2.vertex(matrix4f, f3, f5, f4).color(f12, f13, f14, f15);
            }

            if (!hashSet.contains(blockPos.south())) {
               bufferBuilder2.vertex(matrix4f, f6, f5, f).color(f12, f13, f14, f15);
               bufferBuilder2.vertex(matrix4f, f3, f5, f).color(f12, f13, f14, f15);
            }
         }

         if (!hashSet.contains(blockPos.up())) {
            if (!hashSet.contains(blockPos.west())) {
               bufferBuilder2.vertex(matrix4f, f6, f2, f4).color(f12, f13, f14, f15);
               bufferBuilder2.vertex(matrix4f, f6, f2, f).color(f12, f13, f14, f15);
            }

            if (!hashSet.contains(blockPos.east())) {
               bufferBuilder2.vertex(matrix4f, f3, f2, f4).color(f12, f13, f14, f15);
               bufferBuilder2.vertex(matrix4f, f3, f2, f).color(f12, f13, f14, f15);
            }

            if (!hashSet.contains(blockPos.north())) {
               bufferBuilder2.vertex(matrix4f, f6, f2, f4).color(f12, f13, f14, f15);
               bufferBuilder2.vertex(matrix4f, f3, f2, f4).color(f12, f13, f14, f15);
            }

            if (!hashSet.contains(blockPos.south())) {
               bufferBuilder2.vertex(matrix4f, f6, f2, f).color(f12, f13, f14, f15);
               bufferBuilder2.vertex(matrix4f, f3, f2, f).color(f12, f13, f14, f15);
            }
         }

         if (!hashSet.contains(blockPos.west()) && !hashSet.contains(blockPos.north())) {
            bufferBuilder2.vertex(matrix4f, f6, f5, f4).color(f12, f13, f14, f15);
            bufferBuilder2.vertex(matrix4f, f6, f2, f4).color(f12, f13, f14, f15);
         }

         if (!hashSet.contains(blockPos.east()) && !hashSet.contains(blockPos.north())) {
            bufferBuilder2.vertex(matrix4f, f3, f5, f4).color(f12, f13, f14, f15);
            bufferBuilder2.vertex(matrix4f, f3, f2, f4).color(f12, f13, f14, f15);
         }

         if (!hashSet.contains(blockPos.east()) && !hashSet.contains(blockPos.south())) {
            bufferBuilder2.vertex(matrix4f, f3, f5, f).color(f12, f13, f14, f15);
            bufferBuilder2.vertex(matrix4f, f3, f2, f).color(f12, f13, f14, f15);
         }

         if (!hashSet.contains(blockPos.west()) && !hashSet.contains(blockPos.south())) {
            bufferBuilder2.vertex(matrix4f, f6, f5, f).color(f12, f13, f14, f15);
            bufferBuilder2.vertex(matrix4f, f6, f2, f).color(f12, f13, f14, f15);
         }

         if (!hashSet.contains(blockPos.west())
            && hashSet.contains(blockPos.north())
            && !hashSet.contains(blockPos.west().north())) {
            bufferBuilder2.vertex(matrix4f, f6, f5, f4).color(f12, f13, f14, f15);
            bufferBuilder2.vertex(matrix4f, f6, f2, f4).color(f12, f13, f14, f15);
         }

         if (!hashSet.contains(blockPos.north())
            && hashSet.contains(blockPos.west())
            && !hashSet.contains(blockPos.north().west())) {
            bufferBuilder2.vertex(matrix4f, f6, f5, f4).color(f12, f13, f14, f15);
            bufferBuilder2.vertex(matrix4f, f6, f2, f4).color(f12, f13, f14, f15);
         }

         if (!hashSet.contains(blockPos.east())) {
            if (hashSet.contains(blockPos.north())) {
               if (!hashSet.contains(blockPos.east().north())) {
                  bufferBuilder2.vertex(matrix4f, f3, f5, f4).color(f12, f13, f14, f15);
                  bufferBuilder2.vertex(matrix4f, f3, f2, f4).color(f12, f13, f14, f15);
               }
            } else if (b) {
            }
         }

         if (!hashSet.contains(blockPos.north())) {
            if (hashSet.contains(blockPos.east())) {
               if (!hashSet.contains(blockPos.north().east())) {
                  bufferBuilder2.vertex(matrix4f, f3, f5, f4).color(f12, f13, f14, f15);
                  bufferBuilder2.vertex(matrix4f, f3, f2, f4).color(f12, f13, f14, f15);
               }
            } else if (b) {
            }
         }

         if (!hashSet.contains(blockPos.east())
            && hashSet.contains(blockPos.south())
            && !hashSet.contains(blockPos.east().south())) {
            bufferBuilder2.vertex(matrix4f, f3, f5, f).color(f12, f13, f14, f15);
            bufferBuilder2.vertex(matrix4f, f3, f2, f).color(f12, f13, f14, f15);
         }

         if (!hashSet.contains(blockPos.south())
            && hashSet.contains(blockPos.east())
            && !hashSet.contains(blockPos.south().east())) {
            bufferBuilder2.vertex(matrix4f, f3, f5, f).color(f12, f13, f14, f15);
            bufferBuilder2.vertex(matrix4f, f3, f2, f).color(f12, f13, f14, f15);
         }

         if (!hashSet.contains(blockPos.west())
            && hashSet.contains(blockPos.south())
            && !hashSet.contains(blockPos.west().south())) {
            bufferBuilder2.vertex(matrix4f, f6, f5, f).color(f12, f13, f14, f15);
            bufferBuilder2.vertex(matrix4f, f6, f2, f).color(f12, f13, f14, f15);
         }

         if (!hashSet.contains(blockPos.south())
            && hashSet.contains(blockPos.west())
            && !hashSet.contains(blockPos.south().west())) {
            bufferBuilder2.vertex(matrix4f, f6, f5, f).color(f12, f13, f14, f15);
            bufferBuilder2.vertex(matrix4f, f6, f2, f).color(f12, f13, f14, f15);
         }
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
      GL11.glPolygonOffset(0.0F, 0.0F);
      GL11.glDisable(10754);
      RenderSystem.lineWidth(1.0F);
      RenderSystem.disableBlend();
      matrixStack.pop();
   }

   public static void a(MatrixStack matrixStack, Vec3d vec3d, float f, int n, int n2, float f2) {
      matrixStack.push();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(true);
      GL11.glEnable(10754);
      GL11.glPolygonOffset(-1.0F, -1.0F);
      RenderSystem.lineWidth(1.5F);
      Tessellator tessellator = Tessellator.getInstance();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      Vec3d vec3d2 = c.gameRenderer.getCamera().getPos();
      int n3 = n2 >> 16;
      float f3 = ((~n3 | 0xFF) - ~n3) / 255.0F;
      int n4 = n2 >> 8;
      float f4 = ((~n4 | 0xFF) - ~n4) / 255.0F;
      float f5 = ((~n2 | 0xFF) - ~n2) / 255.0F;
      int n5 = n2 >> 24;
      float f6 = ((~n5 | 0xFF) - ~n5) / 255.0F;
      if (f6 == 0.0F) {
         f6 = 1.0F;
      }

      BufferBuilder bufferBuilder = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);

      for (int i = 0; i <= n; i++) {
         double d = (Math.PI * 2) * i / n;
         bufferBuilder.vertex(
               matrix4f,
               (float)(vec3d.x + f * Math.cos(d) - vec3d2.x),
               (float)(vec3d.y + f2 + 1.0 - vec3d2.y),
               (float)(vec3d.z + f * Math.sin(d) - vec3d2.z)
            )
            .color(f3, f4, f5, f6);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      GL11.glPolygonOffset(0.0F, 0.0F);
      GL11.glDisable(10754);
      RenderSystem.lineWidth(1.0F);
      RenderSystem.disableBlend();
      matrixStack.pop();
   }

   public static void a(MatrixStack matrixStack, Box box, int n) {
      matrixStack.push();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(true);
      GL11.glEnable(10754);
      GL11.glPolygonOffset(-1.0F, -1.0F);
      RenderSystem.lineWidth(1.5F);
      Tessellator tessellator = Tessellator.getInstance();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      Vec3d vec3d = c.gameRenderer.getCamera().getPos();
      double d = box.minX - vec3d.x;
      double d2 = box.minY - vec3d.y;
      double d3 = box.minZ - vec3d.z;
      double d4 = box.maxX - vec3d.x;
      double d5 = box.maxY - vec3d.y;
      double d6 = box.maxZ - vec3d.z;
      int n2 = n >> 16;
      float f = ((~n2 | 0xFF) - ~n2) / 255.0F;
      int n3 = n >> 8;
      float f2 = ((~n3 | 0xFF) - ~n3) / 255.0F;
      float f3 = ((~n | 0xFF) - ~n) / 255.0F;
      int n4 = n >> 24;
      float f4 = ((~n4 | 0xFF) - ~n4) / 255.0F;
      if (f4 == 0.0F) {
         f4 = 1.0F;
      }

      BufferBuilder bufferBuilder = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f4);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d3).color(f, f2, f3, f4);
      bufferBuilder.vertex(matrix4f, (float)d4, (float)d2, (float)d6).color(f, f2, f3, f4);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d6).color(f, f2, f3, f4);
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f4);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      BufferBuilder bufferBuilder2 = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
      bufferBuilder2.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f4);
      bufferBuilder2.vertex(matrix4f, (float)d4, (float)d5, (float)d3).color(f, f2, f3, f4);
      bufferBuilder2.vertex(matrix4f, (float)d4, (float)d5, (float)d6).color(f, f2, f3, f4);
      bufferBuilder2.vertex(matrix4f, (float)d, (float)d5, (float)d6).color(f, f2, f3, f4);
      bufferBuilder2.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f4);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
      BufferBuilder bufferBuilder3 = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
      bufferBuilder3.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f, f2, f3, f4);
      bufferBuilder3.vertex(matrix4f, (float)d, (float)d5, (float)d3).color(f, f2, f3, f4);
      bufferBuilder3.vertex(matrix4f, (float)d4, (float)d2, (float)d3).color(f, f2, f3, f4);
      bufferBuilder3.vertex(matrix4f, (float)d4, (float)d5, (float)d3).color(f, f2, f3, f4);
      bufferBuilder3.vertex(matrix4f, (float)d4, (float)d2, (float)d6).color(f, f2, f3, f4);
      bufferBuilder3.vertex(matrix4f, (float)d4, (float)d5, (float)d6).color(f, f2, f3, f4);
      bufferBuilder3.vertex(matrix4f, (float)d, (float)d2, (float)d6).color(f, f2, f3, f4);
      bufferBuilder3.vertex(matrix4f, (float)d, (float)d5, (float)d6).color(f, f2, f3, f4);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder3.end());
      GL11.glPolygonOffset(0.0F, 0.0F);
      GL11.glDisable(10754);
      RenderSystem.lineWidth(1.0F);
      RenderSystem.disableBlend();
      matrixStack.pop();
   }

   public static void a(MatrixStack matrixStack, Vec3d vec3d, float f, int n) {
      RenderSystem.setShaderTexture(0, WorldRenderUtils.f);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      matrixStack.push();
      RenderSystem.disableCull();
      GL11.glDepthMask(false);
      RenderSystem.enableBlend();
      int n2 = n >> 16;
      int n3 = (~n2 | 0xFF) - ~n2;
      int n4 = n >> 8;
      int n5 = (~n4 | 0xFF) - ~n4;
      int n6 = (~n | 0xFF) - ~n;
      int n7 = n >> 24;
      int n8 = (~n7 | 0xFF) - ~n7;
      if (((n3 ^ n5) + 2 * (n3 & n5) - ~n6 - 1) / 765.0F >= 0.2F) {
         RenderSystem.blendFunc(770, 1);
         Vec3d vec3d2 = c.getEntityRenderDispatcher().camera.getPos();
         matrixStack.translate(-vec3d2.x + vec3d.x, -vec3d2.y + vec3d.y, -vec3d2.z + vec3d.z);
         matrixStack.multiply(c.getEntityRenderDispatcher().getRotation());
         matrixStack.scale(f, f, f);
         BufferBuilder bufferBuilder = e.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
         float f2 = n3 / 255.0F;
         float f3 = n5 / 255.0F;
         float f4 = n6 / 255.0F;
         float f5 = n8 / 255.0F;
         bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), -0.5F, -0.5F, 0.0F).texture(0.0F, 0.0F).color(f2, f3, f4, f5);
         bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), 0.5F, -0.5F, 0.0F).texture(1.0F, 0.0F).color(f2, f3, f4, f5);
         bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), 0.5F, 0.5F, 0.0F).texture(1.0F, 1.0F).color(f2, f3, f4, f5);
         bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), -0.5F, 0.5F, 0.0F).texture(0.0F, 1.0F).color(f2, f3, f4, f5);
         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
         RenderSystem.blendFunc(770, 771);
      } else {
         RenderSystem.blendFunc(770, 771);
         Vec3d vec3d3 = c.getEntityRenderDispatcher().camera.getPos();
         matrixStack.translate(-vec3d3.x + vec3d.x, -vec3d3.y + vec3d.y, -vec3d3.z + vec3d.z);
         matrixStack.multiply(c.getEntityRenderDispatcher().getRotation());
         matrixStack.scale(f * 1.2F, f * 1.2F, f * 1.2F);
         BufferBuilder bufferBuilder = e.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
         float f6 = n8 / 255.0F * 0.3F;
         bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), -0.5F, -0.5F, 0.0F).texture(0.0F, 0.0F).color(1.0F, 1.0F, 1.0F, f6);
         bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), 0.5F, -0.5F, 0.0F).texture(1.0F, 0.0F).color(1.0F, 1.0F, 1.0F, f6);
         bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), 0.5F, 0.5F, 0.0F).texture(1.0F, 1.0F).color(1.0F, 1.0F, 1.0F, f6);
         bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), -0.5F, 0.5F, 0.0F).texture(0.0F, 1.0F).color(1.0F, 1.0F, 1.0F, f6);
         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
         matrixStack.scale(0.8333333F, 0.8333333F, 0.8333333F);
         BufferBuilder bufferBuilder2 = e.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
         float f7 = n3 / 255.0F;
         float f8 = n5 / 255.0F;
         float f9 = n6 / 255.0F;
         float f10 = n8 / 255.0F;
         bufferBuilder2.vertex(matrixStack.peek().getPositionMatrix(), -0.5F, -0.5F, 0.0F).texture(0.0F, 0.0F).color(f7, f8, f9, f10);
         bufferBuilder2.vertex(matrixStack.peek().getPositionMatrix(), 0.5F, -0.5F, 0.0F).texture(1.0F, 0.0F).color(f7, f8, f9, f10);
         bufferBuilder2.vertex(matrixStack.peek().getPositionMatrix(), 0.5F, 0.5F, 0.0F).texture(1.0F, 1.0F).color(f7, f8, f9, f10);
         bufferBuilder2.vertex(matrixStack.peek().getPositionMatrix(), -0.5F, 0.5F, 0.0F).texture(0.0F, 1.0F).color(f7, f8, f9, f10);
         BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
      }

      GL11.glDepthMask(true);
      RenderSystem.enableCull();
      matrixStack.pop();
   }

   public static void a(MatrixStack matrixStack, Vec3d vec3d, float f, int n, Identifier identifier, float f2, boolean bl) {
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      RenderSystem.setShaderTexture(0, identifier);
      matrixStack.push();
      RenderSystem.disableCull();
      if (bl) {
         RenderSystem.disableDepthTest();
         GL11.glDepthMask(false);
      } else {
         GL11.glDepthMask(false);
      }

      RenderSystem.enableBlend();
      int n2 = n >> 16;
      int n3 = (~n2 | 0xFF) - ~n2;
      int n4 = n >> 8;
      int n5 = (~n4 | 0xFF) - ~n4;
      int n6 = n >> 24;
      int n7 = (~n6 | 0xFF) - ~n6;
      RenderSystem.blendFunc(770, 771);
      Vec3d vec3d2 = c.getEntityRenderDispatcher().camera.getPos();
      matrixStack.translate(-vec3d2.x + vec3d.x, -vec3d2.y + vec3d.y, -vec3d2.z + vec3d.z);
      matrixStack.multiply(c.getEntityRenderDispatcher().getRotation());
      matrixStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(f2));
      matrixStack.scale(f, f, f);
      BufferBuilder bufferBuilder = e.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
      float f3 = n3 / 255.0F;
      float f4 = n5 / 255.0F;
      float f5 = ((~n | 0xFF) - ~n) / 255.0F;
      float f6 = n7 / 255.0F;
      bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), -0.5F, -0.5F, 0.0F).texture(0.0F, 0.0F).color(f3, f4, f5, f6);
      bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), 0.5F, -0.5F, 0.0F).texture(1.0F, 0.0F).color(f3, f4, f5, f6);
      bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), 0.5F, 0.5F, 0.0F).texture(1.0F, 1.0F).color(f3, f4, f5, f6);
      bufferBuilder.vertex(matrixStack.peek().getPositionMatrix(), -0.5F, 0.5F, 0.0F).texture(0.0F, 1.0F).color(f3, f4, f5, f6);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      if (bl) {
         RenderSystem.enableDepthTest();
         GL11.glDepthMask(true);
      } else {
         GL11.glDepthMask(true);
      }

      RenderSystem.enableCull();
      matrixStack.pop();
   }

   public static void a(MatrixStack matrixStack, Vec3d vec3d, float f, int n, int n2) {
      matrixStack.push();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      Tessellator tessellator = Tessellator.getInstance();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      Vec3d vec3d2 = c.gameRenderer.getCamera().getPos();
      int n3 = n2 >> 16;
      float f2 = ((~n3 | 0xFF) - ~n3) / 255.0F;
      int n4 = n2 >> 8;
      float f3 = ((~n4 | 0xFF) - ~n4) / 255.0F;
      float f4 = ((~n2 | 0xFF) - ~n2) / 255.0F;
      int n5 = n2 >> 24;
      float f5 = ((~n5 | 0xFF) - ~n5) / 255.0F * 0.3F;
      BufferBuilder bufferBuilder = tessellator.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
      double d = vec3d.x - vec3d2.x;
      double d2 = vec3d.y - vec3d2.y;
      double d3 = vec3d.z - vec3d2.z;
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d3).color(f2, f3, f4, f5);

      for (int i = 0; i <= n; i++) {
         double d4 = (Math.PI * 2) * i / n;
         bufferBuilder.vertex(matrix4f, (float)(d + f * Math.cos(d4)), (float)d2, (float)(d3 + f * Math.sin(d4))).color(f2, f3, f4, f5);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(true);
      RenderSystem.disableBlend();
      matrixStack.pop();
   }

   public static void a(MatrixStack matrixStack, Iterable<BlockPos> iterable, int n) {
      matrixStack.push();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(true);
      GL11.glEnable(10754);
      GL11.glPolygonOffset(-1.0F, -1.0F);
      RenderSystem.lineWidth(1.5F);
      Tessellator tessellator = Tessellator.getInstance();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      Vec3d vec3d = c.gameRenderer.getCamera().getPos();
      int n2 = n >> 16;
      float f = ((~n2 | 0xFF) - ~n2) / 255.0F;
      int n3 = n >> 8;
      float f2 = ((~n3 | 0xFF) - ~n3) / 255.0F;
      float f3 = ((~n | 0xFF) - ~n) / 255.0F;
      int n4 = n >> 24;
      float f4 = ((~n4 | 0xFF) - ~n4) / 255.0F;
      if (f4 == 0.0F) {
         f4 = 1.0F;
      }

      HashSet<BlockPos> hashSet = new HashSet<>();
      Iterator<BlockPos> iterator = iterable.iterator();

      while (iterator.hasNext()) {
         hashSet.add(iterator.next());
      }

      BufferBuilder bufferBuilder = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

      for (BlockPos blockPos : hashSet) {
         float f5 = blockPos.getX() - (float)vec3d.x;
         float f6 = blockPos.getY() - (float)vec3d.y;
         float f7 = blockPos.getZ() - (float)vec3d.z;
         float f8 = f5 + 1.0F;
         float f9 = f6 + 1.0F;
         float f10 = f7 + 1.0F;
         if (!hashSet.contains(blockPos.down())) {
            if (!hashSet.contains(blockPos.west())) {
               bufferBuilder.vertex(matrix4f, f5, f6, f7).color(f, f2, f3, f4);
               bufferBuilder.vertex(matrix4f, f5, f6, f10).color(f, f2, f3, f4);
            }

            if (!hashSet.contains(blockPos.east())) {
               bufferBuilder.vertex(matrix4f, f8, f6, f7).color(f, f2, f3, f4);
               bufferBuilder.vertex(matrix4f, f8, f6, f10).color(f, f2, f3, f4);
            }

            if (!hashSet.contains(blockPos.north())) {
               bufferBuilder.vertex(matrix4f, f5, f6, f7).color(f, f2, f3, f4);
               bufferBuilder.vertex(matrix4f, f8, f6, f7).color(f, f2, f3, f4);
            }

            if (!hashSet.contains(blockPos.south())) {
               bufferBuilder.vertex(matrix4f, f5, f6, f10).color(f, f2, f3, f4);
               bufferBuilder.vertex(matrix4f, f8, f6, f10).color(f, f2, f3, f4);
            }
         }

         if (!hashSet.contains(blockPos.up())) {
            if (!hashSet.contains(blockPos.west())) {
               bufferBuilder.vertex(matrix4f, f5, f9, f7).color(f, f2, f3, f4);
               bufferBuilder.vertex(matrix4f, f5, f9, f10).color(f, f2, f3, f4);
            }

            if (!hashSet.contains(blockPos.east())) {
               bufferBuilder.vertex(matrix4f, f8, f9, f7).color(f, f2, f3, f4);
               bufferBuilder.vertex(matrix4f, f8, f9, f10).color(f, f2, f3, f4);
            }

            if (!hashSet.contains(blockPos.north())) {
               bufferBuilder.vertex(matrix4f, f5, f9, f7).color(f, f2, f3, f4);
               bufferBuilder.vertex(matrix4f, f8, f9, f7).color(f, f2, f3, f4);
            } else if (b) {
            }

            if (!hashSet.contains(blockPos.south())) {
               bufferBuilder.vertex(matrix4f, f5, f9, f10).color(f, f2, f3, f4);
               bufferBuilder.vertex(matrix4f, f8, f9, f10).color(f, f2, f3, f4);
            }
         }

         if (!hashSet.contains(blockPos.west()) && !hashSet.contains(blockPos.north())) {
            bufferBuilder.vertex(matrix4f, f5, f6, f7).color(f, f2, f3, f4);
            bufferBuilder.vertex(matrix4f, f5, f9, f7).color(f, f2, f3, f4);
         }

         if (!hashSet.contains(blockPos.east()) && !hashSet.contains(blockPos.north())) {
            bufferBuilder.vertex(matrix4f, f8, f6, f7).color(f, f2, f3, f4);
            bufferBuilder.vertex(matrix4f, f8, f9, f7).color(f, f2, f3, f4);
         }

         if (!hashSet.contains(blockPos.east()) && !hashSet.contains(blockPos.south())) {
            bufferBuilder.vertex(matrix4f, f8, f6, f10).color(f, f2, f3, f4);
            bufferBuilder.vertex(matrix4f, f8, f9, f10).color(f, f2, f3, f4);
         }

         if (!hashSet.contains(blockPos.west()) && !hashSet.contains(blockPos.south())) {
            bufferBuilder.vertex(matrix4f, f5, f6, f10).color(f, f2, f3, f4);
            bufferBuilder.vertex(matrix4f, f5, f9, f10).color(f, f2, f3, f4);
         }

         if (!hashSet.contains(blockPos.west())
            && hashSet.contains(blockPos.north())
            && !hashSet.contains(blockPos.west().north())) {
            bufferBuilder.vertex(matrix4f, f5, f6, f7).color(f, f2, f3, f4);
            bufferBuilder.vertex(matrix4f, f5, f9, f7).color(f, f2, f3, f4);
         }

         if (!hashSet.contains(blockPos.north())
            && hashSet.contains(blockPos.west())
            && !hashSet.contains(blockPos.north().west())) {
            bufferBuilder.vertex(matrix4f, f5, f6, f7).color(f, f2, f3, f4);
            bufferBuilder.vertex(matrix4f, f5, f9, f7).color(f, f2, f3, f4);
         }

         if (!hashSet.contains(blockPos.east())
            && hashSet.contains(blockPos.north())
            && !hashSet.contains(blockPos.east().north())) {
            bufferBuilder.vertex(matrix4f, f8, f6, f7).color(f, f2, f3, f4);
            bufferBuilder.vertex(matrix4f, f8, f9, f7).color(f, f2, f3, f4);
         }

         if (!hashSet.contains(blockPos.north())
            && hashSet.contains(blockPos.east())
            && !hashSet.contains(blockPos.north().east())) {
            bufferBuilder.vertex(matrix4f, f8, f6, f7).color(f, f2, f3, f4);
            bufferBuilder.vertex(matrix4f, f8, f9, f7).color(f, f2, f3, f4);
         }

         if (!hashSet.contains(blockPos.east())
            && hashSet.contains(blockPos.south())
            && !hashSet.contains(blockPos.east().south())) {
            bufferBuilder.vertex(matrix4f, f8, f6, f10).color(f, f2, f3, f4);
            bufferBuilder.vertex(matrix4f, f8, f9, f10).color(f, f2, f3, f4);
         }

         if (!hashSet.contains(blockPos.south())
            && hashSet.contains(blockPos.east())
            && !hashSet.contains(blockPos.south().east())) {
            bufferBuilder.vertex(matrix4f, f8, f6, f10).color(f, f2, f3, f4);
            bufferBuilder.vertex(matrix4f, f8, f9, f10).color(f, f2, f3, f4);
         }

         if (!hashSet.contains(blockPos.west())
            && hashSet.contains(blockPos.south())
            && !hashSet.contains(blockPos.west().south())) {
            bufferBuilder.vertex(matrix4f, f5, f6, f10).color(f, f2, f3, f4);
            bufferBuilder.vertex(matrix4f, f5, f9, f10).color(f, f2, f3, f4);
         }

         if (!hashSet.contains(blockPos.south())) {
            if (hashSet.contains(blockPos.west())) {
               if (!hashSet.contains(blockPos.south().west())) {
                  bufferBuilder.vertex(matrix4f, f5, f6, f10).color(f, f2, f3, f4);
                  bufferBuilder.vertex(matrix4f, f5, f9, f10).color(f, f2, f3, f4);
               }
            } else if (!b) {
            }
         }
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      GL11.glPolygonOffset(0.0F, 0.0F);
      GL11.glDisable(10754);
      RenderSystem.lineWidth(1.0F);
      RenderSystem.disableBlend();
      matrixStack.pop();
   }

   public static void a(MatrixStack matrixStack, Vec3d vec3d, float f, float f2, int n, int n2) {
      matrixStack.push();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.lineWidth(1.5F);
      a(matrixStack, vec3d, f, n, n2, 0.0F);
      a(matrixStack, vec3d, f, n, n2, f2);
      Tessellator tessellator = Tessellator.getInstance();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      Vec3d vec3d2 = c.gameRenderer.getCamera().getPos();
      int n3 = n2 >> 16;
      float f3 = ((~n3 | 0xFF) - ~n3) / 255.0F;
      int n4 = n2 >> 8;
      float f4 = ((~n4 | 0xFF) - ~n4) / 255.0F;
      float f5 = ((~n2 | 0xFF) - ~n2) / 255.0F;
      int n5 = n2 >> 24;
      float f6 = ((~n5 | 0xFF) - ~n5) / 255.0F;
      if (f6 == 0.0F) {
         f6 = 1.0F;
      }

      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      BufferBuilder bufferBuilder = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

      for (int i = 0; i < 8; i++) {
         double d = (Math.PI * 2) * i / 8.0;
         double d2 = vec3d.x + f * Math.cos(d) - vec3d2.x;
         double d3 = vec3d.z + f * Math.sin(d) - vec3d2.z;
         double d4 = vec3d.y - vec3d2.y;
         bufferBuilder.vertex(matrix4f, (float)d2, (float)d4, (float)d3).color(f3, f4, f5, f6);
         bufferBuilder.vertex(matrix4f, (float)d2, (float)(d4 + f2), (float)d3).color(f3, f4, f5, f6);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.lineWidth(1.0F);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(true);
      RenderSystem.disableBlend();
      matrixStack.pop();
   }
}
