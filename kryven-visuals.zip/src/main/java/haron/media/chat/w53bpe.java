package haron.media.chat;

import haron.client.MinecraftClientAccess;
import haron.module.ModuleManager;
import haron.util.ColorUtils;
import java.awt.Color;
import net.minecraft.text.Text;
import net.minecraft.text.Style;
import net.minecraft.text.MutableText;
import net.minecraft.text.TextColor;
import ru.haron.Kryven;

public final class w53bpe implements MinecraftClientAccess {
   private static final String e = "[Kryven] ";
   public static int a;
   public static boolean b;

   private w53bpe() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static void b(Text text) {
      if (c.player != null) {
         c.inGameHud
            .getChatHud()
            .addMessage(
               b("[Kryven] ")
                  .append(Text.literal("» ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215))))
                  .append(text)
            );
      }
   }

   public static MutableText b(String string) {
      MutableText mutableText = Text.literal("");
      Color color = new Color(a());
      Color color2 = a(color);
      int n = string.length();

      for (int i = 0; i < n; i++) {
         mutableText.append(
            Text.literal(String.valueOf(string.charAt(i)))
               .setStyle(
                  Style.EMPTY.withColor(TextColor.fromRgb(ColorUtils.a(color, color2, n <= 1 ? 0.0F : i / ((n & -2) - (~n & 1))).getRGB()))
               )
         );
      }

      return mutableText;
   }

   public static void a(Text text) {
      if (c.player != null) {
         c.player.sendMessage(text, false);
      }
   }

   public static void a(String string) {
      if (c.player != null) {
         c.player.networkHandler.sendChatCommand(string);
      }
   }

   public static void a(Object object) {
      if (object == null) {
         object = "null";
      }

      if (c.player == null) {
         Kryven.getLOGGER().info($sf$0(String.valueOf(object)));
      } else {
         c.inGameHud
            .getChatHud()
            .addMessage(
               b("[Kryven] ")
                  .append(Text.literal("» ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215))))
                  .append(Text.literal($sf$1(String.valueOf(object)).replace("&", "§")))
            );
      }
   }

   private static int a() {
      return ModuleManager.CLIENT_COLOR.o();
   }

   private static Color a(Color color) {
      float[] fArray = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
      return new Color(Color.HSBtoRGB(fArray[0], Math.max(0.0F, fArray[1] - 0.3F), Math.min(1.0F, fArray[2] + 0.2F)));
   }

   private static String $sf$0(String string) {
      return "(CHAT) " + string;
   }

   private static String $sf$1(String string) {
      int n = 284;
      return "§7" + string;
   }
}
