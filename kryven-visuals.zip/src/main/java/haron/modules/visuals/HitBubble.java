package haron.modules.visuals;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import haron.events.AttackTargetEvent;
import haron.events.WorldRenderPostEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.render.icons.HaronIcons;
import haron.settings.NumberSetting;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexFormat;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

@ModuleInfo(a = "Hit Bubble", b = "Показывает анимированные пузыри при атаке", c = ModuleCategory.VISUALS)
public class HitBubble extends HaronModule {
   private static final long LIFETIME_MS = 600L;
   private static final float RISE_DISTANCE = 0.6F;
   private static final float BASE_SIZE = 0.35F;
   private int hitCounter = 0;
   private final NumberSetting size = new NumberSetting("Размер", 0.35F, 0.15F, 0.8F, 0.05F);
   private final NumberSetting riseSpeed = new NumberSetting("Скорость подъёма", 0.6F, 0.1F, 1.5F, 0.05F);
   private final CopyOnWriteArrayList<HitBubbleParticle> bubbles = new CopyOnWriteArrayList<>();

   @EventHandler
   public void onAttack(AttackTargetEvent dt813s2) {
      Entity entity;
      if (this.k() && (entity = dt813s2.a()) != null) {
         double d = entity.getX();
         double d2 = entity.getY() + entity.getHeight() * 0.5;
         double d3 = entity.getZ();
         if (c.player != null && c.gameRenderer != null) {
            float f = c.gameRenderer.getCamera().getYaw();
            float f2 = (float)Math.toRadians(-f);
            double d4 = -Math.sin(f2) * 0.4;
            double d5 = Math.cos(f2) * 0.4;
            d += d4;
            d3 += d5;
         }

         boolean bl = this.hitCounter % 2 == 0;
         this.hitCounter++;
         this.bubbles.add(new HitBubbleParticle(d, d2, d3, bl ? "bubble_1" : "bubble_2", System.currentTimeMillis()));
      }
   }

   private void renderBubble(MatrixStack matrixStack, Vec3d vec3d, float f, float f2, HitBubbleParticle cvf4002, float f3) {
      double d = cvf4002.x - vec3d.x;
      double d2 = cvf4002.y - vec3d.y + (1.0F - (1.0F - f3) * (1.0F - f3)) * this.riseSpeed.a();
      double d3 = cvf4002.z - vec3d.z;
      float f4 = MathHelper.clamp(f3 < 0.15F ? f3 / 0.15F : (f3 > 0.7F ? 1.0F - (f3 - 0.7F) / 0.3F : 1.0F), 0.0F, 1.0F);
      float f5 = f3 < 0.2F ? 0.4F + 0.8F * (f3 / 0.2F) : 1.0F;
      Identifier identifier = HaronIcons.get(cvf4002.textureKey);
      if (identifier != null) {
         matrixStack.push();
         matrixStack.translate(d, d2, d3);
         matrixStack.multiply(new Quaternionf().rotationYXZ((float)Math.toRadians(-f), (float)Math.toRadians(f2), 0.0F));
         float f6 = this.size.a() * f5 / 2.0F;
         RenderSystem.setShaderTexture(0, identifier);
         RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, f4);
         BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
         Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
         bufferBuilder.vertex(matrix4f, -f6, -f6, 0.0F).texture(0.0F, 0.0F).color(1.0F, 1.0F, 1.0F, f4);
         bufferBuilder.vertex(matrix4f, f6, -f6, 0.0F).texture(1.0F, 0.0F).color(1.0F, 1.0F, 1.0F, f4);
         bufferBuilder.vertex(matrix4f, f6, f6, 0.0F).texture(1.0F, 1.0F).color(1.0F, 1.0F, 1.0F, f4);
         bufferBuilder.vertex(matrix4f, -f6, f6, 0.0F).texture(0.0F, 1.0F).color(1.0F, 1.0F, 1.0F, f4);
         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
         matrixStack.pop();
      }
   }

   @EventHandler
   public void onWorldRender(WorldRenderPostEvent kvprd92) {
      if (this.k() && !this.bubbles.isEmpty() && c.world != null && c.gameRenderer != null) {
         MatrixStack matrixStack = kvprd92.a();
         Vec3d vec3d = c.gameRenderer.getCamera().getPos();
         float f = c.gameRenderer.getCamera().getYaw();
         float f2 = c.gameRenderer.getCamera().getPitch();
         long l = System.currentTimeMillis();
         ArrayList<HitBubbleParticle> arrayList = new ArrayList<>();
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
         RenderSystem.disableCull();
         RenderSystem.depthMask(false);

         try {
            for (HitBubbleParticle cvf4002 : this.bubbles) {
               long l2 = l - cvf4002.spawnTime;
               if (l2 >= 600L) {
                  arrayList.add(cvf4002);
               } else {
                  this.renderBubble(matrixStack, vec3d, f, f2, cvf4002, (float)l2 / 600.0F);
               }
            }
         } catch (Exception exception) {
            arrayList.clear();
            this.bubbles.clear();
         } finally {
            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         }

         if (!arrayList.isEmpty()) {
            this.bubbles.removeAll(arrayList);
         }
      }
   }
}
