package haron.modules.visuals;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;

@ModuleInfo(a = "No Fluid", b = "Disables fluid rendering", c = ModuleCategory.VISUALS)
public class NoFluid extends HaronModule {
}
