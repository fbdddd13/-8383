package haron.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.events.WorldRenderPostEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.settings.NumberSetting;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.client.render.VertexFormat;
import org.joml.Matrix4f;

@ModuleInfo(a = "Wings", b = "Добавляет игроку детализированные анимированные крылья", c = ModuleCategory.VISUALS)
public final class Wings extends HaronModule {
   private static final float[][] WING_SHAPE = new float[][]{
      {0.08F, 0.1F},
      {0.28F, 0.34F},
      {0.56F, 0.82F},
      {0.86F, 0.3F},
      {1.14F, 0.46F},
      {1.24F, 0.04F},
      {1.02F, -0.18F},
      {1.18F, -0.64F},
      {0.86F, -0.46F},
      {0.8F, -0.98F},
      {0.54F, -0.74F},
      {0.3F, -1.16F},
      {0.1F, -0.54F}
   };
   private final NumberSetting size = new NumberSetting("Размер", 1.0F, 0.5F, 2.0F, 0.05F);
   private final NumberSetting opacity = new NumberSetting("Прозрачность", 0.75F, 0.1F, 1.0F, 0.05F);

   private static void drawWing(BufferBuilder bufferBuilder, Matrix4f matrix4f, float f, float f2, float f3, int n, int n2, int n3, int n4) {
      float f4 = 0.42F + f3;
      float f5 = f * 0.1F;
      float f6 = (float)Math.cos(f4 * f);
      float f7 = (float)Math.sin(f4 * f);

      for (int i = 0; i < WING_SHAPE.length; i++) {
         float[] fArray = WING_SHAPE[i];
         float[] fArray2 = WING_SHAPE[(i + 1) % WING_SHAPE.length];
         float f8 = f * fArray[0] * f2;
         float f9 = fArray[1] * f2;
         float f10 = f * fArray2[0] * f2;
         float f11 = fArray2[1] * f2;
         float f12 = f5 + (f8 - f5) * f6 - f9 * f7;
         float f13 = (f8 - f5) * f7 + f9 * f6;
         float f14 = f5 + (f10 - f5) * f6 - f11 * f7;
         float f15 = (f10 - f5) * f7 + f11 * f6;
         bufferBuilder.vertex(matrix4f, f5, 0.0F, 0.05F).color(n / 255.0F, n2 / 255.0F, n3 / 255.0F, n4 / 255.0F);
         bufferBuilder.vertex(matrix4f, f12, f13, 0.02F).color(n / 255.0F, n2 / 255.0F, n3 / 255.0F, n4 / 255.0F);
         bufferBuilder.vertex(matrix4f, f14, f15, 0.02F).color(n / 255.0F, n2 / 255.0F, n3 / 255.0F, n4 / 255.0F);
      }
   }

   private static void drawWingOutline(BufferBuilder bufferBuilder, Matrix4f matrix4f, float f, float f2, float f3, int n, int n2, int n3, int n4) {
      float f4 = f * 0.1F;
      float f5 = 0.42F + f3;
      float f6 = (float)Math.cos(f5 * f);
      float f7 = (float)Math.sin(f5 * f);

      for (int i = 0; i <= WING_SHAPE.length; i++) {
         float[] fArray = WING_SHAPE[i % WING_SHAPE.length];
         float f8 = f * fArray[0] * f2;
         float f9 = fArray[1] * f2;
         float f10 = f4 + (f8 - f4) * f6 - f9 * f7;
         float f11 = (f8 - f4) * f7 + f9 * f6;
         bufferBuilder.vertex(matrix4f, f10, f11, 0.025F).color(n / 255.0F, n2 / 255.0F, n3 / 255.0F, n4 / 255.0F);
      }
   }

   private static void drawWingRibs(BufferBuilder bufferBuilder, Matrix4f matrix4f, float f, float f2, float f3, int n, int n2, int n3, int n4) {
      int[] nArray = new int[]{2, 4, 7, 9, 11};
      float f4 = f * 0.1F;
      float f5 = 0.42F + f3;
      float f6 = (float)Math.cos(f5 * f);
      float f7 = (float)Math.sin(f5 * f);

      for (int n5 : nArray) {
         float[] fArray = WING_SHAPE[n5];
         float f8 = f * fArray[0] * f2;
         float f9 = fArray[1] * f2;
         float f10 = f4 + (f8 - f4) * f6 - f9 * f7;
         float f11 = (f8 - f4) * f7 + f9 * f6;
         bufferBuilder.vertex(matrix4f, f4, 0.0F, 0.03F).color(n / 255.0F, n2 / 255.0F, n3 / 255.0F, n4 / 255.0F);
         bufferBuilder.vertex(matrix4f, f10, f11, 0.03F).color(n / 255.0F, n2 / 255.0F, n3 / 255.0F, n4 / 255.0F);
      }
   }

   @EventHandler
   private void a(WorldRenderPostEvent kvprd92) {
      if (c.player != null && c.world != null && !c.options.getPerspective().isFirstPerson()) {
         MatrixStack matrixStack = kvprd92.a();
         float f = kvprd92.b();
         Vec3d vec3d = c.gameRenderer.getCamera().getPos();
         double d = MathHelper.lerp(f, c.player.lastRenderX, c.player.getX()) - vec3d.x;
         double d2 = MathHelper.lerp(f, c.player.lastRenderY, c.player.getY()) - vec3d.y;
         double d3 = MathHelper.lerp(f, c.player.lastRenderZ, c.player.getZ()) - vec3d.z;
         float f2 = (float)Math.sin((c.player.age + f) * 0.22F) * 0.16F;
         float f3 = 0.45F * this.size.a();
         int n = Math.round(this.opacity.a() * 255.0F);
         Color color = ModuleManager.CLIENT_COLOR.n();
         int n2 = color.getRed();
         int n3 = color.getGreen();
         int n4 = color.getBlue();
         matrixStack.push();
         matrixStack.translate(d, d2 + 1.35, d3);
         float f4 = MathHelper.lerpAngleDegrees(f, c.player.prevBodyYaw, c.player.bodyYaw);
         matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-f4));
         if (c.player.isSneaking()) {
            matrixStack.translate(0.0, -0.15, 0.15);
            matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(20.0F));
         }

         Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableCull();
         RenderSystem.enableDepthTest();
         RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

         try {
            BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
            drawWing(bufferBuilder, matrix4f, -1.0F, f3, f2, n2, n3, n4, n);
            drawWing(bufferBuilder, matrix4f, 1.0F, f3, f2, n2, n3, n4, n);
            BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
            BufferBuilder bufferBuilder2 = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
            drawWingOutline(bufferBuilder2, matrix4f, -1.0F, f3, f2, n2, n3, n4, Math.min(255, n + 55));
            drawWingOutline(bufferBuilder2, matrix4f, 1.0F, f3, f2, n2, n3, n4, Math.min(255, n + 55));
            drawWingRibs(bufferBuilder2, matrix4f, -1.0F, f3, f2, n2, n3, n4, Math.max(45, n / 2));
            drawWingRibs(bufferBuilder2, matrix4f, 1.0F, f3, f2, n2, n3, n4, Math.max(45, n / 2));
            BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
         } finally {
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            matrixStack.pop();
         }
      }
   }
}
