package haron.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.animation.AnimatedValue;
import haron.animation.Easings;
import haron.core.BooleanCoercion;
import haron.entity.EntityInterpolation;
import haron.events.WorldRenderPostEvent;
import haron.hud.core.HudServices;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.modules.hud.ClientColor;
import haron.render.shader.DefaultShaders;
import haron.render.shader.ShaderProgram;
import haron.render.world.WorldRenderUtils;
import haron.settings.BooleanSetting;
import haron.settings.ColorSetting;
import haron.settings.ModeSetting;
import haron.settings.NumberSetting;
import haron.settings.SettingGroup;
import haron.util.ColorUtils;
import java.awt.Color;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexFormat;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

@ModuleInfo(a = "Target ESP", b = "Отображает ESP вокруг цели", c = ModuleCategory.VISUALS)
public class TargetEsp extends HaronModule {
   private final ModeSetting mode = new ModeSetting("Режим", new String[]{"Призраки", "Круг", "Квадратик", "Орбита"}, "Орбита");
   private final SettingGroup ghostSettings = new SettingGroup("Призраки").a(() -> this.mode.b("Призраки"));
   private final NumberSetting ghostSpeed = new NumberSetting("Скорость анимации", 1.5F, 0.5F, 5.0F, 0.1F).a(() -> this.mode.b("Призраки"));
   private final NumberSetting ghostParticleSize = new NumberSetting("Размер частиц", 0.25F, 0.05F, 0.5F, 0.01F).a(() -> this.mode.b("Призраки"));
   private final NumberSetting ghostCount = new NumberSetting("Количество призраков", 4.0F, 2.0F, 6.0F, 1.0F).a(() -> this.mode.b("Призраки"));
   private final SettingGroup circleSettings = new SettingGroup("Круг").a(() -> this.mode.b("Круг"));
   private final NumberSetting circleSpeed = new NumberSetting("Скорость анимации", 1.5F, 0.5F, 5.0F, 0.1F).a(() -> this.mode.b("Круг"));
   private final SettingGroup squareSettings = new SettingGroup("Квадратик").a(() -> this.mode.b("Квадратик"));
   private final NumberSetting squareSpeed = new NumberSetting("Скорость анимации", 2.5F, 0.5F, 5.0F, 0.1F).a(() -> this.mode.b("Квадратик"));
   private final NumberSetting squareSize = new NumberSetting("Размер квадратика", 1.4F, 0.5F, 2.0F, 0.1F).a(() -> this.mode.b("Квадратик"));
   private final SettingGroup orbitSettings = new SettingGroup("Орбита").a(() -> {
      int n = 422;
      return this.mode.b("Орбита");
   });
   private final ModeSetting orbitShape = new ModeSetting("Форма", new String[]{"Стрелки", "Ромбы", "Кубы"}, "Стрелки").a(() -> this.mode.b("Орбита"));
   private final NumberSetting orbitSpeed = new NumberSetting("Скорость анимации", 1.5F, 0.5F, 5.0F, 0.1F).a(() -> this.mode.b("Орбита"));
   private final NumberSetting figuresPerRing = new NumberSetting("Фигур по кругу", 3.0F, 2.0F, 8.0F, 1.0F).a(() -> this.mode.b("Орбита"));
   private final NumberSetting orbitLayerCount = new NumberSetting("Слоёв по высоте", 3.0F, 2.0F, 5.0F, 1.0F).a(() -> this.mode.b("Орбита"));
   private final NumberSetting orbitVerticalSpread = new NumberSetting("Отступ между слоями", 1.0F, 0.3F, 2.0F, 0.05F).a(() -> {
      int n = 249;
      return this.mode.b("Орбита");
   });
   private final NumberSetting orbitRadius = new NumberSetting("Дистанция", 0.9F, 0.5F, 2.0F, 0.05F).a(() -> this.mode.b("Орбита"));
   private final NumberSetting orbitFigureSize = new NumberSetting("Размер фигур", 0.2F, 0.08F, 0.4F, 0.01F).a(() -> this.mode.b("Орбита"));
   private final BooleanSetting orbitRotationEnabled = new BooleanSetting("Вращение", true).a(() -> this.mode.b("Орбита"));
   private final BooleanSetting orbitShaderEnabled = new BooleanSetting("Шейдер", true).a(() -> this.mode.b("Орбита"));
   private final ModeSetting orbitShaderType = new ModeSetting("Тип шейдера", new String[]{"Небула", "Звёзды", "Паутина", "Плазма"}, "Небула")
      .a(() -> this.mode.b("Орбита") && this.orbitShaderEnabled.a());
   private final BooleanSetting orbitGlowEnabled = new BooleanSetting("Свечение", true).a(() -> this.mode.b("Орбита"));
   private final NumberSetting orbitGlowSize = new NumberSetting("Размер свечения", 0.85F, 0.1F, 1.0F, 0.05F)
      .a(() -> BooleanCoercion.from(this.mode.b("Орбита") && this.orbitGlowEnabled.a() ? 1 : 0));
   private final NumberSetting orbitGlowOpacity = new NumberSetting("Прозрачность свечения", 0.25F, 0.1F, 1.0F, 0.05F)
      .a(() -> BooleanCoercion.from(this.mode.b("Орбита") && this.orbitGlowEnabled.a() ? 1 : 0));
   private final SettingGroup colorSettings = new SettingGroup("Цвет");
   private final BooleanSetting useClientColor = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting customColor = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> BooleanCoercion.from(this.useClientColor.a() ? 0 : 1));
   private final SettingGroup hitSettings = new SettingGroup("При ударе");
   private final BooleanSetting hitEffectEnabled = new BooleanSetting("Включить", BooleanCoercion.from(-1673835725));
   private final BooleanSetting hitColorEnabled = new BooleanSetting("Изменять цвет", true).a(() -> this.hitEffectEnabled.a());
   private final ColorSetting hitColor = new ColorSetting("Цвет урона", new Color(255, 50, 50))
      .a(() -> BooleanCoercion.from(this.hitEffectEnabled.a() && this.hitColorEnabled.a() ? 1 : 0));
   private final BooleanSetting hitSpeedEnabled = new BooleanSetting("Ускорять анимацию", true).a(() -> {
      int n = 978;
      return this.hitEffectEnabled.a();
   });
   private final NumberSetting hitSpeedMultiplier = new NumberSetting("Множитель ускорения", 3.0F, 1.2F, 5.0F, 0.1F)
      .a(() -> BooleanCoercion.from(this.hitEffectEnabled.a() && this.hitSpeedEnabled.a() ? 1 : 0));
   private final NumberSetting hitEffectDuration = new NumberSetting("Длительность эффекта", 0.8F, 0.3F, 2.0F, 0.1F)
      .a(() -> BooleanCoercion.from(this.hitEffectEnabled.a() && this.hitSpeedEnabled.a() ? 1 : 0));
   private final Map<LivingEntity, AnimatedValue> visibilityAnimations = new HashMap<>();
   private final Identifier targetTexture = Identifier.of("haron", "textures/target.png");
   private final BooleanSetting targetPlayers = new BooleanSetting("Игроки", true);
   private final BooleanSetting targetMobs = new BooleanSetting("Мобы", true);
   private final Map<LivingEntity, Integer> previousHurtTimes = new HashMap<>();
   private final Map<LivingEntity, Long> hitTimestamps = new HashMap<>();
   private final Map<LivingEntity, Double> rotationDegrees = new HashMap<>();
   private final Map<LivingEntity, Double> animationPhase = new HashMap<>();
   private long lastFrameTimeMs = System.currentTimeMillis();

   private boolean matchesTargetType(LivingEntity livingEntity) {
      if (livingEntity != null && livingEntity != c.player) {
         return livingEntity instanceof PlayerEntity ? this.targetPlayers.a() : this.targetMobs.a();
      } else {
         return false;
      }
   }

   private Color getRenderColor(LivingEntity livingEntity) {
      if (this.hitEffectEnabled.a() && this.hitColorEnabled.a() && livingEntity != null && livingEntity.hurtTime > 0) {
         float f = livingEntity.hurtTime / 10.0F;
         Color color = this.baseColor();
         Color color2 = this.hitColor.a();
         int n = (int)(color.getRed() + (color2.getRed() - color.getRed()) * f);
         int n2 = (int)(color.getGreen() + (color2.getGreen() - color.getGreen()) * f);
         int n3 = (int)(color.getBlue() + (color2.getBlue() - color.getBlue()) * f);
         return new Color(Math.max(0, Math.min(255, n)), Math.max(0, Math.min(255, n2)), Math.max(0, Math.min(255, n3)));
      } else {
         return this.baseColor();
      }
   }

   private void renderGhosts(WorldRenderPostEvent kvprd92, LivingEntity livingEntity, float f) {
      if (this.isRenderableTarget(livingEntity) && !(f <= 0.0F) && c.player.canSee(livingEntity)) {
         Vec3d vec3d = EntityInterpolation.b(livingEntity, kvprd92.b());
         if (vec3d == null) {
            vec3d = livingEntity.getPos();
         }

         if (vec3d != null) {
            double d = Math.toRadians(50.0) / 15.0;
            int n = this.ghostCount.b();
            double d2 = this.animationPhase.getOrDefault(livingEntity, 0.0);
            double d3 = Math.max(livingEntity.getWidth(), 0.5F) + 0.3;
            double d4 = vec3d.y + Math.max(livingEntity.getHeight(), 0.5F) / 2.0F;
            double d5 = f;
            Vec3d[] vec3dArray = new Vec3d[]{
               new Vec3d(1.0, 1.0, 1.0),
               new Vec3d(-1.0, 1.0, -1.0),
               new Vec3d(1.0, -1.0, 1.0),
               new Vec3d(-1.0, -1.0, 1.0),
               new Vec3d(1.0, 1.0, -1.0),
               new Vec3d(-1.0, -1.0, -1.0)
            };

            for (int i = 0; i < n; i++) {
               double d6 = d2 + i * Math.PI / 2.0;
               Vec3d vec3d3 = vec3dArray[i];
               double d7 = Math.sqrt(vec3d3.x * vec3d3.x + vec3d3.y * vec3d3.y + vec3d3.z * vec3d3.z);
               Vec3d vec3d4 = new Vec3d(vec3d3.x / d7, vec3d3.y / d7, vec3d3.z / d7);
               Vec3d vec3d2;
               if (Math.abs(vec3d4.dotProduct(vec3d2 = new Vec3d(0.0, 1.0, 0.0))) > 0.99) {
                  vec3d2 = new Vec3d(1.0, 0.0, 0.0);
               }

               Vec3d vec3d5 = vec3d4.crossProduct(vec3d2).normalize();
               Vec3d vec3d6 = vec3d4.crossProduct(vec3d5).normalize();

               for (int j = 0; j < 15; j++) {
                  double d8 = j * d + d6;
                  double d9 = Math.cos(d8);
                  double d10 = Math.sin(d8);
                  Vec3d vec3d7 = vec3d5.multiply(d9).add(vec3d6.multiply(d10)).multiply(d3);
                  double d11 = vec3d.x + vec3d7.x;
                  double d12 = d4 + vec3d7.y;
                  double d13 = vec3d.z + vec3d7.z;

                  try {
                     WorldRenderUtils.a(
                        kvprd92.a(),
                        new Vec3d(d11, d12, d13),
                        this.ghostParticleSize.a() * (1.0F + j / 15.0F),
                        ColorUtils.a(ColorUtils.a(this.getRenderColor(livingEntity).getRGB()), Math.max(1, (int)(d5 * 150.0)))
                     );
                  } catch (Exception var42) {
                  }
               }
            }
         }
      }
   }

   private void b(
      Matrix4f matrix4f,
      Vec3d vec3d,
      Color color,
      boolean bl,
      float f,
      float f2,
      float f3,
      double d,
      double d2,
      double d3,
      double d4,
      double d5,
      double d6,
      double d7,
      double d8,
      double d9,
      float f4,
      int n
   ) {
      double d10 = d5 * d9 - d6 * d8;
      double d11 = d6 * d7 - d4 * d9;
      double d12 = d4 * d8 - d5 * d7;
      float f5 = f4;
      float f6 = (float)(f + d * f5 * 1.2 - vec3d.x);
      float f7 = (float)(f2 + d2 * f5 * 1.2 - vec3d.y);
      float f8 = (float)(f3 + d3 * f5 * 1.2 - vec3d.z);
      float f9 = (float)(f - d * f5 * 1.2 - vec3d.x);
      float f10 = (float)(f2 - d2 * f5 * 1.2 - vec3d.y);
      float f11 = (float)(f3 - d3 * f5 * 1.2 - vec3d.z);
      float f12 = f5 * 0.6F;
      float f13 = (float)(f + d7 * f12 + d10 * f12 - vec3d.x);
      float f14 = (float)(f2 + d8 * f12 + d11 * f12 - vec3d.y);
      float f15 = (float)(f3 + d9 * f12 + d12 * f12 - vec3d.z);
      float f16 = (float)(f + d7 * f12 - d10 * f12 - vec3d.x);
      float f17 = (float)(f2 + d8 * f12 - d11 * f12 - vec3d.y);
      float f18 = (float)(f3 + d9 * f12 - d12 * f12 - vec3d.z);
      float f19 = (float)(f - d7 * f12 - d10 * f12 - vec3d.x);
      float f20 = (float)(f2 - d8 * f12 - d11 * f12 - vec3d.y);
      float f21 = (float)(f3 - d9 * f12 - d12 * f12 - vec3d.z);
      float f22 = (float)(f - d7 * f12 + d10 * f12 - vec3d.x);
      float f23 = (float)(f2 - d8 * f12 + d11 * f12 - vec3d.y);
      float f24 = (float)(f3 - d9 * f12 + d12 * f12 - vec3d.z);
      this.a(matrix4f, color, bl, f6, f7, f8, f13, f14, f15, f16, f17, f18, n);
      this.a(matrix4f, color, bl, f6, f7, f8, f16, f17, f18, f19, f20, f21, n);
      this.a(matrix4f, color, bl, f6, f7, f8, f19, f20, f21, f22, f23, f24, n);
      this.a(matrix4f, color, bl, f6, f7, f8, f22, f23, f24, f13, f14, f15, n);
      this.a(matrix4f, color, bl, f9, f10, f11, f16, f17, f18, f13, f14, f15, n);
      this.a(matrix4f, color, bl, f9, f10, f11, f19, f20, f21, f16, f17, f18, n);
      this.a(matrix4f, color, bl, f9, f10, f11, f22, f23, f24, f19, f20, f21, n);
      this.a(matrix4f, color, bl, f9, f10, f11, f13, f14, f15, f22, f23, f24, n);
   }

   private void c(
      Matrix4f matrix4f,
      Vec3d vec3d,
      Color color,
      boolean bl,
      float f,
      float f2,
      float f3,
      double d,
      double d2,
      double d3,
      double d4,
      double d5,
      double d6,
      float f4,
      int n
   ) {
      float f5 = f4 * 0.5F;
      double d7 = d2 * d6 - d3 * d5;
      double d8 = d3 * d4 - d * d6;
      double d9 = d * d5 - d2 * d4;
      float[][] fArray = new float[8][3];
      int n2 = 0;

      for (int i = -1; i <= 1; i += 2) {
         for (int j = -1; j <= 1; j += 2) {
            for (int k = -1; k <= 1; k += 2) {
               fArray[n2++] = new float[]{
                  (float)(f + d * f5 * i + d4 * f5 * j + d7 * f5 * k - vec3d.x),
                  (float)(f2 + d2 * f5 * i + d5 * f5 * j + d8 * f5 * k - vec3d.y),
                  (float)(f3 + d3 * f5 * i + d6 * f5 * j + d9 * f5 * k - vec3d.z)
               };
            }
         }
      }

      for (int[] nArray : new int[][]{{0, 1, 3, 2}, {4, 6, 7, 5}, {0, 4, 5, 1}, {2, 3, 7, 6}, {0, 2, 6, 4}, {1, 5, 7, 3}}) {
         this.a(
            matrix4f,
            color,
            bl,
            fArray[nArray[0]][0],
            fArray[nArray[0]][1],
            fArray[nArray[0]][2],
            fArray[nArray[1]][0],
            fArray[nArray[1]][1],
            fArray[nArray[1]][2],
            fArray[nArray[2]][0],
            fArray[nArray[2]][1],
            fArray[nArray[2]][2],
            fArray[nArray[3]][0],
            fArray[nArray[3]][1],
            fArray[nArray[3]][2],
            n
         );
      }
   }

   private float animationSpeed(LivingEntity livingEntity) {
      float f3 = this.baseAnimationSpeed();
      if (this.hitEffectEnabled.a() && this.hitSpeedEnabled.a() && livingEntity != null) {
         int n = livingEntity.hurtTime;
         int n2 = this.previousHurtTimes.getOrDefault(livingEntity, 0);
         this.previousHurtTimes.put(livingEntity, n);
         if (n >= 9 && n2 < 9) {
            this.hitTimestamps.put(livingEntity, System.currentTimeMillis());
         }

         Long l;
         if ((l = this.hitTimestamps.get(livingEntity)) == null) {
            return f3;
         }

         float f4 = (float)(System.currentTimeMillis() - l) / 1000.0F;
         float f2;
         if (f4 > (f2 = this.hitEffectDuration.a())) {
            return f3;
         }

         float f5 = f4 / f2;
         float hitStrength;
         if (f5 >= 0.15F) {
            float f6 = (f5 - 0.15F) / 0.85F;
            hitStrength = 1.0F - f6 * f6 * (3.0F - 2.0F * f6);
         } else {
            float f7 = f5 / 0.15F;
            hitStrength = f7 * f7 * (3.0F - 2.0F * f7);
         }

         return f3 * (1.0F + (this.hitSpeedMultiplier.a() - 1.0F) * hitStrength);
      } else {
         return f3;
      }
   }

   private void renderCircle(WorldRenderPostEvent kvprd92, LivingEntity livingEntity, float f) {
      if (!(f <= 0.0F) && livingEntity != null && this.isRenderableTarget(livingEntity) && c.player.canSee(livingEntity)) {
         float f2 = livingEntity.getWidth() * 0.7F;
         Vec3d vec3d = EntityInterpolation.b(livingEntity, kvprd92.b());
         if (vec3d == null) {
            vec3d = livingEntity.getPos();
         }

         double d = this.animationPhase.getOrDefault(livingEntity, 0.0) % (Math.PI * 2);
         double d2 = Math.PI;
         boolean bl = d > Math.PI;
         double d3 = d / Math.PI;
         double d4 = bl ? d3 - 1.0 : 1.0 - d3;
         double d5 = d4 >= 0.5 ? 1.0 - Math.pow(-2.0 * d4 + 2.0, 2.0) / 2.0 : 2.0 * d4 * d4;
         double d6 = livingEntity.getHeight() / 2.0F * (d5 <= 0.5 ? d5 : 1.0 - d5) * (bl ? -1 : 1);
         Tessellator tessellator = Tessellator.getInstance();
         MatrixStack matrixStack = kvprd92.a();
         Vec3d vec3d2 = c.gameRenderer.getCamera().getPos();
         Color color = this.getRenderColor(livingEntity);
         Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
         matrixStack.push();

         try {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableCull();
            RenderSystem.depthMask(false);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            GL11.glEnable(2848);
            GL11.glHint(3154, 4354);
            RenderSystem.lineWidth(3.0F);
            BufferBuilder bufferBuilder = tessellator.begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);

            for (int i = 0; i <= 360; i++) {
               double d7 = Math.toRadians(i);
               double d8 = Math.cos(d7);
               double d9 = Math.sin(d7);
               float f3 = (float)(vec3d.x + d8 * f2 - vec3d2.x);
               float f4 = (float)(vec3d.y + livingEntity.getHeight() * d5 - vec3d2.y);
               float f5 = (float)(vec3d.z + d9 * f2 - vec3d2.z);
               bufferBuilder.vertex(matrix4f, f3, f4, f5).color(color.getRed(), color.getGreen(), color.getBlue(), (int)(100.0F * f));
               float f6 = (float)(vec3d.y + livingEntity.getHeight() * d5 + d6 - vec3d2.y);
               bufferBuilder.vertex(matrix4f, f3, f6, f5).color(color.getRed(), color.getGreen(), color.getBlue(), 0);
            }

            BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
            BufferBuilder bufferBuilder2 = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);

            for (int i = 0; i <= 360; i++) {
               double d10 = Math.toRadians(i);
               float f7 = (float)(vec3d.x + Math.cos(d10) * f2 - vec3d2.x);
               float f8 = (float)(vec3d.y + livingEntity.getHeight() * d5 - vec3d2.y);
               float f9 = (float)(vec3d.z + Math.sin(d10) * f2 - vec3d2.z);
               bufferBuilder2.vertex(matrix4f, f7, f8, f9).color(color.getRed(), color.getGreen(), color.getBlue(), (int)(255.0F * f));
            }

            BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
         } catch (Exception var39) {
         } finally {
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            RenderSystem.depthMask(true);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glDisable(2848);
            matrixStack.pop();
         }
      }
   }

   private Color baseColor() {
      if (this.useClientColor.a()) {
         ClientColor byzlib2 = ModuleManager.CLIENT_COLOR;
         return byzlib2.n();
      } else {
         return this.customColor.a();
      }
   }

   @Override
   public void f() {
      super.f();
      this.visibilityAnimations.clear();
      this.previousHurtTimes.clear();
      this.hitTimestamps.clear();
   }

   private void renderOrbit(WorldRenderPostEvent event, LivingEntity target, float alpha) {
      if (!(alpha <= 0.0F) && this.isRenderableTarget(target) && c.player.canSee(target)) {
         Vec3d entityPosition = EntityInterpolation.interpolatedPosition(target, event.b());
         if (entityPosition == null) {
            entityPosition = target.getPos();
         }

         if (entityPosition != null) {
            MatrixStack matrices = event.a();
            Vec3d cameraPosition = c.gameRenderer.getCamera().getPos();
            Color color = this.getRenderColor(target);
            int figuresPerRing = this.figuresPerRing.b();
            int layerCount = this.orbitLayerCount.b();
            float entityHeight = target.getHeight();
            float verticalSpan = entityHeight * this.orbitVerticalSpread.a();
            float lowerOffset = (entityHeight - verticalSpan) / 2.0F;
            float baseRadius = this.orbitRadius.a() + target.getWidth() / 2.0F;
            float figureSize = this.orbitFigureSize.a() * alpha;
            Vec3d orbitCenter = entityPosition.add(0.0, entityHeight / 2.0F, 0.0);
            double rotationDegrees = this.orbitRotationEnabled.a() ? this.rotationDegrees.getOrDefault(target, 0.0) : 0.0;
            double animationPhase = this.animationPhase.getOrDefault(target, 0.0);
            float animatedRadius = (float)(baseRadius + Math.sin(animationPhase) * 0.08);
            String shape = this.orbitShape.d();
            Optional<ShaderProgram> shader = this.resolveOrbitShader();
            if (this.orbitGlowEnabled.a()) {
               this.renderOrbitGlow(
                  matrices,
                  entityPosition,
                  orbitCenter,
                  color,
                  alpha,
                  figuresPerRing,
                  layerCount,
                  verticalSpan,
                  lowerOffset,
                  animatedRadius,
                  figureSize,
                  rotationDegrees,
                  shape
               );
            }

            this.renderOrbitFigures(
               matrices,
               cameraPosition,
               entityPosition,
               orbitCenter,
               color,
               alpha,
               figuresPerRing,
               layerCount,
               verticalSpan,
               lowerOffset,
               animatedRadius,
               figureSize,
               rotationDegrees,
               animationPhase,
               shape,
               shader
            );
         }
      }
   }

   private Optional<ShaderProgram> resolveOrbitShader() {
      return !this.orbitShaderEnabled.a()
         ? Optional.empty()
         : DefaultShaders.getRegistry().find(this.shaderName(this.orbitShaderType)).filter(ShaderProgram::b);
   }

   private void renderOrbitGlow(
      MatrixStack matrices,
      Vec3d entityPosition,
      Vec3d orbitCenter,
      Color color,
      float alpha,
      int figuresPerRing,
      int layerCount,
      float verticalSpan,
      float lowerOffset,
      float animatedRadius,
      float figureSize,
      double rotationDegrees,
      String shape
   ) {
      float glowSize = this.orbitGlowSize.a();
      int glowColor = ColorUtils.withAlpha(ColorUtils.ensureOpaque(color.getRGB()), (int)(alpha * 255.0F * this.orbitGlowOpacity.a()));

      for (int layerIndex = 0; layerIndex < layerCount; layerIndex++) {
         float layerY = layerY(entityPosition.y, lowerOffset, verticalSpan, layerIndex, layerCount);
         float layerRadius = layerRadius(animatedRadius, layerIndex, layerCount);
         double angularOffset = alternatingAngularOffset(layerIndex, figuresPerRing);

         for (int figureIndex = 0; figureIndex < figuresPerRing; figureIndex++) {
            double angle = Math.toRadians(rotationDegrees + angularOffset + 360.0 * figureIndex / figuresPerRing);
            Vec3d figurePosition = new Vec3d(
               orbitCenter.x + layerRadius * Math.cos(angle), layerY, orbitCenter.z + layerRadius * Math.sin(angle)
            );
            if (shape.equals("Стрелки")) {
               Vec3d towardCenter = orbitCenter.subtract(figurePosition);
               if (towardCenter.lengthSquared() > 1.0E-6) {
                  figurePosition = figurePosition.add(towardCenter.normalize().multiply(figureSize * 0.75F));
               }
            }

            WorldRenderUtils.drawBillboardGlow(matrices, figurePosition, glowSize, glowColor);
         }
      }
   }

   private void renderOrbitFigures(
      MatrixStack matrices,
      Vec3d cameraPosition,
      Vec3d entityPosition,
      Vec3d orbitCenter,
      Color color,
      float alpha,
      int figuresPerRing,
      int layerCount,
      float verticalSpan,
      float lowerOffset,
      float animatedRadius,
      float figureSize,
      double rotationDegrees,
      double animationPhase,
      String shape,
      Optional<ShaderProgram> shader
   ) {
      matrices.push();

      try {
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableCull();
         RenderSystem.depthMask(false);
         RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
         Matrix4f positionMatrix = matrices.peek().getPositionMatrix();

         int shapeType = switch (shape) {
            case "Стрелки" -> 0;
            case "Ромбы" -> 1;
            case "Кубы" -> 2;
            default -> -1;
         };
         int renderPassCount = shader.isPresent() ? 2 : 1;

         for (int passIndex = 0; passIndex < renderPassCount; passIndex++) {
            boolean shaderPass = passIndex == 1;

            try {
               if (shaderPass) {
                  ShaderProgram program = shader.orElseThrow();
                  program.d();
                  program.a("time", (float)(animationPhase * 0.4));
                  program.a("screenSize", (float)c.getWindow().getFramebufferWidth(), (float)c.getWindow().getFramebufferHeight());
                  program.a("baseColor", color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, 1.0F);
                  program.a("alpha", alpha * 1.5F);
                  RenderSystem.blendFunc(770, 1);
               }

               for (int layerIndex = 0; layerIndex < layerCount; layerIndex++) {
                  float layerY = layerY(entityPosition.y, lowerOffset, verticalSpan, layerIndex, layerCount);
                  float radius = layerRadius(animatedRadius, layerIndex, layerCount);
                  double angularOffset = alternatingAngularOffset(layerIndex, figuresPerRing);

                  for (int figureIndex = 0; figureIndex < figuresPerRing; figureIndex++) {
                     double angle = Math.toRadians(rotationDegrees + angularOffset + 360.0 * figureIndex / figuresPerRing);
                     float figureX = (float)(orbitCenter.x + radius * Math.cos(angle));
                     float figureZ = (float)(orbitCenter.z + radius * Math.sin(angle));
                     Vec3d forward = orbitCenter.subtract(figureX, layerY, figureZ).normalize();
                     Vec3d side = new Vec3d(-forward.z, 0.0, forward.x).normalize();
                     Vec3d up = side.crossProduct(forward);
                     int opacity = (int)(alpha * 220.0F);
                     switch (shapeType) {
                        case 0:
                           this.a(
                              positionMatrix,
                              cameraPosition,
                              color,
                              shaderPass,
                              figureX,
                              layerY,
                              figureZ,
                              forward.x,
                              forward.y,
                              forward.z,
                              up.x,
                              up.y,
                              up.z,
                              side.x,
                              side.y,
                              side.z,
                              figureSize,
                              opacity
                           );
                           break;
                        case 1:
                           this.b(
                              positionMatrix,
                              cameraPosition,
                              color,
                              shaderPass,
                              figureX,
                              layerY,
                              figureZ,
                              forward.x,
                              forward.y,
                              forward.z,
                              up.x,
                              up.y,
                              up.z,
                              side.x,
                              side.y,
                              side.z,
                              figureSize,
                              opacity
                           );
                           break;
                        case 2:
                           this.c(
                              positionMatrix,
                              cameraPosition,
                              color,
                              shaderPass,
                              figureX,
                              layerY,
                              figureZ,
                              up.x,
                              up.y,
                              up.z,
                              side.x,
                              side.y,
                              side.z,
                              figureSize,
                              opacity
                           );
                     }
                  }
               }
            } finally {
               if (shaderPass) {
                  shader.ifPresent(program -> {
                     try {
                        program.e();
                     } catch (Exception var2) {
                     }
                  });
                  RenderSystem.defaultBlendFunc();
               }
            }
         }
      } finally {
         RenderSystem.depthMask(true);
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         matrices.pop();
      }
   }

   private static float layerY(double entityY, float lowerOffset, float verticalSpan, int layerIndex, int layerCount) {
      int intervals = Math.max(1, layerCount - 1);
      return (float)(entityY + lowerOffset + verticalSpan * layerIndex / intervals);
   }

   private static float layerRadius(float baseRadius, int layerIndex, int layerCount) {
      float centerLayer = (layerCount - 1) / 2.0F;
      return baseRadius * (1.0F - Math.abs(layerIndex - centerLayer) / Math.max(centerLayer, 0.001F) * 0.3F);
   }

   private static double alternatingAngularOffset(int layerIndex, int figuresPerRing) {
      return 180.0 / figuresPerRing * (layerIndex % 2);
   }

   private void renderSquare(WorldRenderPostEvent kvprd92, LivingEntity livingEntity, float f) {
      if (!(f <= 0.0F) && livingEntity != null && this.isRenderableTarget(livingEntity) && c.player.canSee(livingEntity)) {
         Vec3d vec3d = EntityInterpolation.b(livingEntity, kvprd92.b());
         if (vec3d == null) {
            vec3d = livingEntity.getPos();
         }

         if (vec3d != null) {
            double d = this.rotationDegrees.getOrDefault(livingEntity, 0.0);
            double d2 = this.animationPhase.getOrDefault(livingEntity, 0.0);
            float f2 = (float)(this.squareSize.a() * (1.0 + 0.05 * Math.sin(d2))) * f;
            WorldRenderUtils.drawTexturedBillboard(
               kvprd92.a(),
               new Vec3d(vec3d.x, vec3d.y + livingEntity.getHeight() / 2.0F, vec3d.z),
               f2,
               ColorUtils.withAlpha(ColorUtils.ensureOpaque(this.getRenderColor(livingEntity).getRGB()), Math.max(1, (int)(f * 255.0F))),
               this.targetTexture,
               (float)d,
               true
            );
         }
      }
   }

   private void a(
      Matrix4f matrix4f,
      Vec3d vec3d,
      Color color,
      boolean bl,
      float f,
      float f2,
      float f3,
      double d,
      double d2,
      double d3,
      double d4,
      double d5,
      double d6,
      double d7,
      double d8,
      double d9,
      float f4,
      int n
   ) {
      float f5 = f4 * 0.5F;
      this.a(
         matrix4f,
         color,
         bl,
         (float)(f + d * f4 * 1.5 - vec3d.x),
         (float)(f2 + d2 * f4 * 1.5 - vec3d.y),
         (float)(f3 + d3 * f4 * 1.5 - vec3d.z),
         (float)(f + d4 * f5 - vec3d.x),
         (float)(f2 + d5 * f5 - vec3d.y),
         (float)(f3 + d6 * f5 - vec3d.z),
         (float)(f - d4 * f5 - vec3d.x),
         (float)(f2 - d5 * f5 - vec3d.y),
         (float)(f3 - d6 * f5 - vec3d.z),
         (float)(f + d7 * f5 - vec3d.x),
         (float)(f2 + d8 * f5 - vec3d.y),
         (float)(f3 + d9 * f5 - vec3d.z),
         n
      );
   }

   private boolean isRenderableTarget(LivingEntity livingEntity) {
      if (livingEntity == null) {
         return false;
      }

      if (!this.matchesTargetType(livingEntity)) {
         return false;
      }

      if (!livingEntity.isAlive() || livingEntity.getWorld() != c.world) {
         return false;
      }

      if (livingEntity.getWidth() <= 0.0F || livingEntity.getHeight() <= 0.0F) {
         return false;
      }

      if (livingEntity.squaredDistanceTo(c.player) > 25.0) {
         return false;
      }

      if (!c.player.canSee(livingEntity)) {
         return false;
      }

      if (livingEntity.hasStatusEffect(StatusEffects.INVISIBILITY)) {
         boolean bl = !livingEntity.getMainHandStack().isEmpty() || !livingEntity.getOffHandStack().isEmpty();
         boolean bl2 = false;

         for (ItemStack itemStack : livingEntity.getArmorItems()) {
            if (!itemStack.isEmpty()) {
               bl2 = true;
               break;
            }
         }

         if (!bl && !bl2) {
            return false;
         }
      }

      return true;
   }

   private void updateAnimationPhase(LivingEntity livingEntity, float f) {
      float f2 = this.animationSpeed(livingEntity);
      this.rotationDegrees.put(livingEntity, (this.rotationDegrees.getOrDefault(livingEntity, 0.0) + f * f2 * 50.0) % 360.0);
      this.animationPhase.put(livingEntity, this.animationPhase.getOrDefault(livingEntity, 0.0) + f * f2 * 2.5);
   }

   @EventHandler
   public void onWorldRender(WorldRenderPostEvent kvprd92) {
      long l = this.lastFrameTimeMs;
      this.lastFrameTimeMs = System.currentTimeMillis();
      float f = Math.min((float)(this.lastFrameTimeMs - l) / 1000.0F, 0.1F);
      LivingEntity livingEntity2 = this.findTarget();
      if (livingEntity2 != null && this.isRenderableTarget(livingEntity2)) {
         this.visibilityAnimations.computeIfAbsent(livingEntity2, livingEntity -> {
            int n = 95;
            return new AnimatedValue();
         }).a(1.0, 0.5, Easings.f, true);
      }

      HashSet<LivingEntity> hashSet = new HashSet<>();

      for (Map.Entry<LivingEntity, AnimatedValue> livingEntity3 : this.visibilityAnimations.entrySet()) {
         LivingEntity livingEntity4 = livingEntity3.getKey();
         if (this.isRenderableTarget(livingEntity4)) {
            AnimatedValue urhlup2 = livingEntity3.getValue();
            if (livingEntity4 != livingEntity2) {
               urhlup2.a(0.0, 0.5, Easings.f, true);
            }

            urhlup2.a();
            if (urhlup2.d() && urhlup2.i() == 0.0) {
               hashSet.add(livingEntity4);
            } else {
               this.updateAnimationPhase(livingEntity4, f);
               switch (this.mode.d()) {
                  case "Призраки":
                     this.renderGhosts(kvprd92, livingEntity4, (float)urhlup2.j());
                     break;
                  case "Круг":
                     this.renderCircle(kvprd92, livingEntity4, (float)urhlup2.j());
                     break;
                  case "Квадратик":
                     this.renderSquare(kvprd92, livingEntity4, (float)urhlup2.j());
                     break;
                  case "Орбита":
                     this.renderOrbit(kvprd92, livingEntity4, (float)urhlup2.j());
               }
            }
         } else {
            hashSet.add(livingEntity4);
         }
      }

      for (LivingEntity livingEntity5 : hashSet) {
         this.visibilityAnimations.remove(livingEntity5);
         this.rotationDegrees.remove(livingEntity5);
         this.animationPhase.remove(livingEntity5);
      }
   }

   private void a(Matrix4f matrix4f, Color color, boolean bl, float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, int n) {
      if (!bl) {
         BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
         bufferBuilder.vertex(matrix4f, f, f2, f3).color(color.getRed(), color.getGreen(), color.getBlue(), n);
         bufferBuilder.vertex(matrix4f, f4, f5, f6).color(color.getRed(), color.getGreen(), color.getBlue(), n * 3 / 4);
         bufferBuilder.vertex(matrix4f, f7, f8, f9).color(color.getRed(), color.getGreen(), color.getBlue(), n * 3 / 4);
         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      } else {
         Vector4f vector4f = matrix4f.transform(new Vector4f(f, f2, f3, 1.0F));
         Vector4f vector4f2 = matrix4f.transform(new Vector4f(f4, f5, f6, 1.0F));
         Vector4f vector4f3 = matrix4f.transform(new Vector4f(f7, f8, f9, 1.0F));
         float[] fArray = new float[]{
            vector4f.x,
            vector4f.y,
            vector4f.z,
            0.5F,
            0.0F,
            vector4f2.x,
            vector4f2.y,
            vector4f2.z,
            0.0F,
            1.0F,
            vector4f3.x,
            vector4f3.y,
            vector4f3.z,
            1.0F,
            1.0F
         };
         ShaderProgram.a(fArray, 3);
      }
   }

   private void a(
      Matrix4f matrix4f,
      Color color,
      boolean bl,
      float f,
      float f2,
      float f3,
      float f4,
      float f5,
      float f6,
      float f7,
      float f8,
      float f9,
      float f10,
      float f11,
      float f12,
      int n
   ) {
      this.a(matrix4f, color, bl, f, f2, f3, f4, f5, f6, f7, f8, f9, n);
      this.a(matrix4f, color, bl, f, f2, f3, f7, f8, f9, f10, f11, f12, n);
   }

   private String shaderName(ModeSetting s82syr2) {
      switch (s82syr2.d()) {
         case "Звёзды":
            return "block_starfield";
         case "Паутина":
            return "block_cobweb";
         case "Плазма":
            return "block_plasma";
         default:
            return "block_nebula";
      }
   }

   private float baseAnimationSpeed() {
      switch (this.mode.d()) {
         case "Призраки":
            return this.ghostSpeed.a();
         case "Круг":
            return this.circleSpeed.a();
         case "Квадратик":
            return this.squareSpeed.a();
         case "Орбита":
            return this.orbitSpeed.a();
         default:
            return 1.5F;
      }
   }

   private LivingEntity findTarget() {
      if (c.player != null && c.world != null) {
         LivingEntity livingEntity2 = HudServices.TARGETS.h();
         if (this.isRenderableTarget(livingEntity2)) {
            return livingEntity2;
         }

         Entity entity = c.targetedEntity;
         LivingEntity livingEntity;
         return entity instanceof LivingEntity && this.isRenderableTarget(livingEntity = (LivingEntity)entity) ? livingEntity : null;
      } else {
         return null;
      }
   }
}
