package haron.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.events.AttackTargetEvent;
import haron.events.ClientTickEvent;
import haron.events.WorldRenderPostEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.modules.visuals.killeffect.KillParticleBurstEmitter;
import haron.modules.visuals.killeffect.KillSoundScheduler;
import haron.modules.visuals.killeffect.KillTracker;
import haron.settings.BooleanSetting;
import haron.settings.NumberSetting;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexFormat;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

@ModuleInfo(a = "Kill Effect", b = "Эффекты при убийстве", c = ModuleCategory.VISUALS)
public class KillEffect extends HaronModule {
   private final BooleanSetting particles = new BooleanSetting("Частицы", true);
   private final NumberSetting particleCount = new NumberSetting("Кол-во частиц", 20.0F, 5.0F, 50.0F, 1.0F);
   private final BooleanSetting scanEffect = new BooleanSetting("Волна", true);
   private final NumberSetting scanSpeed = new NumberSetting("Скорость волны", 1.5F, 0.5F, 4.0F, 0.1F);
   private final BooleanSetting soundEnabled = new BooleanSetting("Звук", true);
   private final NumberSetting soundVolume = new NumberSetting("Громкость", 1.0F, 0.1F, 2.0F, 0.1F);
   private final KillTracker tracker = new KillTracker(2500L, this::onKill);
   private final KillParticleBurstEmitter particles2 = new KillParticleBurstEmitter();
   private final KillSoundScheduler sounds = new KillSoundScheduler();
   private float scanAlpha = 0.0F;
   private float scanRadius = 0.0F;
   private Vec3d scanPos = null;

   @EventHandler
   public void onTick(ClientTickEvent q8krcw2) {
      this.tracker.tick();
      this.sounds.tick();
      if (this.scanAlpha > 0.0F) {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         this.scanRadius = this.scanRadius + this.scanSpeed.a() * 0.15F;
         this.scanAlpha -= 0.015F;
         if (this.scanAlpha <= 0.0F) {
            this.scanAlpha = 0.0F;
            this.scanPos = null;
         }
      }
   }

   @EventHandler
   public void onAttack(AttackTargetEvent dt813s2) {
      if (dt813s2.getEntity() instanceof LivingEntity livingEntity) {
         this.tracker.remember(livingEntity, false);
      }
   }

   private void onKill(LivingEntity livingEntity) {
      if (livingEntity != null) {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         if (minecraftClient.player != null && minecraftClient.world != null) {
            float f = minecraftClient.getRenderTickCounter().getTickDelta(false);
            Vec3d vec3d = livingEntity.getLerpedPos(f).add(0.0, livingEntity.getHeight() / 2.0, 0.0);
            Color color = this.getAccentColor();
            if (this.particles.a()) {
               this.particles2.spawnBurst(vec3d, (int)this.particleCount.a(), 0, 0.8F, (int)this.particleCount.a(), 0.3F);
            }

            if (this.scanEffect.a()) {
               this.scanPos = vec3d;
               this.scanAlpha = 1.0F;
               this.scanRadius = 0.0F;
            }

            if (this.soundEnabled.a()) {
               this.sounds.schedule(null, this.soundVolume.a(), 0L);
            }
         }
      }
   }

   private void renderScan(WorldRenderPostEvent kvprd92, Vec3d vec3d, float f, float f2) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      Vec3d vec3d2 = minecraftClient.gameRenderer.getCamera().getPos();
      Color color = this.getAccentColor();
      int n = color.getRed();
      int n2 = color.getGreen();
      int n3 = color.getBlue();
      int n4 = (int)(f * 180.0F);
      MatrixStack matrixStack = kvprd92.a();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      Tessellator tessellator = Tessellator.getInstance();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableDepthTest();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      RenderSystem.lineWidth(2.5F);

      try {
         BufferBuilder bufferBuilder = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);

         for (int i = 0; i <= 360; i += 3) {
            double d = Math.toRadians(i);
            float f3 = (float)(vec3d.x + Math.cos(d) * f2 - vec3d2.x);
            float f4 = (float)(vec3d.z + Math.sin(d) * f2 - vec3d2.z);
            float f5 = (float)(vec3d.y - vec3d2.y);
            bufferBuilder.vertex(matrix4f, f3, f5, f4).color(n, n2, n3, n4);
         }

         BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      } catch (Exception var25) {
      } finally {
         GL11.glDisable(2848);
         RenderSystem.enableDepthTest();
         RenderSystem.disableBlend();
      }
   }

   private Color getAccentColor() {
      return ModuleManager.CLIENT_COLOR.n();
   }

   @EventHandler
   public void onWorldRender(WorldRenderPostEvent kvprd92) {
      if (this.scanAlpha > 0.0F && this.scanPos != null) {
         this.renderScan(kvprd92, this.scanPos, this.scanAlpha, this.scanRadius);
      }
   }

   @Override
   public void f() {
      super.f();
      this.tracker.clear();
      this.particles2.clear();
      this.sounds.clear();
      this.scanAlpha = 0.0F;
      this.scanPos = null;
   }
}
