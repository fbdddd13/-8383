package haron.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.events.WorldRenderPostEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.settings.BooleanSetting;
import haron.settings.ColorSetting;
import haron.settings.NumberSetting;
import haron.settings.SettingGroup;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexFormat;
import org.joml.Matrix4f;

@ModuleInfo(a = "China Hat", b = "Draws a cone hat above players.", c = ModuleCategory.VISUALS)
public class ChinaHat extends HaronModule {
   private static final int SEGMENTS = 90;
   private final NumberSetting height = new NumberSetting("Высота", 0.3F, 0.1F, 0.6F, 0.05F);
   private final NumberSetting radius = new NumberSetting("Радиус", 0.5F, 0.1F, 1.0F, 0.05F);
   private final BooleanSetting followSneaking = new BooleanSetting("Следовать за приседанием", true);
   private final SettingGroup colorGroup = new SettingGroup("Цвет");
   private final BooleanSetting useClientColor = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting color = new ColorSetting("Кастомный цвет", new Color(120, 80, 255)).a(() -> !this.useClientColor.a());

   private static void vertex(BufferBuilder bufferBuilder, Matrix4f matrix4f, double d, double d2, double d3, Color color, float f) {
      bufferBuilder.vertex(matrix4f, (float)d, (float)d2, (float)d3)
         .color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, f);
   }

   private void renderHat(MatrixStack matrixStack, Vec3d vec3d, PlayerEntity playerEntity, float f) {
      double d = MathHelper.lerp(f, playerEntity.prevX, playerEntity.getX()) - vec3d.x;
      double d2 = MathHelper.lerp(f, playerEntity.prevZ, playerEntity.getZ()) - vec3d.z;
      double d3 = MathHelper.lerp(f, playerEntity.prevY, playerEntity.getY()) - vec3d.y + playerEntity.getHeight() + 0.05;
      if (this.followSneaking.a() && playerEntity.isSneaking()) {
         d3 -= 0.18;
      }

      float f3 = this.radius.a();
      float f4 = this.height.a();
      Color color = this.n();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);

      for (int i = 0; i < 90; i++) {
         float f5 = i / 90.0F;
         float f2 = (i + 1) / 90.0F;
         double d4 = f5 * Math.PI * 2.0;
         double d5 = f2 * Math.PI * 2.0;
         Color color2 = this.a(color, f5);
         vertex(bufferBuilder, matrix4f, d, d3 + f4, d2, color2, 0.55F);
         vertex(bufferBuilder, matrix4f, d + Math.cos(d4) * f3, d3, d2 + Math.sin(d4) * f3, color2, 0.28F);
         vertex(bufferBuilder, matrix4f, d + Math.cos(d5) * f3, d3, d2 + Math.sin(d5) * f3, this.a(color, f2), 0.28F);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.lineWidth(2.0F);
      BufferBuilder bufferBuilder2 = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

      for (int i = 0; i < 90; i++) {
         float f2 = i / 90.0F;
         float f6 = (i + 1) / 90.0F;
         double d6 = f2 * Math.PI * 2.0;
         double d7 = f6 * Math.PI * 2.0;
         vertex(bufferBuilder2, matrix4f, d + Math.cos(d6) * f3, d3, d2 + Math.sin(d6) * f3, this.a(color, f2), 0.95F);
         vertex(bufferBuilder2, matrix4f, d + Math.cos(d7) * f3, d3, d2 + Math.sin(d7) * f3, this.a(color, f6), 0.95F);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder2.end());
      RenderSystem.lineWidth(1.0F);
   }

   private Color n() {
      return this.useClientColor.a() ? ModuleManager.CLIENT_COLOR.n() : this.color.a();
   }

   private Color a(Color color, float f) {
      float[] fArray = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
      fArray[0] = (fArray[0] + (float)Math.sin(f * Math.PI) * 0.08F) % 1.0F;
      if (fArray[0] < 0.0F) {
         fArray[0]++;
      }

      return Color.getHSBColor(fArray[0], fArray[1], fArray[2]);
   }

   @EventHandler
   public void a(WorldRenderPostEvent kvprd92) {
      if (c.player != null && c.world != null && c.gameRenderer != null) {
         MatrixStack matrixStack = kvprd92.a();
         Vec3d vec3d = c.gameRenderer.getCamera().getPos();
         matrixStack.push();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableCull();
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(false);

         for (AbstractClientPlayerEntity abstractClientPlayerEntity : c.world.getPlayers()) {
            if (!abstractClientPlayerEntity.isInvisible() && (abstractClientPlayerEntity != c.player || !c.options.getPerspective().isFirstPerson())) {
               this.renderHat(matrixStack, vec3d, abstractClientPlayerEntity, kvprd92.b());
            }
         }

         RenderSystem.depthMask(true);
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
         matrixStack.pop();
      }
   }
}
