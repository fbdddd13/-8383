package haron.modules.visuals;

import haron.events.WorldRenderPostEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.render.SkyShaderProgram;
import haron.settings.BooleanSetting;
import haron.settings.ColorSetting;
import haron.settings.ModeSetting;
import haron.settings.NumberSetting;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.render.Camera;
import ru.haron.mixin.accessor.GameRendererAccessor;

@ModuleInfo(a = "Sky Shader", b = "Replaces sky with procedural shader effects", c = ModuleCategory.VISUALS)
public class SkyShader extends HaronModule {
   private final ModeSetting mode = new ModeSetting("Режим", new String[]{"Облака", "Магма"}, "Облака");
   private final NumberSetting speed = new NumberSetting("Скорость", 0.15F, 0.0F, 2.0F, 0.01F);
   private final NumberSetting density = new NumberSetting("Плотность", 0.55F, 0.0F, 1.0F, 0.01F);
   private final NumberSetting scale = new NumberSetting("Масштаб", 3.0F, 0.5F, 10.0F, 0.1F);
   private final BooleanSetting useClientColor = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting skyColor = new ColorSetting("Кастомный цвет", new Color(45, 55, 65)).a(() -> !this.useClientColor.get());
   private final BooleanSetting hideVanillaSky = new BooleanSetting("Скрыть ванильное небо", false);

   public float getDensity() {
      return this.density.a();
   }

   public float getScale() {
      return this.scale.a();
   }

   public float getSpeed() {
      return this.speed.a();
   }

   public int getSkyMode() {
      return this.mode.d().equals("Магма") ? 1 : 0;
   }

   public Color getSkyColor() {
      return this.useClientColor.get() ? ModuleManager.CLIENT_COLOR.n() : this.skyColor.getColor();
   }

   public boolean isHideVanillaSky() {
      int n = 157;
      return this.hideVanillaSky.get();
   }

   @EventHandler
   public void onWorldRender(WorldRenderPostEvent kvprd92) {
      if (c.player != null && c.gameRenderer != null) {
         Camera camera = c.gameRenderer.getCamera();
         float f = camera.getYaw();
         float f2 = camera.getPitch();
         float f3 = ((GameRendererAccessor)c.gameRenderer).haron$getFov(camera, c.getRenderTickCounter().getTickDelta(true), true);
         SkyShaderProgram.get().render(this.getSpeed(), this.getDensity(), this.getScale(), this.getSkyColor(), f, f2, f3, this.getSkyMode());
      }
   }
}
