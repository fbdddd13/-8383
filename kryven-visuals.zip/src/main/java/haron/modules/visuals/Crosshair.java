package haron.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.core.BooleanCoercion;
import haron.events.HudRenderPostEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.render.ScaledGuiProjection;
import haron.settings.BooleanSetting;
import haron.settings.ColorSetting;
import haron.settings.NumberSetting;
import haron.settings.SettingGroup;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.VertexFormat;
import org.joml.Matrix4f;

@ModuleInfo(a = "Crosshair", b = "Настраивает отображение прицела", c = ModuleCategory.VISUALS)
public class Crosshair extends HaronModule {
   private final NumberSetting e = new NumberSetting("Длина", 3.0F, 1.0F, 15.0F, 1.0F);
   private final NumberSetting f = new NumberSetting("Толщина", 1.0F, 1.0F, 10.0F, 1.0F);
   private final NumberSetting g = new NumberSetting("Отступ", 0.0F, 0.0F, 10.0F, 1.0F);
   private final SettingGroup h = new SettingGroup("Поведение");
   private final BooleanSetting i = new BooleanSetting("Обводка", true);
   private final BooleanSetting j = new BooleanSetting("Точка", false);
   private final BooleanSetting k = new BooleanSetting("Менять цвет при наводке", true);
   private final BooleanSetting l = new BooleanSetting("Динамический", false);
   private final SettingGroup m = new SettingGroup("Цвет");
   private final BooleanSetting n = new BooleanSetting("Цвет клиента", false);
   private final ColorSetting o = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> BooleanCoercion.from(this.n.a() ? 0 : 1));
   public static int a;
   public static boolean b;

   private boolean n() {
      HitResult hitResult = c.crosshairTarget;
      return hitResult != null && hitResult.getType() == HitResult.Type.ENTITY && hitResult instanceof EntityHitResult
         ? ((EntityHitResult)hitResult).getEntity() instanceof LivingEntity
         : false;
   }

   private void a(MatrixStack matrixStack, float f, float f2, float f3, float f4, Color color) {
      float f5 = f + f3;
      float f6 = f2 + f4;
      float f7 = color.getRed() / 255.0F;
      float f8 = color.getGreen() / 255.0F;
      float f9 = color.getBlue() / 255.0F;
      float f10 = color.getAlpha() / 255.0F;
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      bufferBuilder.vertex(matrix4f, f, f6, 0.0F).color(f7, f8, f9, f10);
      bufferBuilder.vertex(matrix4f, f5, f6, 0.0F).color(f7, f8, f9, f10);
      bufferBuilder.vertex(matrix4f, f5, f2, 0.0F).color(f7, f8, f9, f10);
      bufferBuilder.vertex(matrix4f, f, f2, 0.0F).color(f7, f8, f9, f10);
      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.disableBlend();
   }

   @EventHandler(priority = -200)
   private void a(HudRenderPostEvent f3zcs42) {
      if (c.options.getPerspective() == Perspective.FIRST_PERSON && c.player != null) {
         ScaledGuiProjection.a(2.0);

         try {
            float f = c.getWindow().getWidth() / 4.0F;
            float f2 = c.getWindow().getHeight() / 4.0F;
            float f3 = 1.0F - c.player.getAttackCooldownProgress(f3zcs42.d());
            Color color = this.o();
            if (this.k.a() && this.n()) {
               color = new Color(255, 64, 64);
            }

            this.a(f3zcs42.a(), f, f2, f3, color);
         } finally {
            ScaledGuiProjection.a();
         }
      }
   }

   private void a(MatrixStack matrixStack, float f, float f2, float f3, Color color) {
      float f4 = !this.l.a() ? this.g.a() : this.g.a() + 8.0F * f3;
      float f5 = this.f.a();
      float f6 = this.e.a();
      if (this.i.a()) {
         Color color2 = Color.BLACK;
         this.a(matrixStack, f + f4 - 0.5F, f2 - f5 / 2.0F - 0.5F, f6 + 1.0F, f5 + 1.0F, color2);
         this.a(matrixStack, f - f4 - f6 - 0.5F, f2 - f5 / 2.0F - 0.5F, f6 + 1.0F, f5 + 1.0F, color2);
         this.a(matrixStack, f - f5 / 2.0F - 0.5F, f2 - f4 - f6 - 0.5F, f5 + 1.0F, f6 + 1.0F, color2);
         this.a(matrixStack, f - f5 / 2.0F - 0.5F, f2 + f4 - 0.5F, f5 + 1.0F, f6 + 1.0F, color2);
         if (this.j.a()) {
            this.a(matrixStack, f - 1.0F - 0.5F, f2 - 1.0F - 0.5F, 3.0F, 3.0F, color2);
         }
      }

      this.a(matrixStack, f + f4, f2 - f5 / 2.0F, f6, f5, color);
      this.a(matrixStack, f - f4 - f6, f2 - f5 / 2.0F, f6, f5, color);
      this.a(matrixStack, f - f5 / 2.0F, f2 - f4 - f6, f5, f6, color);
      this.a(matrixStack, f - f5 / 2.0F, f2 + f4, f5, f6, color);
      if (this.j.a()) {
         this.a(matrixStack, f - 1.0F, f2 - 1.0F, 2.0F, 2.0F, color);
      }
   }

   private Color o() {
      return this.n.a() ? ModuleManager.CLIENT_COLOR.n() : this.o.a();
   }
}
