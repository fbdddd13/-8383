package haron.modules.visuals;

import haron.core.BooleanCoercion;
import haron.events.RenderTickEvent;
import haron.hud.core.HudServices;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.settings.BooleanSetting;
import haron.settings.ColorSetting;
import haron.settings.ModeSetting;
import haron.settings.NumberSetting;
import haron.settings.SettingGroup;
import haron.util.ColorUtils;
import java.awt.Color;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.Identifier;

@ModuleInfo(a = "World Particles", b = "Падающие частицы в мире", c = ModuleCategory.VISUALS)
public class WorldParticles extends HaronModule {
   private final ModeSetting e = new ModeSetting("Тип частиц", new String[]{"Сердце", "Искра", "Снежинка", "Сияние", "Линия", "Доллар"}, "Снежинка");
   private final ModeSetting f = new ModeSetting("Режим физики", new String[]{"Реалистичная", "Без коллизий", "Без физики"}, "Без физики");
   private final SettingGroup g = new SettingGroup("Спавн");
   private final NumberSetting h = new NumberSetting("Частота спавна", 5.0F, 1.0F, 10.0F, 1.0F);
   private final NumberSetting i = new NumberSetting("Количество за спавн", 5.0F, 1.0F, 15.0F, 1.0F);
   private final NumberSetting j = new NumberSetting("Радиус спавна", 30.0F, 5.0F, 50.0F, 1.0F);
   private final NumberSetting k = new NumberSetting("Высота спавна", 10.0F, 5.0F, 30.0F, 1.0F);
   private final SettingGroup l = new SettingGroup("Частицы");
   private final NumberSetting m = new NumberSetting("Размер", 0.25F, 0.1F, 1.0F, 0.05F);
   private final NumberSetting n = new NumberSetting("Время жизни", 100.0F, 30.0F, 300.0F, 10.0F);
   private final NumberSetting o = new NumberSetting("Сила притяжения", 0.02F, 0.0F, 0.1F, 0.01F);
   private final BooleanSetting p = new BooleanSetting("Горизонтальное движение", true);
   private final NumberSetting q = new NumberSetting("Скорость движения", 0.05F, 0.0F, 0.2F, 0.01F).a(() -> this.p.a());
   private final SettingGroup r = new SettingGroup("Цвет");
   private final BooleanSetting s = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting t = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> {
      int n = 848;
      return BooleanCoercion.from(this.s.a() ? 0 : 1);
   });
   private long u = 0L;
   public static int a;
   public static boolean b;

   private void n() {
      Vec3d vec3d = c.player.getPos();
      int n = this.i.b();

      for (int i = 0; i < n; i++) {
         HudServices.PARTICLES
            .spawn(
               new Vec3d(
                  vec3d.x + ThreadLocalRandom.current().nextDouble(-this.j.a(), this.j.a()),
                  vec3d.y + (!this.f.b("Без физики") ? this.k.a() : ThreadLocalRandom.current().nextDouble(0.0, this.k.a())),
                  vec3d.z + ThreadLocalRandom.current().nextDouble(-this.j.a(), this.j.a())
               ),
               !this.p.a()
                  ? Vec3d.ZERO
                  : new Vec3d(
                     ThreadLocalRandom.current().nextDouble(-this.q.a(), this.q.a()), 0.0, ThreadLocalRandom.current().nextDouble(-this.q.a(), this.q.a())
                  ),
               this.n.b(),
               this.m.a() + (ThreadLocalRandom.current().nextFloat() * 0.1F - 0.05F),
               this.p(),
               ColorUtils.a(this.o().getRGB()),
               this.o.a(),
               this.f.d()
            );
      }
   }

   @EventHandler
   public void a(RenderTickEvent zv7i6c2) {
      if (c.player != null && c.world != null) {
         long l = System.currentTimeMillis();
         if (l - this.u >= 1000.0 / this.h.a()) {
            this.n();
            this.u = l;
         }
      }
   }

   private Color o() {
      return !this.s.a() ? this.t.a() : ModuleManager.CLIENT_COLOR.n();
   }

   private Identifier p() {
      switch (this.e.d()) {
         case "Сердце":
            return Identifier.of("haron", "textures/particle/heart.png");
         case "Искра":
            return Identifier.of("haron", "textures/particle/sparkle.png");
         case "Снежинка":
            return Identifier.of("haron", "textures/particle/snowflake.png");
         case "Сияние":
            return Identifier.of("haron", "textures/particle/glow.png");
         case "Линия":
            return Identifier.of("haron", "textures/particle/line.png");
         case "Доллар":
            return Identifier.of("haron", "textures/particle/dollar.png");
         default:
            return Identifier.of("haron", "textures/particle/snowflake.png");
      }
   }
}
