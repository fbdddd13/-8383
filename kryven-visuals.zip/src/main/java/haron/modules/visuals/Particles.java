package haron.modules.visuals;

import haron.core.BooleanCoercion;
import haron.events.AttackTargetEvent;
import haron.events.RenderTickEvent;
import haron.events.TotemPopEvent;
import haron.hud.core.HudServices;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.settings.BooleanSetting;
import haron.settings.ColorSetting;
import haron.settings.ModeSetting;
import haron.settings.NumberSetting;
import haron.settings.SettingGroup;
import haron.util.ColorUtils;
import java.awt.Color;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.Identifier;

@ModuleInfo(a = "Particles", b = "Создаёт частицы при выполнении условий", c = ModuleCategory.VISUALS)
public class Particles extends HaronModule {
   private long H;
   private Vec3d I;
   private LivingEntity K;
   public static int a;
   public static boolean b;
   private final ModeSetting e = new ModeSetting("Условия", new String[]{"При ударе", "При сносе тотема"}, new int[]{0});
   private final BooleanSetting f = new BooleanSetting("Индивидуальные настройки", false);
   private final SettingGroup g = new SettingGroup("Общие").a(() -> BooleanCoercion.from(this.f.a() ? 0 : 1));
   private final ModeSetting h = new ModeSetting("Тип частиц", new String[]{"Сердце", "Искра", "Снежинка", "Сияние", "Линия", "Доллар"}, "Сердце")
      .a(() -> BooleanCoercion.from(this.f.a() ? 0 : 1));
   private final ModeSetting i = new ModeSetting("Режим физики", new String[]{"Реалистичная", "Без коллизий", "Без физики", "Притяжение"}, "Реалистичная")
      .a(() -> BooleanCoercion.from(this.f.a() ? 0 : 1));
   private final NumberSetting j = new NumberSetting("Количество", 4.0F, 1.0F, 20.0F, 1.0F).a(() -> BooleanCoercion.from(this.f.a() ? 0 : 1));
   private final NumberSetting k = new NumberSetting("Размер", 0.3F, 0.1F, 0.75F, 0.05F).a(() -> BooleanCoercion.from(this.f.a() ? 0 : 1));
   private final NumberSetting l = new NumberSetting("Время жизни", 20.0F, 10.0F, 50.0F, 5.0F).a(() -> BooleanCoercion.from(this.f.a() ? 0 : 1));
   private final NumberSetting m = new NumberSetting("Сила разлёта", 0.3F, 0.15F, 0.35F, 0.01F).a(() -> {
      int n = this.f.a() ? 0 : 1;
      return BooleanCoercion.from(n);
   });
   private final BooleanSetting n = new BooleanSetting("Цвет клиента", BooleanCoercion.from(45027861)).a(() -> BooleanCoercion.from(this.f.a() ? 0 : 1));
   private final ColorSetting o = new ColorSetting("Конечный цвет", Color.WHITE).a(() -> BooleanCoercion.from(!this.n.a() && !this.f.a() ? 1 : 0));
   private final SettingGroup p = new SettingGroup("Удар").a(() -> this.f.a() && this.e.b("При ударе") ? true : false);
   private final ModeSetting q = new ModeSetting("Тип частиц", new String[]{"Сердце", "Искра", "Снежинка", "Сияние", "Линия", "Доллар"}, "Сердце")
      .a(() -> this.f.a() && this.e.b("При ударе") ? true : false);
   private final ModeSetting r = new ModeSetting("Режим физики", new String[]{"Реалистичная", "Без коллизий", "Без физики", "Притяжение"}, "Реалистичная")
      .a(() -> this.f.a() && this.e.b("При ударе") ? true : false);
   private final NumberSetting s = new NumberSetting("Количество", 4.0F, 1.0F, 20.0F, 1.0F).a(() -> this.f.a() && this.e.b("При ударе") ? true : false);
   private final NumberSetting t = new NumberSetting("Размер", 0.3F, 0.1F, 0.75F, 0.05F).a(() -> this.f.a() && this.e.b("При ударе") ? true : false);
   private final NumberSetting u = new NumberSetting("Время жизни", 20.0F, 10.0F, 50.0F, 5.0F).a(() -> this.f.a() && this.e.b("При ударе") ? true : false);
   private final NumberSetting v = new NumberSetting("Сила разлёта", 0.3F, 0.15F, 0.35F, 0.01F).a(() -> this.f.a() && this.e.b("При ударе") ? true : false);
   private final BooleanSetting w = new BooleanSetting("Цвет клиента", true).a(() -> this.f.a() && this.e.b("При ударе") ? true : false);
   private final ColorSetting x = new ColorSetting("Конечный цвет", Color.WHITE).a(() -> this.f.a() && this.e.b("При ударе") && !this.w.a() ? true : false);
   private final SettingGroup y = new SettingGroup("Снос тотема").a(() -> this.f.a() && this.e.b("При сносе тотема") ? true : false);
   private final ModeSetting z = new ModeSetting("Тип частиц", new String[]{"Сердце", "Искра", "Снежинка", "Сияние", "Линия", "Доллар"}, "Сердце")
      .a(() -> this.f.a() && this.e.b("При сносе тотема") ? true : false);
   private final ModeSetting A = new ModeSetting("Режим физики", new String[]{"Реалистичная", "Без коллизий", "Без физики", "Притяжение"}, "Реалистичная")
      .a(() -> this.f.a() && this.e.b("При сносе тотема") ? true : false);
   private final NumberSetting B = new NumberSetting("Количество", 4.0F, 1.0F, 20.0F, 1.0F).a(() -> this.f.a() && this.e.b("При сносе тотема") ? true : false);
   private final NumberSetting C = new NumberSetting("Размер", 0.3F, 0.1F, 0.75F, 0.05F).a(() -> this.f.a() && this.e.b("При сносе тотема") ? true : false);
   private final NumberSetting D = new NumberSetting("Время жизни", 20.0F, 10.0F, 50.0F, 5.0F)
      .a(() -> this.f.a() && this.e.b("При сносе тотема") ? true : false);
   private final NumberSetting E = new NumberSetting("Сила разлёта", 0.3F, 0.15F, 0.35F, 0.01F)
      .a(() -> this.f.a() && this.e.b("При сносе тотема") ? true : false);
   private final BooleanSetting F = new BooleanSetting("Цвет клиента", BooleanCoercion.from(1175694691))
      .a(() -> this.f.a() && this.e.b("При сносе тотема") ? true : false);
   private final ColorSetting G = new ColorSetting("Конечный цвет", Color.WHITE)
      .a(() -> this.f.a() && this.e.b("При сносе тотема") && !this.F.a() ? true : false);
   private boolean J = false;

   private String e(String string) {
      switch (string) {
         case "attack":
            return this.r.d();
         case "totem":
            return this.A.d();
         default:
            return this.i.d();
      }
   }

   private float b(String string) {
      switch (string) {
         case "attack":
            return this.t.a();
         case "totem":
            return this.C.a();
         default:
            return this.k.a();
      }
   }

   private int c(String string) {
      switch (string) {
         case "attack":
            return this.u.b();
         case "totem":
            return this.D.b();
         default:
            return this.l.b();
      }
   }

   @Override
   public void f() {
      super.f();
      this.J = false;
      this.K = null;
   }

   private Color f(String string) {
      if (this.f.a()) {
         switch (string) {
            case "attack":
               return !this.w.a() ? this.x.a() : ModuleManager.CLIENT_COLOR.n();
            case "totem":
               return this.F.a() ? ModuleManager.CLIENT_COLOR.n() : this.G.a();
         }
      }

      return !this.n.a() ? this.o.a() : ModuleManager.CLIENT_COLOR.n();
   }

   private double d(String string) {
      switch (string) {
         case "attack":
            return this.v.a();
         case "totem":
            return this.E.a();
         default:
            return this.m.a();
      }
   }

   @EventHandler
   public void a(AttackTargetEvent dt813s2) {
      if (this.e.b("При ударе") && dt813s2.a() != c.player && dt813s2.a() instanceof LivingEntity) {
         LivingEntity livingEntity = (LivingEntity)dt813s2.a();
         Vec3d vec3d = new Vec3d(
            livingEntity.getX(),
            livingEntity.getY() + livingEntity.getEyeHeight(livingEntity.getPose()) / 2.0F,
            livingEntity.getZ()
         );
         int n = this.f.a() ? this.s.b() * 3 : this.j.b() * 3;
         int n2 = n;

         for (int i = 0; i < n2; i++) {
            this.a(vec3d, 0.02, this.f("attack").getRGB(), "attack");
         }
      }
   }

   @EventHandler
   public void a(TotemPopEvent bjffkp2) {
      if (this.e.b("При сносе тотема")) {
         this.K = bjffkp2.a();
         this.I = new Vec3d(this.K.getX(), this.K.getY() + this.K.getEyeHeight(this.K.getPose()), this.K.getZ());
         this.H = System.currentTimeMillis();
         this.J = true;
      }
   }

   private int a(String string) {
      switch (string) {
         case "attack":
            return this.s.b();
         case "totem":
            return this.B.b();
         default:
            return this.j.b();
      }
   }

   private void a(Vec3d vec3d, double d, int n, String string) {
      int n2 = ColorUtils.a(n);
      int n3 = !this.f.a() ? this.j.b() : this.a(string);
      int n4 = !this.f.a() ? this.l.b() : this.c(string);
      int n5 = (n4 & -11) - (~n4 & 10);
      int n6 = (n4 | 10) + (n4 & 10);
      float f = !this.f.a() ? this.k.a() : this.b(string);
      float f2 = f - 0.05F;
      float f3 = f + 0.05F;
      double d2 = !this.f.a() ? this.m.a() : this.d(string);
      String string2 = !this.f.a() ? this.i.d() : this.e(string);

      for (int i = 0; i < n3; i++) {
         int n7 = ThreadLocalRandom.current().nextInt(n5, n6);
         float f4 = f2 + ThreadLocalRandom.current().nextFloat() * (f3 - f2);
         Vec3d vec3d2 = new Vec3d(
            ThreadLocalRandom.current().nextDouble(-d, d), ThreadLocalRandom.current().nextDouble(0.0, d), ThreadLocalRandom.current().nextDouble(-d, d)
         );
         if (vec3d2.lengthSquared() > 0.0) {
            vec3d2 = vec3d2.normalize().multiply(ThreadLocalRandom.current().nextDouble(0.005, d2));
         }

         HudServices.PARTICLES.spawn(vec3d, vec3d2, n7, f4, this.g(string), n2, string2);
      }
   }

   @EventHandler
   public void a(RenderTickEvent zv7i6c2) {
      if (this.e.b("При сносе тотема") && this.J) {
         if (System.currentTimeMillis() - this.H > 1500L) {
            this.J = false;
            this.K = null;
            return;
         }

         if (this.K != null && this.K.isAlive()) {
            this.I = new Vec3d(this.K.getX(), this.K.getY() + this.K.getHeight() / 2.0, this.K.getZ());
         }

         for (int i = 0; i < 2; i++) {
            Vec3d vec3d;
            while (
               (vec3d = new Vec3d(
                        ThreadLocalRandom.current().nextDouble(-1.0, 1.0),
                        ThreadLocalRandom.current().nextDouble(0.1, 1.0),
                        ThreadLocalRandom.current().nextDouble(-1.0, 1.0)
                     ))
                     .lengthSquared()
                  > 1.0
            ) {
            }

            HudServices.PARTICLES
               .spawn(
                  this.I,
                  vec3d.normalize().multiply(0.4),
                  !this.f.a() ? this.l.b() : this.D.b(),
                  !this.f.a() ? this.k.a() : this.C.a(),
                  this.g("totem"),
                  !ThreadLocalRandom.current().nextBoolean() ? 327424 : 16776983,
                  !this.f.a() ? this.i.d() : this.A.d()
               );
         }
      }
   }

   private Identifier g(String string) {
      String string2;
      if (this.f.a()) {
         switch (string) {
            case "attack":
               string2 = this.q.d();
               break;
            case "totem":
               string2 = this.z.d();
               break;
            default:
               string2 = this.h.d();
         }
      } else {
         string2 = this.h.d();
      }

      switch (string2) {
         case "Снежинка":
            return Identifier.of("haron", "textures/particle/snowflake.png");
         case "Доллар":
            return Identifier.of("haron", "textures/particle/dollar.png");
         case "Линия":
            return Identifier.of("haron", "textures/particle/line.png");
         case "Искра":
            return Identifier.of("haron", "textures/particle/sparkle.png");
         case "Сердце":
            return Identifier.of("haron", "textures/particle/heart.png");
         case "Сияние":
            return Identifier.of("haron", "textures/particle/glow.png");
         default:
            return Identifier.of("haron", "textures/particle/heart.png");
      }
   }
}
