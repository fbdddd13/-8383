package haron.modules.visuals;

import haron.events.ClientTickEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.option.SimpleOption;

@ModuleInfo(a = "Full Bright", b = "Increases world brightness", c = ModuleCategory.VISUALS)
public class FullBright extends HaronModule {
   private static final double FULL_BRIGHT_GAMMA = 9999.0;
   private double previousGamma = 1.0;

   @Override
   public void e() {
      if (c.options != null) {
         this.previousGamma = (Double)c.options.getGamma().getValue();
         c.options.getGamma().setValue(9999.0);
      }
   }

   @Override
   public void f() {
      if (c.options != null) {
         c.options.getGamma().setValue(this.previousGamma);
      }

      super.f();
   }

   @EventHandler
   public void a(ClientTickEvent q8krcw2) {
      if (c.options != null) {
         SimpleOption<Double> simpleOption = c.options.getGamma();
         if ((Double)simpleOption.getValue() != 9999.0) {
            simpleOption.setValue(9999.0);
         }
      }
   }
}
