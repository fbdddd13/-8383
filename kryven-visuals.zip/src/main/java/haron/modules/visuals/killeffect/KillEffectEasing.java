package haron.modules.visuals.killeffect;

public final class KillEffectEasing {
   public static float sineInOut(float f) {
      return -((float)(Math.cos(Math.PI * f) - 1.0)) / 2.0F;
   }

   public static float sineOut(float f) {
      return (float)Math.sin(f * Math.PI / 2.0);
   }

   public static float quintOut(float f) {
      int n = 211;
      return 1.0F - (float)Math.pow(1.0F - f, 5.0);
   }

   private KillEffectEasing() {
   }
}
