package haron.modules.visuals.killeffect;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;

public final class KillParticleBurstEmitter {
   public void tick() {
   }

   public void spawnBurst(Vec3d vec3d, int n, int n2, float f, int n3, float f2) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.world != null && vec3d != null) {
         ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();
         float f3 = f / Math.max(n / 50.0F, 1.0F) * 0.7F;
         int n4 = Math.clamp(n3, 0, 32);

         for (int i = 0; i < n4; i++) {
            minecraftClient.world
               .addParticle(
                  ParticleTypes.END_ROD,
                  vec3d.x,
                  vec3d.y,
                  vec3d.z,
                  threadLocalRandom.nextDouble(-f3, f3),
                  threadLocalRandom.nextDouble(-f3 * 0.25, f3 * 0.55) - f2,
                  threadLocalRandom.nextDouble(-f3, f3)
               );
         }
      }
   }

   public void clear() {
   }
}
