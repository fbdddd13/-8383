package haron.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.events.WorldRenderPostEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.settings.BooleanSetting;
import haron.settings.ColorSetting;
import haron.settings.NumberSetting;
import haron.settings.SettingGroup;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexFormat;
import org.joml.Matrix4f;

@ModuleInfo(a = "Nimb", b = "Draws a halo above the player.", c = ModuleCategory.VISUALS)
public class Nimb extends HaronModule {
   private static final int SEGMENTS = 72;
   private final NumberSetting lineWidth = new NumberSetting("Толщина линии", 1.5F, 1.0F, 3.0F, 0.5F);
   private final NumberSetting radius = new NumberSetting("Радиус", 0.28F, 0.18F, 0.55F, 0.02F);
   private final NumberSetting yOffset = new NumberSetting("Смещение Y", 0.05F, -0.3F, 0.25F, 0.02F);
   private final SettingGroup colorGroup = new SettingGroup("Цвет");
   private final BooleanSetting useClientColor = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting color = new ColorSetting("Кастомный цвет", Color.WHITE).a(() -> !this.useClientColor.a());
   private static final double MAX_RENDER_DISTANCE_SQ = 16384.0;
   private static double[] cosTable = new double[73];
   private static double[] sinTable = new double[73];

   private Color n() {
      return this.useClientColor.a() ? ModuleManager.CLIENT_COLOR.n() : this.color.a();
   }

   @EventHandler
   public void a(WorldRenderPostEvent kvprd92) {
      if (c.player != null && c.world != null && c.gameRenderer != null) {
         MatrixStack matrixStack = kvprd92.a();
         Vec3d vec3d = c.gameRenderer.getCamera().getPos();
         boolean bl = c.options.getPerspective().isFirstPerson();
         double d = c.player.getX();
         double d2 = c.player.getY();
         double d3 = c.player.getZ();
         Color color = this.n();
         float f = color.getRed() / 255.0F;
         float f2 = color.getGreen() / 255.0F;
         float f3 = color.getBlue() / 255.0F;
         float f4 = 0.9F;
         float f5 = kvprd92.b();
         float f6 = this.yOffset.a();
         matrixStack.push();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableCull();
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(false);
         RenderSystem.lineWidth(this.lineWidth.a());
         RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
         Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
         BufferBuilder bufferBuilder = null;

         for (AbstractClientPlayerEntity abstractClientPlayerEntity : c.world.getPlayers()) {
            double d4;
            double d5;
            double d6;
            if (!abstractClientPlayerEntity.isInvisible()
               && (abstractClientPlayerEntity != c.player || !bl)
               && !(
                  (d6 = abstractClientPlayerEntity.getX() - d) * d6
                        + (d5 = abstractClientPlayerEntity.getY() - d2) * d5
                        + (d4 = abstractClientPlayerEntity.getZ() - d3) * d4
                     > 16384.0
               )) {
               float f7 = this.radius.a();
               double d7 = MathHelper.lerp(f5, abstractClientPlayerEntity.prevX, abstractClientPlayerEntity.getX()) - vec3d.x;
               double d8 = MathHelper.lerp(f5, abstractClientPlayerEntity.prevZ, abstractClientPlayerEntity.getZ()) - vec3d.z;
               double d9 = MathHelper.lerp(f5, abstractClientPlayerEntity.prevY, abstractClientPlayerEntity.getY())
                  - vec3d.y
                  + abstractClientPlayerEntity.getEyeHeight(abstractClientPlayerEntity.getPose())
                  + 0.05
                  + f6;
               if (bufferBuilder == null) {
                  bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
               }

               for (int i = 0; i < 72; i++) {
                  double d10 = d7 + cosTable[i] * f7;
                  double d11 = d8 + sinTable[i] * f7;
                  double d12 = d7 + cosTable[i + 1] * f7;
                  double d13 = d8 + sinTable[i + 1] * f7;
                  bufferBuilder.vertex(matrix4f, (float)d10, (float)d9, (float)d11).color(f, f2, f3, 0.9F);
                  bufferBuilder.vertex(matrix4f, (float)d12, (float)d9, (float)d13).color(f, f2, f3, 0.9F);
               }
            }
         }

         if (bufferBuilder != null) {
            BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
         }

         RenderSystem.lineWidth(1.0F);
         RenderSystem.depthMask(true);
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
         matrixStack.pop();
      }
   }

   static {
      for (int i = 0; i <= 72; i++) {
         double d = i / 72.0 * Math.PI * 2.0;
         cosTable[i] = Math.cos(d);
         sinTable[i] = Math.sin(d);
      }
   }
}
