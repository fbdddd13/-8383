package haron.modules.visuals;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.render.HandShaderProgram;
import haron.settings.BooleanSetting;
import haron.settings.ColorSetting;
import haron.settings.ModeSetting;
import haron.settings.NumberSetting;
import java.awt.Color;

@ModuleInfo(a = "Hand Shader", b = "Applies procedural shader effect on held items/hand", c = ModuleCategory.VISUALS)
public class HandShader extends HaronModule {
   private final ModeSetting mode = new ModeSetting("Режим", new String[]{"Облака", "Магма"}, "Облака");
   private final NumberSetting speed = new NumberSetting("Скорость", 0.15F, 0.0F, 2.0F, 0.01F);
   private final NumberSetting density = new NumberSetting("Плотность", 0.55F, 0.0F, 1.0F, 0.01F);
   private final NumberSetting scale = new NumberSetting("Масштаб", 3.0F, 0.5F, 10.0F, 0.1F);
   private final NumberSetting opacity = new NumberSetting("Прозрачность", 0.55F, 0.0F, 1.0F, 0.01F);
   private final BooleanSetting useClientColor = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting skyColor = new ColorSetting("Кастомный цвет", new Color(45, 55, 65)).a(() -> !this.useClientColor.get());

   public float getOpacity() {
      return this.opacity.a();
   }

   public float getDensity() {
      return this.density.a();
   }

   public float getScale() {
      return this.scale.a();
   }

   public float getSpeed() {
      return this.speed.a();
   }

   public int getSkyMode() {
      return this.mode.d().equals("Магма") ? 1 : 0;
   }

   public Color getSkyColor() {
      return this.useClientColor.get() ? ModuleManager.CLIENT_COLOR.n() : this.skyColor.getColor();
   }

   public void renderShader() {
      HandShaderProgram.get().render(this.getSpeed(), this.getDensity(), this.getScale(), this.getSkyColor(), this.getSkyMode(), this.getOpacity());
   }
}
