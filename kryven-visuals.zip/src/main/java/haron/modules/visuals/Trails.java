package haron.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.core.BooleanCoercion;
import haron.events.ClientTickEvent;
import haron.events.RenderTickEvent;
import haron.events.WorldRenderPostEvent;
import haron.hud.core.HudServices;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.settings.BooleanSetting;
import haron.settings.ColorSetting;
import haron.settings.ModeSetting;
import haron.settings.NumberSetting;
import haron.settings.SettingGroup;
import haron.util.ColorUtils;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexFormat;
import org.joml.Matrix4f;

@ModuleInfo(a = "Trails", b = "Отображает след игрока", c = ModuleCategory.VISUALS)
public class Trails extends HaronModule {
   private double previousX;
   private double previousY;
   private double previousZ;
   private final ModeSetting movementMode = new ModeSetting("Режим ходьбы", new String[]{"Только след", "Только частицы", "След + частицы"}, "Только след");
   private final BooleanSetting showInFirstPerson = new BooleanSetting("Показывать от первого лица", false);
   private final SettingGroup trailSettings = new SettingGroup("След").a(() -> this.movementMode.b("След + частицы"));
   private final ModeSetting trailStyle = new ModeSetting("Тип следа", new String[]{"Сплошной", "Пунктир", "Затухающий"}, "Сплошной")
      .a(() -> !this.movementMode.b("Только след") && !this.movementMode.b("След + частицы") ? false : true);
   private final NumberSetting trailLength = new NumberSetting("Длина следа", 5.0F, 1.0F, 20.0F, 1.0F)
      .a(() -> !this.movementMode.b("Только след") && !this.movementMode.b("След + частицы") ? false : true);
   private final NumberSetting trailWidth = new NumberSetting("Ширина следа", 0.1F, 0.05F, 0.5F, 0.01F)
      .a(() -> !this.movementMode.b("Только след") && !this.movementMode.b("След + частицы") ? false : true);
   private final BooleanSetting useClientTrailColor = new BooleanSetting("Цвет клиента", true)
      .a(() -> !this.movementMode.b("Только след") && !this.movementMode.b("След + частицы") ? false : true);
   private final ColorSetting customTrailColor = new ColorSetting("Кастомный цвет", Color.WHITE)
      .a(() -> (this.movementMode.b("Только след") || this.movementMode.b("След + частицы")) && !this.useClientTrailColor.a() ? true : false);
   private final SettingGroup particleSettings = new SettingGroup("Частицы").a(() -> this.movementMode.b("След + частицы"));
   private final ModeSetting particleSpawnMode = new ModeSetting("Режим частиц", new String[]{"Под ногами", "По телу"}, "Под ногами")
      .a(() -> !this.movementMode.b("Только частицы") && !this.movementMode.b("След + частицы") ? false : true);
   private final ModeSetting particleType = new ModeSetting("Тип частиц", new String[]{"Сердце", "Искра", "Снежинка", "Сияние", "Линия", "Доллар"}, "Сердце")
      .a(() -> !this.movementMode.b("Только частицы") && !this.movementMode.b("След + частицы") ? false : true);
   private final ModeSetting particlePhysics = new ModeSetting(
         "Режим физики", new String[]{"Реалистичная", "Без коллизий", "Без физики", "Притяжение"}, "Реалистичная"
      )
      .a(() -> !this.movementMode.b("Только частицы") && !this.movementMode.b("След + частицы") ? false : true);
   private final NumberSetting particleCount = new NumberSetting("Количество частиц", 4.0F, 1.0F, 20.0F, 1.0F)
      .a(() -> !this.movementMode.b("Только частицы") && !this.movementMode.b("След + частицы") ? false : true);
   private final NumberSetting particleSize = new NumberSetting("Размер частиц", 0.3F, 0.1F, 0.75F, 0.05F)
      .a(() -> !this.movementMode.b("Только частицы") && !this.movementMode.b("След + частицы") ? false : true);
   private final NumberSetting particleLifetimeTicks = new NumberSetting("Время жизни", 20.0F, 10.0F, 50.0F, 5.0F)
      .a(() -> !this.movementMode.b("Только частицы") && !this.movementMode.b("След + частицы") ? false : true);
   private final NumberSetting particleSpread = new NumberSetting("Сила разлёта", 0.3F, 0.15F, 0.35F, 0.01F)
      .a(() -> !this.movementMode.b("Только частицы") && !this.movementMode.b("След + частицы") ? false : true);
   private final BooleanSetting useClientParticleColor = new BooleanSetting("Цвет клиента", BooleanCoercion.from(-950111800))
      .a(() -> !this.movementMode.b("Только частицы") && !this.movementMode.b("След + частицы") ? false : true);
   private final ColorSetting customParticleColor = new ColorSetting("Кастомный цвет", Color.WHITE)
      .a(() -> (this.movementMode.b("Только частицы") || this.movementMode.b("След + частицы")) && !this.useClientParticleColor.a() ? true : false);
   private final Deque<TrailPoint> trailPoints = new ArrayDeque<>();
   private boolean positionInitialized = false;

   private Color b(int n) {
      Color color = this.trailColor();
      Color color2 = this.trailColor();
      float f = Math.min(1.0F, n / 20.0F);
      return new Color(
         (int)(color.getRed() * (1.0F - f) + color2.getRed() * f),
         (int)(color.getGreen() * (1.0F - f) + color2.getGreen() * f),
         (int)(color.getBlue() * (1.0F - f) + color2.getBlue() * f)
      );
   }

   private void b(Matrix4f matrix4f, float f, List<TrailPoint> list, Vec3d vec3d) {
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.LINES, VertexFormats.POSITION_COLOR);

      for (int n = 0; n - -2 - 1 < list.size(); n += 2) {
         this.a(bufferBuilder, matrix4f, list.get(n), list.get(n - -2 - 1), vec3d, f, n, list.size());
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
   }

   private void c(Matrix4f matrix4f, float f, List<TrailPoint> list, Vec3d vec3d) {
      this.a(matrix4f, f, list, vec3d, true);
      this.a(matrix4f, list, vec3d, true);
      this.a(matrix4f, this.a(list, f), vec3d, true);
   }

   private Color trailColor() {
      return !this.useClientTrailColor.a() ? this.customTrailColor.a() : ModuleManager.CLIENT_COLOR.n();
   }

   @Override
   public void f() {
      super.f();
      this.trailPoints.clear();
      this.positionInitialized = false;
   }

   private void a(Vec3d vec3d, double d, int n) {
      int particleColor = ColorUtils.ensureOpaque(n);
      int particleCount = this.particleCount.b();
      int lifetime = this.particleLifetimeTicks.b();
      int minimumLifetime = Math.max(1, lifetime - 10);
      int maximumLifetime = lifetime + 10;
      float configuredSize = this.particleSize.a();
      float minimumSize = configuredSize - 0.05F;
      float maximumSize = configuredSize + 0.05F;
      double spreadStrength = this.particleSpread.a();
      String physicsMode = this.particlePhysics.d();

      for (int particleIndex = 0; particleIndex < particleCount; particleIndex++) {
         int randomizedLifetime = ThreadLocalRandom.current().nextInt(minimumLifetime, maximumLifetime);
         float randomizedSize = minimumSize + ThreadLocalRandom.current().nextFloat() * (maximumSize - minimumSize);
         Vec3d velocity = new Vec3d(
            ThreadLocalRandom.current().nextDouble(-d, d), ThreadLocalRandom.current().nextDouble(0.0, d), ThreadLocalRandom.current().nextDouble(-d, d)
         );
         if (velocity.lengthSquared() > 0.0) {
            velocity = velocity.normalize().multiply(ThreadLocalRandom.current().nextDouble(0.005, spreadStrength));
         }

         HudServices.PARTICLES.spawn(vec3d, velocity, randomizedLifetime, randomizedSize, this.particleTexture(), particleColor, physicsMode);
      }
   }

   private void a(Matrix4f matrix4f, float f, List<TrailPoint> list, Vec3d vec3d) {
      this.a(matrix4f, f, list, vec3d, false);
      this.a(matrix4f, list, vec3d, false);
      this.a(matrix4f, this.a(list, f), vec3d, false);
   }

   private void a(Matrix4f matrix4f, List<TrailPoint> list, Vec3d vec3d, boolean bl) {
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.LINE_STRIP, VertexFormats.POSITION_COLOR);

      for (int i = 0; i < list.size(); i++) {
         this.a(bufferBuilder, matrix4f, list.get(i).position(), vec3d, this.b(i), this.a(i, list.size(), bl));
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
   }

   private void a(BufferBuilder bufferBuilder, Matrix4f matrix4f, float f, Vec3d vec3d, Vec3d vec3d2, Color color, float f2) {
      this.a(bufferBuilder, matrix4f, vec3d, vec3d2, color, f2);
      this.a(bufferBuilder, matrix4f, vec3d.add(0.0, f, 0.0), vec3d2, color, f2);
   }

   @EventHandler
   public void a(WorldRenderPostEvent kvprd92) {
      String string = this.movementMode.d();
      if ((string.equals("Только след") || string.equals("След + частицы")) && c.world != null && c.player != null && this.trailPoints.size() >= 2) {
         if (!c.options.getPerspective().isFirstPerson() || this.showInFirstPerson.k()) {
            MatrixStack matrixStack = kvprd92.a();
            matrixStack.push();
            Vec3d vec3d = c.gameRenderer.getCamera().getPos();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableCull();
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.lineWidth(this.trailWidth.a() * 3.0F);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
            ArrayList<TrailPoint> arrayList = new ArrayList<>(this.trailPoints);
            String string2 = this.trailStyle.d();
            if ("Пунктир".equals(string2)) {
               this.b(matrix4f, c.player.getHeight(), arrayList, vec3d);
            } else if ("Затухающий".equals(string2)) {
               this.c(matrix4f, c.player.getHeight(), arrayList, vec3d);
            } else {
               this.a(matrix4f, c.player.getHeight(), arrayList, vec3d);
            }

            RenderSystem.disableBlend();
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.depthMask(true);
            RenderSystem.lineWidth(1.0F);
            matrixStack.pop();
         }
      }
   }

   @EventHandler
   public void a(ClientTickEvent q8krcw2) {
      String string = this.movementMode.d();
      if ((string.equals("Только частицы") || string.equals("След + частицы"))
         && c.player != null
         && (!c.options.getPerspective().isFirstPerson() || this.showInFirstPerson.k())) {
         double d = c.player.getX();
         double d2 = c.player.getY();
         double d3 = c.player.getZ();
         if (!this.positionInitialized) {
            this.previousX = d;
            this.previousY = d2;
            this.previousZ = d3;
            this.positionInitialized = true;
            return;
         }

         double d4 = d - this.previousX;
         double d5 = d2 - this.previousY;
         double d6 = d3 - this.previousZ;
         double d7 = Math.sqrt(d4 * d4 + d5 * d5 + d6 * d6);
         this.previousX = d;
         this.previousY = d2;
         this.previousZ = d3;
         if (d7 > 0.01) {
            String string2 = this.particleSpawnMode.d();
            if (string2.equals("Под ногами")) {
               this.a(c.player.getPos(), 0.1, this.particleColor().getRGB());
               return;
            }

            if (string2.equals("По телу")) {
               double d8 = c.player.getHeight();

               for (int i = 0; i < 5; i++) {
                  this.a(c.player.getPos().add(0.0, d8 / 4.0 * i, 0.0), 0.08, this.particleColor().getRGB());
               }
            }
         }
      }
   }

   @EventHandler
   public void a(RenderTickEvent zv7i6c2) {
      String string = this.movementMode.d();
      if (string.equals("Только след") || string.equals("След + частицы")) {
         ClientPlayerEntity clientPlayerEntity = c.player;
         if (c.player != null && c.world != null) {
            float f = zv7i6c2.a();
            this.trailPoints.removeIf(point -> point.isOlderThan(500L));
            Vec3d vec3d = new Vec3d(
               MathHelper.lerp(f, clientPlayerEntity.prevX, clientPlayerEntity.getX()),
               MathHelper.lerp(f, clientPlayerEntity.prevY, clientPlayerEntity.getY()),
               MathHelper.lerp(f, clientPlayerEntity.prevZ, clientPlayerEntity.getZ())
            );
            if (this.trailPoints.isEmpty() || this.trailPoints.getLast().position().squaredDistanceTo(vec3d) > 1.0E-4) {
               this.trailPoints.addLast(new TrailPoint(vec3d));

               while (this.trailPoints.size() > this.trailLength.a() * 10.0F) {
                  this.trailPoints.pollFirst();
               }
            }

            return;
         }
      }
   }

   private void a(BufferBuilder bufferBuilder, Matrix4f matrix4f, Vec3d vec3d, Vec3d vec3d2, Color color, float f) {
      bufferBuilder.vertex(
            matrix4f,
            (float)(vec3d.x - vec3d2.x),
            (float)(vec3d.y - vec3d2.y),
            (float)(vec3d.z - vec3d2.z)
         )
         .color(color.getRed(), color.getGreen(), color.getBlue(), (int)(f * 255.0F));
   }

   private float a(int n, int n2, boolean bl) {
      float f = n2 <= 0 ? 0.0F : (float)n / n2;
      return !bl ? f : f * f;
   }

   private List<TrailPoint> a(List<TrailPoint> list, float f) {
      ArrayList<TrailPoint> arrayList = new ArrayList<>(list.size());
      list.forEach(point -> arrayList.add(new TrailPoint(point.position().add(0.0, f, 0.0), point.createdAtMs())));
      return arrayList;
   }

   private void a(BufferBuilder bufferBuilder, Matrix4f matrix4f, TrailPoint firstPoint, TrailPoint secondPoint, Vec3d vec3d, float f, int n, int n2) {
      float f2 = this.a(n, n2, false);
      Color color = this.b(n);
      this.a(bufferBuilder, matrix4f, firstPoint.position(), vec3d, color, f2);
      this.a(bufferBuilder, matrix4f, secondPoint.position(), vec3d, color, f2);
      this.a(bufferBuilder, matrix4f, firstPoint.position().add(0.0, f, 0.0), vec3d, color, f2);
      this.a(bufferBuilder, matrix4f, secondPoint.position().add(0.0, f, 0.0), vec3d, color, f2);
   }

   private void a(Matrix4f matrix4f, float f, List<TrailPoint> list, Vec3d vec3d, boolean bl) {
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);

      for (int i = 0; i < list.size(); i++) {
         this.a(bufferBuilder, matrix4f, f, list.get(i).position(), vec3d, this.b(i), this.a(i, list.size(), bl));
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
   }

   private Color particleColor() {
      return !this.useClientParticleColor.a() ? this.customParticleColor.a() : ModuleManager.CLIENT_COLOR.n();
   }

   private Identifier particleTexture() {
      String textureName = switch (this.particleType.d()) {
         case "Искра" -> "sparkle";
         case "Снежинка" -> "snowflake";
         case "Сияние" -> "glow";
         case "Линия" -> "line";
         case "Доллар" -> "dollar";
         default -> "heart";
      };
      return Identifier.of("haron", "textures/particle/" + textureName + ".png");
   }
}
