package haron.modules.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.module.ModuleManager;
import haron.render.ShapeRenderer;
import haron.render.font.ClientFonts;
import haron.theme.pryrvd;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.screen.slot.Slot;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.component.DataComponentTypes;
import ru.haron.Kryven;

public final class ShulkerPreviewRenderer {
   private static final float SLOT = 18.0F;
   private static final float PADDING = 6.0F;
   private static final int COLS = 9;
   private static final int ROWS = 3;
   private static final Color SLOT_BACKGROUND = new Color(45, 25, 15, 180);

   public static void renderInventoryHover(Slot slot, DrawContext drawContext, int n, int n2) {
      renderInventoryHover(slot, drawContext, n, n2, false);
   }

   public static void renderInventoryHover(Slot slot, DrawContext drawContext, int n, int n2, boolean bl) {
      ShulkerPreview igawp72 = ModuleManager.SHULKER_PREVIEW;
      if (igawp72.k() && igawp72.inventoryPreview.a() && slot != null) {
         ItemStack itemStack = slot.getStack();
         if (isShulkerBox(itemStack)) {
            List<ItemStack> list = readContents(itemStack);
            float f = 174.0F;
            float f2 = 82.0F;
            float f3 = n;
            float f4 = n2;
            if (!bl) {
               f3 = n + 14;
               f4 = n2 + 6;
               MinecraftClient minecraftClient = MinecraftClient.getInstance();
               if (f3 + 174.0F > minecraftClient.getWindow().getScaledWidth()) {
                  f3 = n - 174.0F - 4.0F;
               }

               if (f4 + 82.0F > minecraftClient.getWindow().getScaledHeight()) {
                  f4 = n2 - 82.0F - 4.0F;
               }
            }

            renderPanel(drawContext, f3, f4, 174.0F, 82.0F, list, itemStack, 1.0F);
         }
      }
   }

   private static Color getAccent() {
      return pryrvd.ACCENT;
   }

   private static void drawItem(MatrixStack matrixStack, DrawContext drawContext, ItemStack itemStack, float f, float f2, float f3) {
      if (!itemStack.isEmpty()) {
         MatrixStack matrixStack2 = drawContext.getMatrices();
         float f4 = f3 / 16.0F;
         matrixStack2.push();
         matrixStack2.translate(f, f2, 0.0F);
         matrixStack2.scale(f4, f4, 1.0F);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         drawContext.drawItem(itemStack, 0, 0);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.disableBlend();
         if (itemStack.getCount() > 1) {
            TextRenderer textRenderer = MinecraftClient.getInstance().textRenderer;
            String string = String.valueOf(itemStack.getCount());
            matrixStack2.push();
            matrixStack2.translate(0.0F, 0.0F, 200.0F);
            matrixStack2.scale(0.5F, 0.5F, 1.0F);
            drawContext.drawTextWithShadow(
               textRenderer, Text.literal(string), (int)((16.0F - textRenderer.getWidth(string) * 0.5F) / 0.5F), 22, 16777215
            );
            matrixStack2.pop();
         }

         matrixStack2.pop();
      }
   }

   public static boolean isShulkerBox(ItemStack itemStack) {
      Item item;
      return !itemStack.isEmpty() && (item = itemStack.getItem()) instanceof BlockItem && ((BlockItem)item).getBlock() instanceof ShulkerBoxBlock;
   }

   public static void renderWorldTarget(MinecraftClient minecraftClient, MatrixStack matrixStack, ShapeRenderer s7swsm2) {
      ShulkerPreview igawp72 = ModuleManager.SHULKER_PREVIEW;
      if (igawp72.k() && igawp72.worldPreview.a() && minecraftClient.player != null) {
         ItemEntity itemEntity;
         ItemStack itemStack;
         EntityHitResult entityHitResult;
         Entity entity;
         if (minecraftClient.crosshairTarget instanceof EntityHitResult
            && (entity = (entityHitResult = (EntityHitResult)minecraftClient.crosshairTarget).getEntity()) instanceof ItemEntity
            && isShulkerBox(itemStack = (itemEntity = (ItemEntity)entity).getStack())
            && minecraftClient.player.squaredDistanceTo(itemEntity) <= 36.0) {
            float f = 174.0F;
            renderPanel(
               new DrawContext(minecraftClient, minecraftClient.getBufferBuilders().getEntityVertexConsumers()),
               minecraftClient.getWindow().getScaledWidth() / 2.0F - 87.0F,
               minecraftClient.getWindow().getScaledHeight() / 2.0F + 20.0F,
               174.0F,
               82.0F,
               readContents(itemStack),
               itemStack,
               1.0F
            );
         }
      }
   }

   private static void renderPanel(DrawContext drawContext, float f, float f2, float f3, float f4, List<ItemStack> list, ItemStack itemStack, float f5) {
      MatrixStack matrixStack = drawContext.getMatrices();
      ShapeRenderer s7swsm2 = Kryven.getInstance().getRender();
      if (s7swsm2 != null) {
         s7swsm2.a(f, f2, f3, f4, 7.0F * f5, getAccent(), matrixStack);
         ClientFonts.a[Math.max(6, Math.min(14, Math.round(10.0F * f5)))]
            .a(
               itemStack.get(DataComponentTypes.CUSTOM_NAME) != null ? itemStack.getName().getString() : "Shulker Box",
               f + 6.0F * f5,
               f2 + 4.0F * f5,
               Color.WHITE,
               matrixStack
            );
         float f6 = f + 6.0F * f5;
         float f7 = f2 + 16.0F * f5;
         float f8 = 18.0F * f5;

         for (int i = 0; i < 27; i++) {
            float f9 = f6 + i % 9 * f8;
            float f10 = f7 + i / 9 * f8;
            s7swsm2.a(f9, f10, f8 - 1.0F, f8 - 1.0F, 3.0F * f5, SLOT_BACKGROUND, matrixStack);
            if (i < list.size() && !list.get(i).isEmpty()) {
               drawItem(matrixStack, drawContext, list.get(i), f9 + 1.0F * f5, f10 + 1.0F * f5, f8 - 2.0F * f5);
            }
         }
      }
   }

   private static List<ItemStack> readContents(ItemStack itemStack) {
      ArrayList<ItemStack> arrayList = new ArrayList<>();
      ContainerComponent containerComponent = (ContainerComponent)itemStack.get(DataComponentTypes.CONTAINER);
      if (containerComponent == null) {
         return arrayList;
      }

      for (int n = 0; n < 27; n++) {
         arrayList.add(ItemStack.EMPTY);
      }

      int var7 = 0;

      for (ItemStack itemStack2 : containerComponent.iterateNonEmpty()) {
         if (var7 < 27) {
            int n2 = var7++;
            arrayList.set(n2, itemStack2.copy());
         }
      }

      return arrayList;
   }

   private ShulkerPreviewRenderer() {
   }
}
