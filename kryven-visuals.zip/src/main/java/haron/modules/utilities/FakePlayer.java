package haron.modules.utilities;

import com.mojang.authlib.GameProfile;
import haron.events.ClientTickEvent;
import haron.events.MouseButtonEvent;
import haron.events.WorldChangedEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.NumberSetting;
import haron.settings.StringSetting;
import java.util.UUID;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.network.OtherClientPlayerEntity;

@ModuleInfo(a = "FakePlayer", b = "Спавнит копию игрока на клиенте для тренировки.", c = ModuleCategory.UTILITIES)
public final class FakePlayer extends HaronModule {
   public final StringSetting name = new StringSetting("Name", "FakePlayer");
   public final BooleanSetting lookAtPlayer = new BooleanSetting("Смотреть на игрока", true);
   public final BooleanSetting totem = new BooleanSetting("Тотем", true);
   public final BooleanSetting copyEquip = new BooleanSetting("Копировать снаряжение", true);
   public final NumberSetting health = new NumberSetting("Здоровье", 20.0F, 1.0F, 40.0F, 1.0F);
   private OtherClientPlayerEntity fakePlayer;
   private float currentHp;
   private static final byte STATUS_HURT = 2;
   private static final byte STATUS_TOTEM = 35;
   private static final int FAKE_ID = -42069;

   @EventHandler
   public void onTick(ClientTickEvent q8krcw2) {
      if (c.player != null && c.world != null) {
         if (this.fakePlayer == null) {
            this.spawn();
         } else {
            if (this.fakePlayer.hurtTime > 0) {
               this.fakePlayer.hurtTime--;
            }

            this.fakePlayer.setHealth(this.currentHp);
            if (this.lookAtPlayer.get()) {
               double d = c.player.getX() - this.fakePlayer.getX();
               double d2 = c.player.getZ() - this.fakePlayer.getZ();
               double d3 = c.player.getEyeY() - this.fakePlayer.getEyeY();
               double d4 = Math.sqrt(d * d + d2 * d2);
               float f = (float)Math.toDegrees(Math.atan2(d2, d)) - 90.0F;
               float f2 = (float)(-Math.toDegrees(Math.atan2(d3, d4)));
               this.fakePlayer.setYaw(f);
               this.fakePlayer.setPitch(f2);
               this.fakePlayer.headYaw = f;
               this.fakePlayer.bodyYaw = f;
            }
         }
      }
   }

   @Override
   public void onDisable() {
      this.remove();
   }

   private void onFatalHit() {
      if (this.fakePlayer != null && c.world != null) {
         if (this.totem.get()
            && (
               this.fakePlayer.getEquippedStack(EquipmentSlot.OFFHAND).getItem() == Items.TOTEM_OF_UNDYING
                  || this.fakePlayer.getEquippedStack(EquipmentSlot.MAINHAND).getItem() == Items.TOTEM_OF_UNDYING
            )) {
            this.currentHp = 1.0F;
            this.fakePlayer.setHealth(this.currentHp);
            this.fakePlayer.handleStatus((byte)35);
            if (this.fakePlayer.getEquippedStack(EquipmentSlot.OFFHAND).getItem() == Items.TOTEM_OF_UNDYING) {
               this.fakePlayer.equipStack(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
            } else {
               this.fakePlayer.equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }

            c.world
               .playSound(
                  this.fakePlayer.getX(),
                  this.fakePlayer.getY(),
                  this.fakePlayer.getZ(),
                  SoundEvents.ITEM_TOTEM_USE,
                  SoundCategory.PLAYERS,
                  1.0F,
                  1.0F,
                  false
               );
         } else {
            c.world
               .playSound(
                  this.fakePlayer.getX(),
                  this.fakePlayer.getY(),
                  this.fakePlayer.getZ(),
                  SoundEvents.ENTITY_PLAYER_DEATH,
                  SoundCategory.PLAYERS,
                  1.0F,
                  1.0F,
                  false
               );
            this.remove();
            this.currentHp = this.health.get();
            this.spawn();
         }
      }
   }

   private void applyHit() {
      if (c.player != null && c.world != null && this.fakePlayer != null) {
         float f = c.player.getAttackCooldownProgress(0.5F);
         if (!(f < 0.2F)) {
            float f2 = (float)c.player.getAttributeValue(EntityAttributes.ATTACK_DAMAGE) * (0.2F + f * f * 0.8F);
            if (!c.player.isOnGround()
               && !(c.player.fallDistance <= 0.0F)
               && !c.player.isSprinting()
               && !c.player.isClimbing()
               && !c.player.isTouchingWater()
               && c.player.getVehicle() == null
               && !c.player.hasStatusEffect(StatusEffects.BLINDNESS)
               && !(f <= 0.9F)) {
               f2 *= 1.5F;
               c.player.addCritParticles((Entity)(Object)this.fakePlayer);
               c.world
                  .playSound(
                     this.fakePlayer.getX(),
                     this.fakePlayer.getY(),
                     this.fakePlayer.getZ(),
                     SoundEvents.ENTITY_PLAYER_ATTACK_CRIT,
                     SoundCategory.PLAYERS,
                     1.0F,
                     1.0F,
                     false
                  );
            } else if (f > 0.9F) {
               c.world
                  .playSound(
                     this.fakePlayer.getX(),
                     this.fakePlayer.getY(),
                     this.fakePlayer.getZ(),
                     SoundEvents.ENTITY_PLAYER_ATTACK_STRONG,
                     SoundCategory.PLAYERS,
                     1.0F,
                     1.0F,
                     false
                  );
            } else {
               c.world
                  .playSound(
                     this.fakePlayer.getX(),
                     this.fakePlayer.getY(),
                     this.fakePlayer.getZ(),
                     SoundEvents.ENTITY_PLAYER_ATTACK_WEAK,
                     SoundCategory.PLAYERS,
                     1.0F,
                     1.0F,
                     false
                  );
            }

            float f3 = (float)this.fakePlayer.getAttributeValue(EntityAttributes.ARMOR);
            float f4 = Math.max(
               0.0F,
               f2
                  * (
                     1.0F
                        - Math.min(
                              20.0F, Math.max(f3 * 0.2F, Math.min(f3, f3 - f2 / (2.0F + (float)this.fakePlayer.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS) / 4.0F)))
                           )
                           / 25.0F
                  )
            );
            this.fakePlayer.hurtTime = 10;
            this.fakePlayer.maxHurtTime = 10;
            this.fakePlayer.handleStatus((byte)2);
            c.world
               .playSound(
                  this.fakePlayer.getX(),
                  this.fakePlayer.getY(),
                  this.fakePlayer.getZ(),
                  SoundEvents.ENTITY_PLAYER_HURT,
                  SoundCategory.PLAYERS,
                  1.0F,
                  1.0F,
                  false
               );
            c.player.resetLastAttackedTicks();
            this.currentHp = Math.max(0.0F, this.currentHp - f4);
            this.fakePlayer.setHealth(this.currentHp);
            if (this.currentHp <= 0.0F) {
               this.onFatalHit();
            }
         }
      }
   }

   private void spawn() {
      if (c.player != null && c.world != null) {
         this.remove();
         this.currentHp = this.health.get();
         ClientWorld clientWorld = c.world;
         String string = this.name.get();
         if (string == null || string.isBlank()) {
            string = "FakePlayer";
         }

         OtherClientPlayerEntity otherClientPlayerEntity = new OtherClientPlayerEntity(clientWorld, new GameProfile(UUID.randomUUID(), string));
         otherClientPlayerEntity.copyFrom(c.player);
         otherClientPlayerEntity.setId(-42069);
         double d = Math.toRadians(c.player.getYaw());
         otherClientPlayerEntity.refreshPositionAndAngles(
            c.player.getX() - Math.sin(d) * 2.0,
            c.player.getY(),
            c.player.getZ() + Math.cos(d) * 2.0,
            c.player.getYaw() + 180.0F,
            0.0F
         );
         otherClientPlayerEntity.headYaw = otherClientPlayerEntity.getYaw();
         otherClientPlayerEntity.bodyYaw = otherClientPlayerEntity.getYaw();
         otherClientPlayerEntity.setHealth(this.currentHp);
         if (this.copyEquip.get()) {
            for (EquipmentSlot equipmentSlot : EquipmentSlot.values()) {
               otherClientPlayerEntity.equipStack(equipmentSlot, c.player.getEquippedStack(equipmentSlot).copy());
            }
         }

         if (this.totem.get()) {
            otherClientPlayerEntity.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
         }

         clientWorld.addEntity(otherClientPlayerEntity);
         this.fakePlayer = otherClientPlayerEntity;
      }
   }

   @EventHandler
   public void onWorldChange(WorldChangedEvent m7z9q12) {
      this.remove();
      if (this.k()) {
         this.currentHp = this.health.get();
         this.spawn();
      }
   }

   @EventHandler
   public void onMouseButton(MouseButtonEvent tp78k22) {
      if (c.player != null && c.world != null && this.fakePlayer != null && tp78k22.button() == 0 && tp78k22.action() == 1 && c.currentScreen == null) {
         EntityHitResult entityHitResult;
         if (c.crosshairTarget instanceof EntityHitResult && (entityHitResult = (EntityHitResult)c.crosshairTarget).getEntity() == this.fakePlayer) {
            tp78k22.cancel();
            this.applyHit();
         }
      }
   }

   public FakePlayer() {
      this.collectSettings();
   }

   private void remove() {
      if (this.fakePlayer != null) {
         if (c.world != null) {
            c.world.removeEntity(this.fakePlayer.getId(), Entity.RemovalReason.DISCARDED);
         }

         this.fakePlayer = null;
      }
   }

   @Override
   public void onEnable() {
      this.spawn();
   }
}
