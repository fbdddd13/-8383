package haron.modules.utilities;

import haron.events.ClientTickEvent;
import haron.events.PlayerDeathEvent;
import haron.media.chat.w53bpe;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.TextTokenType;
import haron.settings.ValidatedTextSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.screen.Screen;

@ModuleInfo(a = "Auto Respawn", b = "Автоматически возрождает игрока после смерти", c = ModuleCategory.UTILITIES)
public class AutoRespawn extends HaronModule {
   private final BooleanSetting e = new BooleanSetting("Авто возрождение", "Автоматически возрождаться после смерти", true);
   private final BooleanSetting f = new BooleanSetting("Отправлять команду после возрождения", "Отправлять команду после возрождения", false);
   private final ValidatedTextSetting g;
   private boolean h;
   private boolean i;
   private int j;
   public static int a;
   public static boolean b;

   public AutoRespawn() {
      ValidatedTextSetting trepl22 = new ValidatedTextSetting("Команда", TextTokenType.COMMAND, "/home");
      BooleanSetting xcv91t2 = this.f;
      this.g = trepl22.a(xcv91t2::k);
      this.h = false;
   }

   @Override
   public void f() {
      super.f();
      this.h = false;
   }

   @EventHandler
   public void a(ClientTickEvent q8krcw2) {
      if (c.player != null && c.world != null) {
         if (c.currentScreen instanceof DeathScreen) {
            int n = this.j;
            this.j = 2 * (n | 1) - (n ^ 1);
         }

         if (this.i && !(c.currentScreen instanceof DeathScreen) && c.player.age > 30) {
            w53bpe.a(this.g.a());
            this.i = false;
            this.j = 0;
         }

         Screen screen = c.currentScreen;
         if (c.currentScreen instanceof DeathScreen) {
            DeathScreen deathScreen = (DeathScreen)screen;
            if (!this.h) {
               this.h = true;
            }

            if (this.e.k() && this.a(deathScreen)) {
               c.player.requestRespawn();
               c.currentScreen = null;
               this.j = 0;
            }
         } else if (this.h) {
            if (c.player.isAlive()) {
               this.h = false;
               if (!this.f.k() || this.g.a().isEmpty()) {
                  return;
               }

               w53bpe.a(this.g.a());
            }
         }
      }
   }

   @EventHandler
   public void a(PlayerDeathEvent c5scvm2) {
      if (c5scvm2.a() == c.player) {
         this.i = true;
      }
   }

   private boolean a(DeathScreen deathScreen) {
      try {
         for (Object e : deathScreen.children()) {
            if (e instanceof ButtonWidget && ((ButtonWidget)e).active) {
               return true;
            }
         }

         return false;
      } catch (Exception exception) {
         return false;
      }
   }
}
