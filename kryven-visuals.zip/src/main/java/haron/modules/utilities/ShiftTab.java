package haron.modules.utilities;

import haron.events.AttackTargetEvent;
import haron.events.ClientTickEvent;
import haron.events.CriticalHitEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.util.InputUtil;

@ModuleInfo(a = "Shift Tab", b = "Briefly sneaks while attacking.", c = ModuleCategory.UTILITIES)
public class ShiftTab extends HaronModule {
   private static final int SNEAK_TICKS = 2;
   private final BooleanSetting triggerBeforeAttack = new BooleanSetting("До атаки", "If disabled, sneaking starts after the attack event.", true);
   private int sneakTicksLeft;
   private boolean restorePending;
   private boolean previousSneakPressed;

   private void startSneakBurst() {
      if (c.player != null) {
         this.previousSneakPressed = this.isSneakKeyPhysicallyPressed();
         this.sneakTicksLeft = 2;
         this.restorePending = true;
         c.options.sneakKey.setPressed(true);
      }
   }

   private boolean isSneakKeyPhysicallyPressed() {
      return c.getWindow() != null && InputUtil.isKeyPressed(c.getWindow().getHandle(), c.options.sneakKey.getDefaultKey().getCode());
   }

   @Override
   public void f() {
      super.f();
      this.sneakTicksLeft = 0;
      this.restorePending = false;
      if (c.options != null) {
         c.options.sneakKey.setPressed(this.isSneakKeyPhysicallyPressed());
      }
   }

   @EventHandler
   public void a(ClientTickEvent q8krcw2) {
      if (c.player != null) {
         if (this.sneakTicksLeft > 0) {
            c.options.sneakKey.setPressed(true);
            this.sneakTicksLeft--;
         } else if (this.restorePending) {
            c.options.sneakKey.setPressed(this.previousSneakPressed);
            this.restorePending = false;
         }
      }
   }

   @EventHandler
   public void a(CriticalHitEvent bjxb112) {
      if (this.triggerBeforeAttack.k()) {
         this.startSneakBurst();
      }
   }

   @EventHandler
   public void a(AttackTargetEvent dt813s2) {
      if (!this.triggerBeforeAttack.k()) {
         this.startSneakBurst();
      }
   }
}
