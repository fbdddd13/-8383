package haron.modules.utilities;

import haron.core.BooleanCoercion;
import haron.events.ClientTickEvent;
import haron.events.KeyInputEvent;
import haron.inventory.rk1ts2;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.KeybindSetting;
import java.util.Optional;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.component.DataComponentTypes;

@ModuleInfo(a = "Elytra Swap", b = "Автоматически меняет нагрудник на элитры при падении", c = ModuleCategory.UTILITIES)
public class ElytraSwap extends HaronModule {
   private final KeybindSetting e = new KeybindSetting("Кнопка свапа", -1);
   private boolean f = false;
   private int g = 0;
   private boolean h = false;
   private int i = 0;
   public static int a;
   public static boolean b;

   @Override
   public void e() {
      super.e();
      this.f = false;
      this.g = 0;
      this.h = false;
      this.i = 0;
   }

   private void b(int n) {
      c.interactionManager.clickSlot(c.player.currentScreenHandler.syncId, n, 40, SlotActionType.SWAP, c.player);
      c.interactionManager.clickSlot(c.player.currentScreenHandler.syncId, 6, 40, SlotActionType.SWAP, c.player);
      c.interactionManager.clickSlot(c.player.currentScreenHandler.syncId, n, 40, SlotActionType.SWAP, c.player);
   }

   private void n() {
      if (this.q()) {
         Optional<Integer> optional = this.p();
         if (optional.isPresent()) {
            this.b(optional.get());
            c.player.sendMessage(Text.of($sf$2(this.g())), true);
         }
      } else {
         Optional<Integer> optional = this.o();
         if (optional.isPresent()) {
            this.b(optional.get());
            c.player.sendMessage(Text.of($sf$3(this.g())), true);
         }
      }
   }

   @Override
   public void f() {
      super.f();
   }

   @EventHandler
   public void a(KeyInputEvent dsgqgn2) {
      if (c.player != null && c.world != null && c.currentScreen == null && dsgqgn2.a() == this.e.k() && dsgqgn2.c() == 1 && !this.f) {
         this.f = true;
         this.g = 0;
         this.h = false;
         this.i = 0;
      }
   }

   @EventHandler
   public void a(ClientTickEvent q8krcw2) {
      if (c.player != null && this.f) {
         if (this.i > 0) {
            int n = this.i;
            this.i = (n ^ 1) - 2 * (~n & 1);
         }

         switch (this.g) {
            case 0:
               if (!c.player.getAbilities().creativeMode) {
                  if (!this.q()) {
                     if (!this.o().isPresent()) {
                        c.player.sendMessage(Text.of($sf$0(this.g())), true);
                        this.f = false;
                     }
                  } else if (!this.p().isPresent()) {
                     c.player.sendMessage(Text.of($sf$1(this.g())), true);
                     this.f = false;
                  }

                  if (!(c.currentScreen instanceof InventoryScreen)) {
                     c.setScreen(new InventoryScreen(c.player));
                  }

                  this.i = 2;
                  this.g = 1;
               } else {
                  this.g = 1;
               }
               break;
            case 1:
               if (c.currentScreen instanceof InventoryScreen && !this.h) {
                  this.n();
                  this.h = true;
                  this.i = 2;
                  this.g = 2;
               }
               break;
            case 2:
               if (c.currentScreen instanceof InventoryScreen) {
                  c.player.closeHandledScreen();
               }

               this.f = false;
               this.g = 0;
         }
      }
   }

   private boolean a(ItemStack itemStack) {
      if (itemStack.getItem() == Items.ELYTRA) {
         return false;
      }

      EquippableComponent equippableComponent = (EquippableComponent)itemStack.get(DataComponentTypes.EQUIPPABLE);
      return BooleanCoercion.from(equippableComponent != null && equippableComponent.slot() == EquipmentSlot.CHEST ? 1 : 0);
   }

   private Optional<Integer> o() {
      return rk1ts2.a(itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.ELYTRA ? 0 : 1), true, false);
   }

   private Optional<Integer> p() {
      return rk1ts2.a(this::a, true, false);
   }

   private boolean q() {
      return BooleanCoercion.from(c.player.getEquippedStack(EquipmentSlot.CHEST).getItem() != Items.ELYTRA ? 0 : 1);
   }

   private static String $sf$0(String string) {
      return string + ": Свап отменен: нет элитр.";
   }

   private static String $sf$3(String string) {
      return string + ": Надел элитры.";
   }

   private static String $sf$1(String string) {
      return string + ": Свап отменен: нет нагрудника.";
   }

   private static String $sf$2(String string) {
      return string + ": Снял элитры.";
   }
}
