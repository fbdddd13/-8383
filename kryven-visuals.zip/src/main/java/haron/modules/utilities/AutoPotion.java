package haron.modules.utilities;

import haron.events.ClientTickEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import java.util.Iterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.component.DataComponentTypes;

@ModuleInfo(a = "Auto Potion", b = "Автоматически использует выбранные зелья", c = ModuleCategory.UTILITIES)
public class AutoPotion extends HaronModule {
   private boolean g;
   public static int a;
   public static boolean b;
   private final BooleanSetting e = new BooleanSetting("Невидимость", true);
   private final BooleanSetting f = new BooleanSetting("Скорость", false);
   private int h = -1;
   private boolean i = false;

   @Override
   public void f() {
      super.f();
      if (this.g) {
         c.options.useKey.setPressed(this.i);
      }

      if (this.h != -1) {
         c.player.getInventory().selectedSlot = this.h;
      }

      this.g = false;
      this.h = -1;
   }

   @EventHandler
   public void a(ClientTickEvent q8krcw2) {
      if (c.world != null && c.player != null) {
         if (!this.g) {
            this.i = c.options.useKey.isPressed();
         }

         int n2 = -1;
         int n3 = -1;
         if (this.e.k()
            && (
               !c.player.hasStatusEffect(StatusEffects.INVISIBILITY)
                  || c.player.getStatusEffect(StatusEffects.INVISIBILITY) != null && c.player.getStatusEffect(StatusEffects.INVISIBILITY).getDuration() <= 100
            )) {
            for (int n = 0; n < 9; n++) {
               ItemStack itemStack = c.player.getInventory().getStack(n);
               if (!itemStack.isEmpty() && itemStack.getItem() == Items.POTION && this.a(itemStack, StatusEffects.INVISIBILITY)) {
                  n2 = n;
                  break;
               }
            }
         }

         if (this.f.k()
            && (
               !c.player.hasStatusEffect(StatusEffects.SPEED)
                  || c.player.getStatusEffect(StatusEffects.SPEED) != null && c.player.getStatusEffect(StatusEffects.SPEED).getDuration() <= 100
            )) {
            for (int n = 0; n < 9; n++) {
               ItemStack itemStack = c.player.getInventory().getStack(n);
               if (!itemStack.isEmpty() && itemStack.getItem() == Items.POTION) {
                  if (this.a(itemStack, StatusEffects.SPEED)) {
                     n3 = n;
                     break;
                  }

                  if (!b) {
                  }
               }
            }
         }

         int n = -1;
         if (n2 != -1) {
            n = n2;
         } else if (n3 != -1) {
            n = n3;
         }

         if (n != -1) {
            if (!this.g) {
               this.h = c.player.getInventory().selectedSlot;
            }

            c.player.getInventory().selectedSlot = n;
            c.options.useKey.setPressed(true);
            this.g = true;
         } else {
            if (this.g) {
               if (this.h != -1) {
                  c.player.getInventory().selectedSlot = this.h;
                  this.h = -1;
               }

               c.options.useKey.setPressed(this.i);
               this.g = false;
            }
         }
      }
   }

   private boolean a(ItemStack itemStack, RegistryEntry<StatusEffect> registryEntry) {
      PotionContentsComponent potionContentsComponent = (PotionContentsComponent)itemStack.get(DataComponentTypes.POTION_CONTENTS);
      if (potionContentsComponent == null) {
         return false;
      }

      Iterator iterator = potionContentsComponent.customEffects().iterator();

      while (iterator.hasNext()) {
         if (((StatusEffectInstance)iterator.next()).getEffectType().equals(registryEntry)) {
            return true;
         }
      }

      return potionContentsComponent.potion()
         .map(
            registryEntry2 -> ((Potion)registryEntry2.value())
               .getEffects()
               .stream()
               .anyMatch(statusEffectInstance -> statusEffectInstance.getEffectType().equals(registryEntry))
         )
         .orElse(false);
   }
}
