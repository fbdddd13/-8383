package haron.modules.utilities;

import haron.events.ClientTickEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import meteordevelopment.orbit.EventHandler;

@ModuleInfo(a = "Sprint", b = "Automatically holds the sprint key.", c = ModuleCategory.UTILITIES)
public class Sprint extends HaronModule {
   @EventHandler
   public void a(ClientTickEvent q8krcw2) {
      if (c.player != null) {
         c.options.sprintKey.setPressed(c.player.age > 3);
      }
   }
}
