package haron.modules.utilities;

import haron.events.PacketDirection;
import haron.events.PacketEvent;
import haron.media.chat.w53bpe;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import java.util.Iterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.network.packet.s2c.play.ItemPickupAnimationS2CPacket;
import net.minecraft.text.MutableText;

@ModuleInfo(a = "Item Pickup Logger", b = "Логирует поднятые предметы в чат", c = ModuleCategory.UTILITIES)
public class ItemPickupLogger extends HaronModule {
   private final BooleanSetting e = new BooleanSetting("Только донат предметы", false);
   public static int a;
   public static boolean b;

   public BooleanSetting n() {
      return this.e;
   }

   private boolean a(ItemStack itemStack) {
      Text text = itemStack.getName();
      if (text.getString().contains("★")) {
         return true;
      }

      if (text instanceof MutableText mutableText) {
         if (mutableText.getStyle().isObfuscated()) {
            return true;
         }

         Iterator iterator = mutableText.getSiblings().iterator();

         while (iterator.hasNext()) {
            if (((Text)iterator.next()).getStyle().isObfuscated()) {
               return true;
            }
         }
      }

      return false;
   }

   @EventHandler
   public void a(PacketEvent g07m232) {
      if (g07m232.e() == PacketDirection.RECIEVE && c.player != null && c.world != null && g07m232.d() instanceof ItemPickupAnimationS2CPacket) {
         ItemPickupAnimationS2CPacket itemPickupAnimationS2CPacket = (ItemPickupAnimationS2CPacket)g07m232.d();
         if (itemPickupAnimationS2CPacket.getCollectorEntityId() == c.player.getId()) {
            if (c.world.getEntityById(itemPickupAnimationS2CPacket.getEntityId()) instanceof ItemEntity itemEntity) {
               ItemStack itemStack = itemEntity.getStack();
               if (itemStack.isEmpty()) {
                  return;
               }

               boolean bl = this.a(itemStack);
               if (!this.e.k() || bl) {
                  Text text = itemStack.getName();
                  int n = itemStack.getCount();
                  MutableText mutableText = !bl
                     ? Text.literal("§7Поднят: ").append(text)
                     : Text.literal("§7Поднят донат предмет: ").append(text);
                  if (n > 1) {
                     mutableText.append(Text.literal($sf$0(n)));
                  }

                  w53bpe.b(mutableText);
               }
            }
         }
      }
   }

   private static String $sf$0(int n) {
      return " §7x" + n;
   }
}
