package haron.modules.utilities;

import com.mojang.blaze3d.systems.RenderSystem;
import haron.events.WorldRenderPostEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.module.ModuleManager;
import haron.settings.BooleanSetting;
import haron.settings.ColorSetting;
import haron.settings.NumberSetting;
import haron.settings.SettingGroup;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.util.hit.HitResult;
import net.minecraft.client.render.VertexFormat;
import org.joml.Matrix4f;

@ModuleInfo(a = "Predictions", b = "Predicts projectile trajectories.", c = ModuleCategory.UTILITIES)
public class Predictions extends HaronModule {
   private static final int MAX_STEPS = 220;
   private static final int MARKER_SEGMENTS = 48;
   private final ColorSetting gradientColor;
   private final BooleanSetting fadeOut;
   private final NumberSetting fadeStart;
   private final SettingGroup markerGroup;
   private final BooleanSetting impactMarker;
   private final NumberSetting markerSize;
   private final BooleanSetting markerHaron;
   private final NumberSetting markerHaronSpeed;
   private final ColorSetting hitColor;
   private Vec3d impactPoint;
   private boolean hitEntity;
   private final List<Vec3d> path = new ArrayList<>();
   private final SettingGroup projectileGroup = new SettingGroup("Снаряды");
   private final BooleanSetting arrows = new BooleanSetting("Стрелы", true);
   private final BooleanSetting enderPearls = new BooleanSetting("Эндер-жемчуг", true);
   private final BooleanSetting tridents = new BooleanSetting("Трезубцы", true);
   private final BooleanSetting potions = new BooleanSetting("Зелья", true);
   private final SettingGroup lineGroup = new SettingGroup("Линия");
   private final NumberSetting lineWidth = new NumberSetting("Толщина линии", 2.0F, 1.0F, 6.0F, 0.25F);
   private final BooleanSetting useClientColor = new BooleanSetting("Цвет клиента", true);
   private final ColorSetting lineColor = new ColorSetting("Цвет линии", new Color(120, 80, 255)).a(() -> !this.useClientColor.a());
   private final BooleanSetting gradient = new BooleanSetting("Градиент", true);

   private void render(WorldRenderPostEvent kvprd92) {
      MatrixStack matrixStack = kvprd92.a();
      Vec3d vec3d = c.gameRenderer.getCamera().getPos();
      Matrix4f matrix4f = matrixStack.peek().getPositionMatrix();
      matrixStack.push();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableCull();
      RenderSystem.depthMask(false);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      RenderSystem.lineWidth(this.lineWidth.a());
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);

      for (int i = 1; i < this.path.size(); i++) {
         Vec3d vec3d2 = this.path.get(i);
         float f = this.path.size() <= 1 ? 0.0F : (float)i / (this.path.size() - 1);
         vertex(bufferBuilder, matrix4f, vec3d2.subtract(vec3d), this.pathColor(f), this.alpha(f));
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.lineWidth(1.0F);
      if (this.impactMarker.a() && this.impactPoint != null) {
         this.renderImpactMarker(matrix4f, vec3d);
      }

      RenderSystem.enableCull();
      RenderSystem.depthMask(true);
      RenderSystem.disableBlend();
      matrixStack.pop();
   }

   private ItemStack currentProjectileStack() {
      ItemStack itemStack = c.player.getMainHandStack();
      if (ProjectilePhysicsProfile.from(itemStack) != null) {
         return itemStack;
      }

      ItemStack itemStack2 = c.player.getOffHandStack();
      return ProjectilePhysicsProfile.from(itemStack2) != null ? itemStack2 : ItemStack.EMPTY;
   }

   private static int lerp(int n, int n2, float f) {
      return Math.round(n + (n2 - n) * Math.max(0.0F, Math.min(1.0F, f)));
   }

   private boolean isReady(ItemStack itemStack, ProjectilePhysicsProfile ncpsno2) {
      Item item = itemStack.getItem();
      if (item == Items.BOW || item == Items.TRIDENT) {
         return true;
      }

      if (item != Items.CROSSBOW) {
         return ncpsno2 == ProjectilePhysicsProfile.ENDER_PEARL || ncpsno2 == ProjectilePhysicsProfile.POTION;
      }

      ChargedProjectilesComponent chargedProjectilesComponent = (ChargedProjectilesComponent)itemStack.get(DataComponentTypes.CHARGED_PROJECTILES);
      return chargedProjectilesComponent != null && !chargedProjectilesComponent.isEmpty();
   }

   private void simulate(float f, ItemStack itemStack, ProjectilePhysicsProfile ncpsno2) {
      this.path.clear();
      this.impactPoint = null;
      this.hitEntity = false;
      Vec3d vec3d = c.player.getCameraPosVec(f);
      Vec3d vec3d2 = this.initialVelocity(itemStack, ncpsno2);
      this.path.add(vec3d);

      for (int i = 0; i < 220; i++) {
         Vec3d vec3d3 = vec3d.add(vec3d2);
         BlockHitResult blockHitResult = c.world.raycast(new RaycastContext(vec3d, vec3d3, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, c.player));
         boolean bl = false;
         if (blockHitResult.getType() != HitResult.Type.MISS) {
            vec3d3 = blockHitResult.getPos();
            bl = true;
         }

         EntityHitResult entityHitResult;
         if ((entityHitResult = this.findEntityHit(vec3d, vec3d3)) != null) {
            vec3d3 = entityHitResult.getPos();
            this.hitEntity = true;
            bl = true;
         }

         this.path.add(vec3d3);
         if (bl) {
            this.impactPoint = vec3d3;
            return;
         }

         if (vec3d3.y < c.world.getBottomY() - 16.0) {
            return;
         }

         vec3d = vec3d3;
         vec3d2 = vec3d2.multiply(ncpsno2.drag).subtract(0.0, ncpsno2.gravity, 0.0);
      }
   }

   private Color pathColor(float f) {
      Color color = this.useClientColor.a() ? ModuleManager.CLIENT_COLOR.n() : this.lineColor.a();
      if (!this.gradient.a()) {
         return color;
      }

      Color color3 = this.gradientColor.a();
      return new Color(lerp(color.getRed(), color3.getRed(), f), lerp(color.getGreen(), color3.getGreen(), f), lerp(color.getBlue(), color3.getBlue(), f));
   }

   private static void vertex(BufferBuilder bufferBuilder, Matrix4f matrix4f, Vec3d vec3d, Color color, float f) {
      int n = Math.max(0, Math.min(255, (int)(f * 255.0F)));
      bufferBuilder.vertex(matrix4f, (float)vec3d.x, (float)vec3d.y, (float)vec3d.z)
         .color(color.getRed(), color.getGreen(), color.getBlue(), n);
   }

   private Vec3d lookDirection() {
      double d = c.player.getYaw() * (Math.PI / 180.0);
      double d2 = c.player.getPitch() * (Math.PI / 180.0);
      double d3 = Math.cos(d2);
      return new Vec3d(-Math.sin(d) * d3, -Math.sin(d2), Math.cos(d) * d3).normalize();
   }

   private void renderImpactMarker(Matrix4f matrix4f, Vec3d vec3d) {
      Color color = this.hitEntity ? this.hitColor.a() : this.pathColor(1.0F);
      float f = this.markerSize.a()
         * (this.markerHaron.a() ? 1.0F + 0.18F * (float)Math.sin(System.currentTimeMillis() * 0.006 * this.markerHaronSpeed.a()) : 1.0F);
      Vec3d vec3d2 = this.impactPoint.subtract(vec3d);
      RenderSystem.lineWidth(2.0F);
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

      for (int i = 0; i < 48; i++) {
         double d = (Math.PI * 2) * i / 48.0;
         double d2 = (Math.PI * 2) * (i + 1) / 48.0;
         vertex(bufferBuilder, matrix4f, vec3d2.add(Math.cos(d) * f, 0.01, Math.sin(d) * f), color, 0.9F);
         vertex(bufferBuilder, matrix4f, vec3d2.add(Math.cos(d2) * f, 0.01, Math.sin(d2) * f), color, 0.9F);
      }

      BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
      RenderSystem.lineWidth(1.0F);
   }

   private Vec3d initialVelocity(ItemStack itemStack, ProjectilePhysicsProfile ncpsno2) {
      Vec3d vec3d = this.lookDirection();
      double d = ncpsno2.baseSpeed;
      Item item = itemStack.getItem();
      if (item == Items.BOW) {
         int n = c.player.isUsingItem() ? itemStack.getMaxUseTime(c.player) - c.player.getItemUseTimeLeft() : itemStack.getMaxUseTime(c.player);
         d = 3.0 * Math.min(1.0F, Math.max(0.05F, (n / 20.0F * n / 20.0F + n / 20.0F * 2.0F) / 3.0F));
      } else if (item == Items.TRIDENT) {
         int n = c.player.isUsingItem() ? itemStack.getMaxUseTime(c.player) - c.player.getItemUseTimeLeft() : itemStack.getMaxUseTime(c.player);
         d = 2.5 * Math.min(1.0F, Math.max(0.1F, n / 10.0F));
      }

      return vec3d.multiply(d).add(c.player.getVelocity().multiply(0.35));
   }

   private void clearPrediction() {
      int n = 921;
      this.path.clear();
      this.impactPoint = null;
      this.hitEntity = false;
   }

   private EntityHitResult findEntityHit(Vec3d vec3d, Vec3d vec3d2) {
      Entity entity = null;
      Vec3d vec3d3 = null;
      double d = Double.MAX_VALUE;

      for (Entity entity2 : c.world.getOtherEntities(c.player, new Box(vec3d, vec3d2).expand(1.0))) {
         double d2;
         Optional optional;
         if (entity2 != c.player
            && !entity2.isSpectator()
            && entity2.isAlive()
            && entity2 instanceof LivingEntity
            && (optional = entity2.getBoundingBox().expand(0.3).raycast(vec3d, vec3d2)).isPresent()
            && (d2 = vec3d.squaredDistanceTo((Vec3d)optional.get())) < d) {
            d = d2;
            entity = entity2;
            vec3d3 = (Vec3d)optional.get();
         }
      }

      return entity == null ? null : new EntityHitResult(entity, vec3d3);
   }

   public Predictions() {
      ColorSetting f40tf12 = new ColorSetting("Цвет градиента", new Color(80, 180, 255));
      BooleanSetting xcv91t2 = this.gradient;
      this.gradientColor = f40tf12.a(xcv91t2::a);
      this.fadeOut = new BooleanSetting("Затухание", true);
      NumberSetting by6erl2 = new NumberSetting("Начало затухания", 0.65F, 0.1F, 0.95F, 0.05F);
      BooleanSetting xcv91t3 = this.fadeOut;
      this.fadeStart = by6erl2.a(xcv91t3::a);
      this.markerGroup = new SettingGroup("Маркер попадания");
      this.impactMarker = new BooleanSetting("Маркер попадания", true);
      NumberSetting by6erl3 = new NumberSetting("Размер маркера", 0.35F, 0.1F, 1.2F, 0.05F);
      BooleanSetting xcv91t4 = this.impactMarker;
      this.markerSize = by6erl3.a(xcv91t4::a);
      BooleanSetting xcv91t5 = new BooleanSetting("Харон", true);
      BooleanSetting xcv91t6 = this.impactMarker;
      this.markerHaron = xcv91t5.a(xcv91t6::a);
      this.markerHaronSpeed = new NumberSetting("Скорость Харона", 1.0F, 0.2F, 3.0F, 0.1F).a(() -> this.impactMarker.a() && this.markerHaron.a());
      ColorSetting f40tf13 = new ColorSetting("Цвет попадания", new Color(255, 85, 110));
      BooleanSetting xcv91t7 = this.impactMarker;
      this.hitColor = f40tf13.a(xcv91t7::a);
   }

   @EventHandler
   public void a(WorldRenderPostEvent kvprd92) {
      if (c.player != null && c.world != null && c.gameRenderer != null) {
         ItemStack itemStack = this.currentProjectileStack();
         ProjectilePhysicsProfile ncpsno2 = ProjectilePhysicsProfile.from(itemStack);
         if (ncpsno2 != null && this.isEnabled(ncpsno2) && this.isReady(itemStack, ncpsno2)) {
            this.simulate(kvprd92.b(), itemStack, ncpsno2);
            if (this.path.size() > 1) {
               this.render(kvprd92);
            }
         } else {
            this.clearPrediction();
         }
      } else {
         this.clearPrediction();
      }
   }

   private boolean isEnabled(ProjectilePhysicsProfile ncpsno2) {
      switch (ncpsno2) {
         case ENDER_PEARL:
            return this.enderPearls.a();
         case TRIDENT:
            return this.tridents.a();
         case ARROW:
            return this.arrows.a();
         case POTION:
            return this.potions.a();
         default:
            throw new MatchException(null, null);
      }
   }

   private float alpha(float f) {
      return this.fadeOut.a() && !(f <= this.fadeStart.a()) ? Math.max(0.0F, 1.0F - (f - this.fadeStart.a()) / (1.0F - this.fadeStart.a())) : 1.0F;
   }
}
