package haron.modules.utilities;

import haron.events.ClientTickEvent;
import haron.events.KeyInputEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.KeybindSetting;
import haron.settings.ModeSetting;
import java.util.Optional;
import java.util.function.Predicate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.text.Text;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;

@ModuleInfo(a = "Item Swap", b = "Автоматически меняет предмет в левой руке при нажатии клавиши", c = ModuleCategory.UTILITIES)
public class ItemSwap extends HaronModule {
   private final ModeSetting e = new ModeSetting("Менять с", new String[]{"Сфера", "Тотем"}, "Сфера");
   private final ModeSetting f = new ModeSetting("Менять на", new String[]{"Сфера", "Тотем"}, "Тотем");
   private final KeybindSetting g = new KeybindSetting("Кнопка свапа", -1);
   private boolean h = false;
   private boolean i = false;
   private int j = 0;
   private int k = 0;
   private boolean l = false;
   private int m = 0;
   private int n = 0;
   private String o = "";
   private int p = -1;
   private int q = -1;
   public static int a;
   public static boolean b;

   @Override
   public void e() {
      super.e();
      this.h = false;
      this.i = false;
      this.j = 0;
      this.k = 0;
      this.l = false;
      this.m = 0;
      this.n = 0;
   }

   private Optional<Integer> b(Predicate<ItemStack> predicate) {
      for (int i = 9; i < 36; i++) {
         if (predicate.test(c.player.getInventory().getStack(i))) {
            return Optional.of(i);
         }
      }

      return Optional.empty();
   }

   private void b(int n) {
      this.p = c.player.getInventory().selectedSlot;
      this.q = n;
      this.i = true;
      this.k = 0;
      this.n = 0;
   }

   private void c(int n) {
      c.interactionManager.clickSlot(c.player.currentScreenHandler.syncId, n, 40, SlotActionType.SWAP, c.player);
   }

   private void n() {
      if (this.n > 0) {
         this.n--;
      }

      switch (this.k) {
         case 0:
            c.player.getInventory().selectedSlot = this.q;
            this.n = 2;
            this.k = 1;
            break;
         case 1:
            c.player.networkHandler.sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN));
            this.n = 2;
            this.k = 2;
            break;
         case 2:
            c.player.getInventory().selectedSlot = this.p;
            c.player.sendMessage(Text.literal("§fСвапнул на ").append(c.player.getOffHandStack().getName()), true);
            this.i = false;
            this.k = 0;
      }
   }

   @Override
   public void f() {
      super.f();
      if (c.currentScreen instanceof InventoryScreen) {
         c.player.closeHandledScreen();
      }

      this.i = false;
      this.h = false;
   }

   @EventHandler
   public void a(KeyInputEvent dsgqgn2) {
      if (c.player != null && c.world != null && c.currentScreen == null && dsgqgn2.a() == this.g.a() && dsgqgn2.c() == 1) {
         this.o = this.q();
         Optional<Integer> optional = this.a(itemStack -> this.a(itemStack, this.o));
         if (optional.isPresent()) {
            this.b(optional.get());
            return;
         }

         if (!this.a(this.o)) {
            c.player.sendMessage(Text.literal("§cНе найден предмет для свапа!"), true);
            return;
         }

         this.h = true;
         this.j = 0;
         this.l = false;
         this.m = 0;
      }
   }

   @EventHandler
   public void a(ClientTickEvent q8krcw2) {
      if (c.player != null) {
         if (this.i) {
            this.n();
         }

         if (this.h) {
            this.o();
         }
      }
   }

   private boolean a(String string) {
      return "Тотем".equals(string) || "Сфера".equals(string);
   }

   private Optional<Integer> a(Predicate<ItemStack> predicate) {
      for (int i = 0; i < 9; i++) {
         if (predicate.test(c.player.getInventory().getStack(i))) {
            return Optional.of(i);
         }
      }

      return Optional.empty();
   }

   private boolean a(ItemStack itemStack, String string) {
      if (itemStack.isEmpty()) {
         return false;
      } else if ("Сфера".equals(string)) {
         return itemStack.getItem() == Items.PLAYER_HEAD;
      } else {
         return "Тотем".equals(string) ? itemStack.getItem() == Items.TOTEM_OF_UNDYING : false;
      }
   }

   private void o() {
      if (this.m > 0) {
         this.m--;
      } else {
         switch (this.j) {
            case 0:
               if (c.player.getAbilities().creativeMode) {
                  this.j = 1;
               } else if (!this.b(itemStack -> this.a(itemStack, this.o)).isPresent()) {
                  c.player.sendMessage(Text.literal("§cНе найден предмет для свапа!"), true);
                  this.h = false;
               } else {
                  if (!(c.currentScreen instanceof InventoryScreen)) {
                     c.setScreen(new InventoryScreen(c.player));
                  }

                  this.m = 2;
                  this.j = 1;
               }
               break;
            case 1:
               if (c.currentScreen instanceof InventoryScreen && !this.l) {
                  this.p();
                  this.l = true;
                  this.m = 2;
                  this.j = 2;
               }
               break;
            case 2:
               if (c.currentScreen instanceof InventoryScreen) {
                  c.setScreen((Screen)null);
               }

               this.h = false;
               this.j = 0;
         }
      }
   }

   private void p() {
      Optional<Integer> optional = this.b(itemStack -> this.a(itemStack, this.o));
      if (optional.isPresent()) {
         this.c(optional.get());
         c.player.sendMessage(Text.literal("§fСвапнул на ").append(c.player.getOffHandStack().getName()), true);
      }
   }

   private String q() {
      ItemStack itemStack = c.player.getOffHandStack();
      String string;
      return !this.a(itemStack, string = this.e.d()) ? string : this.f.d();
   }
}
