package haron.modules.utilities;

import haron.events.ClientTickEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;

@ModuleInfo(a = "Fast EXP", b = "Ускоряет выбрасывание бутылок опыта при ПКМ", c = ModuleCategory.UTILITIES)
public class FastExp extends HaronModule {
   private final NumberSetting throwsPerTick = new NumberSetting("Бросков в тик", 5.0F, 1.0F, 20.0F, 1.0F);
   private final BooleanSetting onlyInHand = new BooleanSetting("Только в руке", "Бросать только из основной руки", true);
   public static int a;
   public static boolean b;

   @EventHandler
   public void onTick(ClientTickEvent q8krcw2) {
      if (c.player != null && c.world != null && c.currentScreen == null) {
         if (c.options.useKey.isPressed()) {
            Hand hand = c.player.getActiveHand();
            if (c.player.getStackInHand(hand).getItem() != Items.EXPERIENCE_BOTTLE) {
               if (this.onlyInHand.get()) {
                  return;
               }

               if (c.player.getMainHandStack().getItem() != Items.EXPERIENCE_BOTTLE) {
                  return;
               }

               hand = Hand.MAIN_HAND;
            }

            int n = (int)this.throwsPerTick.a();

            for (int i = 0; i < n; i++) {
               c.player.networkHandler.sendPacket(new PlayerInteractItemC2SPacket(hand, 0, c.player.getYaw(), c.player.getPitch()));
            }
         }
      }
   }
}
