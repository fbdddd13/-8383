package haron.modules.utilities;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.NumberSetting;

@ModuleInfo(a = "Optimizations", b = "Повышение FPS: частицы, тени, погода, облака, дальние сущности, оптимизация моделей и мира", c = ModuleCategory.UTILITIES)
public class Optimizations extends HaronModule {
   public static Optimizations INSTANCE;
   public final BooleanSetting noParticles = new BooleanSetting("Убрать частицы", true);
   public final BooleanSetting noEntityShadows = new BooleanSetting("Убрать тени сущностей", true);
   public final BooleanSetting noWeather = new BooleanSetting("Не рендерить погоду", true);
   public final BooleanSetting noClouds = new BooleanSetting("Убрать облака", true);
   public final BooleanSetting noFog = new BooleanSetting("Убрать туман", true);
   public final BooleanSetting noGlint = new BooleanSetting("Убрать глинт энчантов", true);
   public final BooleanSetting limitEntityDistance = new BooleanSetting("Резать дальние сущности", true);
   public final NumberSetting entityRenderDistance = new NumberSetting("Дальность сущностей", 48.0F, 16.0F, 128.0F, 8.0F);
   public final BooleanSetting maxEntityCulling = new BooleanSetting("Лимит мобов на экране", true);
   public final NumberSetting maxVisibleEntities = new NumberSetting("Макс. сущностей", 128.0F, 32.0F, 512.0F, 16.0F);
   public final BooleanSetting limitNametags = new BooleanSetting("Резать дальние ники", true);
   public final NumberSetting nametagDistance = new NumberSetting("Дальность ников", 24.0F, 8.0F, 96.0F, 4.0F);
   public final BooleanSetting limitArmor = new BooleanSetting("Резать дальнюю броню", true);
   public final NumberSetting armorDistance = new NumberSetting("Дальность брони", 32.0F, 8.0F, 96.0F, 4.0F);
   public final BooleanSetting fastChests = new BooleanSetting("Упростить сундуки", true);
   public final BooleanSetting noDropRotation = new BooleanSetting("Статичный дроп предм.", true);
   public final BooleanSetting noTotemAnimation = new BooleanSetting("Убрать анимацию тотема", true);
   public final BooleanSetting noExplosionParticles = new BooleanSetting("Убрать взрывы/кристаллы", true);
   public final BooleanSetting animatedTextures = new BooleanSetting("Анимированные текстуры", false);
   public final BooleanSetting noSky = new BooleanSetting("Убрать небо", true);
   public final BooleanSetting noStars = new BooleanSetting("Убрать звёзды", true);
   public final BooleanSetting noWater = new BooleanSetting("Убрать воду", true);
   public final BooleanSetting noEntities = new BooleanSetting("Убрать сущности (кроме игрока)", true);
   public final BooleanSetting shortRenderDist = new BooleanSetting("Уменьшить дальность (6 чанков)", true);
   public final BooleanSetting noBlockEntities = new BooleanSetting("Убрать блок-сущности (сундуки, печи)", true);

   public static boolean cullDistantEntities() {
      return INSTANCE.k() && INSTANCE.limitEntityDistance.k();
   }

   public static boolean disableTextureAnimations() {
      return INSTANCE.k() && !INSTANCE.animatedTextures.k();
   }

   public static boolean isEntityLimitReached(int n) {
      return INSTANCE.k() && INSTANCE.maxEntityCulling.k() ? n > INSTANCE.maxVisibleEntities.get() : false;
   }

   public static double maxNametagDistanceSq() {
      double d = INSTANCE.nametagDistance.get();
      return d * d;
   }

   public static double maxEntityDistanceSq() {
      double d = INSTANCE.entityRenderDistance.get();
      return d * d;
   }

   public static boolean hideSky() {
      return INSTANCE.k() && INSTANCE.noSky.k();
   }

   public static boolean hideClouds() {
      return INSTANCE.k() && INSTANCE.noClouds.k();
   }

   public static boolean hideWater() {
      return INSTANCE.k() && INSTANCE.noWater.k();
   }

   public static boolean hideFog() {
      return INSTANCE.k() && INSTANCE.noFog.k();
   }

   public static boolean hideGlint() {
      return INSTANCE.k() && INSTANCE.noGlint.k();
   }

   public static boolean shortDist() {
      return INSTANCE.k() && INSTANCE.shortRenderDist.k();
   }

   public static boolean hideStars() {
      return INSTANCE.k() && INSTANCE.noStars.k();
   }

   public static boolean stopDropRotation() {
      return INSTANCE.k() && INSTANCE.noDropRotation.k();
   }

   public static boolean hideTotemAnimation() {
      return INSTANCE.k() && INSTANCE.noTotemAnimation.k();
   }

   public static double maxArmorDistanceSq() {
      double d = INSTANCE.armorDistance.get();
      return d * d;
   }

   public static boolean hideEntities() {
      return INSTANCE.k() && INSTANCE.noEntities.k();
   }

   public static boolean hideEntityShadows() {
      return INSTANCE.k() && INSTANCE.noEntityShadows.k();
   }

   public static boolean hideBlockEntities() {
      return INSTANCE.k() && INSTANCE.noBlockEntities.k();
   }

   public static boolean cullDistantArmor() {
      return INSTANCE.k() && INSTANCE.limitArmor.k();
   }

   public static boolean cullParticles() {
      return INSTANCE.k() && INSTANCE.noParticles.k();
   }

   public static boolean hideExplosions() {
      return INSTANCE.k() && INSTANCE.noExplosionParticles.k();
   }

   public static boolean cullNametags() {
      return INSTANCE.k() && INSTANCE.limitNametags.k();
   }

   public static boolean hideWeather() {
      return INSTANCE.k() && INSTANCE.noWeather.k();
   }

   public static boolean useFastChests() {
      return INSTANCE.k() && INSTANCE.fastChests.k();
   }

   public Optimizations() {
      INSTANCE = this;
   }
}
