package haron.modules.utilities;

import haron.events.ClientTickEvent;
import haron.events.WorldRenderPostEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.SettingGroup;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

@ModuleInfo(a = "HW Helper", b = "Shows helper timers for HolyWorld utility items.", c = ModuleCategory.UTILITIES)
public class HwHelper extends HaronModule {
   private static final long MESSAGE_DURATION_MS = 4000L;
   private boolean stunTrapCooldownActive;
   private long stunTrapStartMs;
   private boolean explosiveTrapCooldownActive;
   private long explosiveTrapStartMs;
   private final BooleanSetting trackItems = new BooleanSetting("Отслеживать предметы", true);
   private final BooleanSetting showStunTrap = new BooleanSetting("Оглушающая ловушка", true);
   private final BooleanSetting showExplosiveTrap = new BooleanSetting("Взрывная ловушка", true);
   private final SettingGroup renderGroup = new SettingGroup("Рендер");
   private final BooleanSetting renderNearbyTrapBox = new BooleanSetting("Рендер ближних ловушек", true);
   private int lastStunTrapCount = 0;
   private int lastExplosiveTrapCount = 0;

   private int countItem(Item item) {
      int n = 0;

      for (int i = 0; i < c.player.getInventory().size(); i++) {
         ItemStack itemStack = c.player.getInventory().getStack(i);
         if (itemStack.getItem() == item) {
            n += itemStack.getCount();
         }
      }

      return n;
   }

   private void updateTrackedItem(Item item, boolean bl, boolean bl2) {
      int n2 = this.countItem(item);
      boolean bl3 = c.player.getItemCooldownManager().isCoolingDown(item.getDefaultStack());
      int n = bl2 ? this.lastStunTrapCount : this.lastExplosiveTrapCount;
      if (bl && bl3 && n2 < n) {
         if (bl2) {
            this.stunTrapCooldownActive = true;
            this.stunTrapStartMs = System.currentTimeMillis();
         } else {
            this.explosiveTrapCooldownActive = true;
            this.explosiveTrapStartMs = System.currentTimeMillis();
         }
      }

      if (bl2) {
         this.lastStunTrapCount = n2;
      } else {
         this.lastExplosiveTrapCount = n2;
      }
   }

   private void showOverlayMessage() {
      long l = System.currentTimeMillis();
      String string3 = this.getCooldownMessage("Stun Trap", l, this.stunTrapStartMs, this.stunTrapCooldownActive);
      if (string3 == null) {
         this.stunTrapCooldownActive = false;
      }

      String string2;
      if ((string2 = this.getCooldownMessage("Explosive Trap", l, this.explosiveTrapStartMs, this.explosiveTrapCooldownActive)) == null) {
         this.explosiveTrapCooldownActive = false;
      }

      String var10000 = string3 != null && string2 != null ? $sf$0(string3, string2) : (string3 != null ? string3 : string2);
      String string = var10000;
      if (var10000 != null) {
         c.inGameHud.setOverlayMessage(Text.of(string), false);
      }
   }

   private String getCooldownMessage(String string, long l, long l2, boolean bl) {
      if (!bl) {
         return null;
      }

      long l3 = l - l2;
      return l3 >= 4000L ? null : String.format("%ModuleCard cooldown: %.1fs", string, (4000L - l3) / 1000.0);
   }

   @EventHandler
   public void a(ClientTickEvent q8krcw2) {
      if (c.world != null && c.player != null && this.trackItems.k()) {
         this.updateTrackedItem(Items.PRISMARINE_SHARD, this.showStunTrap.k(), true);
         this.updateTrackedItem(Items.POPPED_CHORUS_FRUIT, this.showExplosiveTrap.k(), false);
         this.showOverlayMessage();
      }
   }

   @EventHandler
   public void a(WorldRenderPostEvent kvprd92) {
   }

   private static String $sf$0(String string, String string2) {
      return string + " | " + string2;
   }
}
