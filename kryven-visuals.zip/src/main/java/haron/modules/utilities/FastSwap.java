package haron.modules.utilities;

import haron.core.BooleanCoercion;
import haron.events.KeyInputEvent;
import haron.inventory.rk1ts2;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.KeybindSetting;
import haron.settings.NumberSetting;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PotionItem;
import net.minecraft.potion.Potion;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.component.DataComponentTypes;

@ModuleInfo(a = "Fast Swap", b = "Быстрый выбор предметов по нажатию клавиш", c = ModuleCategory.UTILITIES)
public class FastSwap extends HaronModule {
   private final KeybindSetting e = new KeybindSetting("Кнопка хоруса", -1);
   private final KeybindSetting f = new KeybindSetting("Кнопка эндерпёрла", -1);
   private final KeybindSetting g = new KeybindSetting("Кнопка зелья исцеления", -1);
   private final KeybindSetting h = new KeybindSetting("Кнопка трапки", -1);
   private final KeybindSetting i = new KeybindSetting("Кнопка пласта", -1);
   private final KeybindSetting j = new KeybindSetting("Кнопка дезориентации", -1);
   private final KeybindSetting k = new KeybindSetting("Кнопка явной пыли", -1);
   private final KeybindSetting l = new KeybindSetting("Кнопка шаровой молнии", -1);
   private final KeybindSetting m = new KeybindSetting("Кнопка кома слизи", -1);
   private final KeybindSetting n = new KeybindSetting("Кнопка черепашьего захвата", -1);
   private final KeybindSetting o = new KeybindSetting("Кнопка паучьей судьбы", -1);
   private final KeybindSetting p = new KeybindSetting("Кнопка стана", -1);
   private final KeybindSetting q = new KeybindSetting("Кнопка магнитного шара", -1);
   private final KeybindSetting r = new KeybindSetting("Кнопка взрывной трапки", -1);
   private final KeybindSetting s = new KeybindSetting("Кнопка взрывной штучки", -1);
   private final KeybindSetting t = new KeybindSetting("Кнопка стана звезды", -1);
   private final KeybindSetting u = new KeybindSetting("Кнопка кома снега", -1);
   private final BooleanSetting v = new BooleanSetting("Отображать бинды", true);
   private final NumberSetting w = new NumberSetting("Размер шрифта биндов", 1.0F, 0.5F, 2.0F, 0.1F);
   private final List<ItemSwapBinding> x;
   public static int a;
   public static boolean b;

   public List<ItemSwapBinding> G() {
      return this.x;
   }

   public FastSwap() {
      ItemSwapBinding[] rrca84Array = new ItemSwapBinding[]{
         new ItemSwapBinding(this.h, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.NETHERITE_SCRAP ? 0 : 1)),
         new ItemSwapBinding(this.i, itemStack -> {
            int n = itemStack.getItem() != Items.DRIED_KELP ? 0 : 1;
            return BooleanCoercion.from(n);
         }),
         new ItemSwapBinding(this.j, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.ENDER_EYE ? 0 : 1)),
         new ItemSwapBinding(this.k, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.SUGAR ? 0 : 1)),
         new ItemSwapBinding(this.l, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.NETHER_STAR ? 0 : 1)),
         new ItemSwapBinding(this.m, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.SLIME_BALL ? 0 : 1)),
         new ItemSwapBinding(this.n, itemStack -> {
            int n = itemStack.getItem() != Items.TURTLE_SCUTE ? 0 : 1;
            return BooleanCoercion.from(n);
         }),
         new ItemSwapBinding(this.o, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.COBWEB ? 0 : 1)),
         new ItemSwapBinding(this.p, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.ENDER_EYE ? 0 : 1)),
         new ItemSwapBinding(this.q, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.FIREWORK_STAR ? 0 : 1)),
         new ItemSwapBinding(this.e, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.CHORUS_FRUIT ? 0 : 1)),
         new ItemSwapBinding(this.f, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.ENDER_PEARL ? 0 : 1)),
         new ItemSwapBinding(this.g, this::a),
         new ItemSwapBinding(this.r, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.PRISMARINE_SHARD ? 0 : 1)),
         new ItemSwapBinding(this.s, itemStack -> BooleanCoercion.from(itemStack.getItem() != Items.FIRE_CHARGE ? 0 : 1)),
         new ItemSwapBinding(this.t, itemStack -> {
            int n = 153;
            return BooleanCoercion.from(itemStack.getItem() != Items.NETHER_STAR ? 0 : 1);
         }),
         new ItemSwapBinding(this.u, itemStack -> {
            int n = 457;
            return BooleanCoercion.from(itemStack.getItem() != Items.SNOWBALL ? 0 : 1);
         })
      };
      this.x = Collections.unmodifiableList(Arrays.asList(rrca84Array));
   }

   public KeybindSetting B() {
      return this.s;
   }

   public KeybindSetting C() {
      return this.t;
   }

   public KeybindSetting D() {
      return this.u;
   }

   public NumberSetting F() {
      return this.w;
   }

   public KeybindSetting x() {
      return this.o;
   }

   public KeybindSetting s() {
      return this.j;
   }

   public KeybindSetting n() {
      return this.e;
   }

   @EventHandler
   public void a(KeyInputEvent dsgqgn2) {
      if (c.player != null && c.currentScreen == null) {
         int pressedKey = dsgqgn2.a();
         this.x.stream().filter(rrca842 -> {
            int boundKey = rrca842.c.a();
            return BooleanCoercion.from(boundKey != -1 && boundKey != 0 && boundKey == pressedKey ? 1 : 0);
         }).findFirst().flatMap(rrca842 -> rk1ts2.a(rrca842.d, false, true)).ifPresent(n -> c.player.getInventory().selectedSlot = n);
      }
   }

   public boolean a(ItemStack itemStack) {
      if (itemStack.getItem() != Items.POTION) {
         return false;
      }

      Optional optional;
      if (itemStack.getItem() instanceof PotionItem
         && (optional = ((PotionContentsComponent)itemStack.getOrDefault(DataComponentTypes.POTION_CONTENTS, PotionContentsComponent.DEFAULT)).potion()).isPresent()) {
         Iterator iterator = ((Potion)((RegistryEntry)optional.get()).value()).getEffects().iterator();

         while (iterator.hasNext()) {
            if (((StatusEffectInstance)iterator.next()).getEffectType() == StatusEffects.INSTANT_HEALTH) {
               return true;
            }
         }
      }

      return false;
   }

   public KeybindSetting o() {
      return this.f;
   }

   public KeybindSetting p() {
      return this.g;
   }

   public KeybindSetting t() {
      return this.k;
   }

   public KeybindSetting v() {
      return this.m;
   }

   public KeybindSetting q() {
      return this.h;
   }

   public KeybindSetting z() {
      return this.q;
   }

   public KeybindSetting w() {
      return this.n;
   }

   public KeybindSetting u() {
      return this.l;
   }

   public KeybindSetting r() {
      return this.i;
   }

   public BooleanSetting E() {
      return this.v;
   }

   public KeybindSetting y() {
      return this.p;
   }

   public KeybindSetting A() {
      return this.r;
   }
}
