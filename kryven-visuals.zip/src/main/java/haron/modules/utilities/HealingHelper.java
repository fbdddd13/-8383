package haron.modules.utilities;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.NumberSetting;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

@ModuleInfo(a = "Healing Helper", b = "Highlights useful healing items.", c = ModuleCategory.UTILITIES)
public class HealingHelper extends HaronModule {
   private final BooleanSetting onlyWhenNeeded = new BooleanSetting("Только при необходимости", true);
   private final NumberSetting healthThreshold = new NumberSetting("Порог здоровья", 14.0F, 1.0F, 20.0F, 1.0F);
   private final NumberSetting hungerThreshold = new NumberSetting("Порог голода", 15.0F, 1.0F, 20.0F, 1.0F);
   private final NumberSetting minimumPriority = new NumberSetting("Минимальный приоритет", 1.0F, 1.0F, 4.0F, 1.0F);
   private final Map<Item, Integer> itemPriority;

   private boolean shouldUseNow(Item item) {
      if (c.player == null) {
         return true;
      } else {
         return item == Items.GOLDEN_CARROT
            ? c.player.getHungerManager().getFoodLevel() <= this.hungerThreshold.b()
            : c.player.getHealth() + c.player.getAbsorptionAmount() <= this.healthThreshold.a();
      }
   }

   public HealingHelper() {
      HashMap<Item, Integer> hashMap = new HashMap<>();
      hashMap.put(Items.POTION, 1);
      hashMap.put(Items.GOLDEN_CARROT, 2);
      hashMap.put(Items.GOLDEN_APPLE, 3);
      hashMap.put(Items.ENCHANTED_GOLDEN_APPLE, 4);
      this.itemPriority = Collections.unmodifiableMap(hashMap);
   }

   public Map<Item, Integer> s() {
      return this.itemPriority;
   }

   public List<Item> n() {
      return new ArrayList<>(this.itemPriority.keySet());
   }

   public int a(Item item) {
      return this.itemPriority.getOrDefault(item, 0);
   }

   public boolean a(ItemStack itemStack) {
      return itemStack != null && !itemStack.isEmpty() && this.a(itemStack.getItem()) >= this.minimumPriority.b()
         ? !this.onlyWhenNeeded.a() || this.shouldUseNow(itemStack.getItem())
         : false;
   }

   public BooleanSetting o() {
      return this.onlyWhenNeeded;
   }

   public NumberSetting p() {
      return this.healthThreshold;
   }

   public NumberSetting q() {
      return this.hungerThreshold;
   }

   public NumberSetting r() {
      return this.minimumPriority;
   }
}
