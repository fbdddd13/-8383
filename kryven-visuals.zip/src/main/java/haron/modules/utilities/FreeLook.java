package haron.modules.utilities;

import haron.events.ClientTickEvent;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.KeybindSetting;
import haron.settings.NumberSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.option.Perspective;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(a = "Free Look", b = "Позволяет вращать камеру отдельно от игрока.", c = ModuleCategory.UTILITIES)
public class FreeLook extends HaronModule {
   public static boolean active;
   public static float freeYaw;
   public static float freePitch;
   public final NumberSetting pDistanceTo = new NumberSetting("Дистанция до камеры", 7.5F, 1.0F, 25.0F, 0.5F);
   public final BooleanSetting free = new BooleanSetting("Свободная камера", false);
   public final KeybindSetting key = new KeybindSetting("Клавиша", 342);
   private float startYaw;
   private float startPitch;
   private Perspective previousPerspective = Perspective.FIRST_PERSON;
   private boolean activatedByThisModule = false;
   private boolean previousKeyPressed = false;

   @EventHandler
   public void onTick(ClientTickEvent q8krcw2) {
      if (c.player != null && c.getWindow() != null) {
         boolean bl = GLFW.glfwGetKey(c.getWindow().getHandle(), this.key.a()) == 1;
         if (this.free.k()) {
            if (bl && !active) {
               this.enableFreeLook();
            } else if (!bl && active && this.activatedByThisModule) {
               this.disableFreeLook();
            }

            if (active) {
               c.options.setPerspective(Perspective.THIRD_PERSON_BACK);
               c.player.setYaw(this.startYaw);
               c.player.setPitch(this.startPitch);
               c.player.headYaw = this.startYaw;
               c.player.bodyYaw = this.startYaw;
            }
         } else if (bl && !this.previousKeyPressed) {
            if (active) {
               this.disableFreeLook();
            } else {
               this.enableFreeLook();
            }
         }

         this.previousKeyPressed = bl;
      } else {
         this.resetIfNeeded();
      }
   }

   private void resetIfNeeded() {
      if (active && this.activatedByThisModule) {
         this.disableFreeLook();
      }

      this.activatedByThisModule = false;
      this.previousKeyPressed = false;
   }

   public static void rotateTowards(double d, double d2) {
      freePitch = MathHelper.clamp((float)(freePitch + d2 * 0.15), -90.0F, 90.0F);
      freeYaw = (float)(freeYaw + d * 0.15);
   }

   private void disableFreeLook() {
      if (c.options != null) {
         c.options.setPerspective(this.previousPerspective);
      }

      active = false;
      this.activatedByThisModule = false;
   }

   private void enableFreeLook() {
      if (c.player != null && c.options != null) {
         this.previousPerspective = c.options.getPerspective();
         this.startYaw = c.player.getYaw();
         this.startPitch = c.player.getPitch();
         freeYaw = this.startYaw;
         freePitch = this.startPitch;
         c.options.setPerspective(Perspective.THIRD_PERSON_BACK);
         active = true;
         this.activatedByThisModule = true;
      }
   }

   @Override
   public void e() {
      super.e();
      if (this.free.k() && c.player != null) {
         this.startYaw = c.player.getYaw();
         this.startPitch = c.player.getPitch();
      }
   }

   @Override
   public void f() {
      if (this.activatedByThisModule) {
         this.disableFreeLook();
      }

      super.f();
   }
}
