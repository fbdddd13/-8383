package haron.modules.hud;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.NumberSetting;

@ModuleInfo(a = "Inventory HUD", b = "Отображение инвентаря.", c = ModuleCategory.HUD)
public class InventoryHud extends HaronModule {
   private final NumberSetting scale = new NumberSetting("Масштаб", 1.0F, 0.8F, 2.0F, 0.1F);

   public InventoryHud() {
      this.collectSettings();
   }

   public NumberSetting n() {
      return this.scale;
   }
}
