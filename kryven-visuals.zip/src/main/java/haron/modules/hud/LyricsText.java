package haron.modules.hud;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.NumberSetting;

@ModuleInfo(a = "Lyrics Text", b = "Показывает текст текущей песни на экране", c = ModuleCategory.HUD)
public class LyricsText extends HaronModule {
   public final NumberSetting fontSize = new NumberSetting("Размер шрифта", 2.0F, 1.0F, 4.0F, 0.1F);
   public final BooleanSetting shadow = new BooleanSetting("Тень", true);
   public final BooleanSetting background = new BooleanSetting("Фон", true);

   public LyricsText() {
      this.collectSettings();
   }
}
