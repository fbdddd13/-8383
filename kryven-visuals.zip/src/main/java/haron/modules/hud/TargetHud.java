package haron.modules.hud;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.NumberSetting;

@ModuleInfo(a = "Target HUD", b = "Shows target information.", c = ModuleCategory.HUD)
public class TargetHud extends HaronModule {
   private final NumberSetting scale = new NumberSetting("Масштаб", 1.0F, 1.0F, 2.0F, 0.1F);
   private final BooleanSetting showArmor = new BooleanSetting("Броня", true);
   private final BooleanSetting showDurability = new BooleanSetting("Прочность", true);

   public boolean isShowDurability() {
      return this.showDurability.get();
   }

   public boolean isShowArmor() {
      return this.showArmor.get();
   }

   public TargetHud() {
      this.collectSettings();
   }

   public NumberSetting n() {
      return this.scale;
   }
}
