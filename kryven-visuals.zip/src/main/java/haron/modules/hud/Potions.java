package haron.modules.hud;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.NumberSetting;

@ModuleInfo(a = "Potions", b = "Shows active potion effects.", c = ModuleCategory.HUD)
public class Potions extends HaronModule {
   private final BooleanSetting vanillaHud = new BooleanSetting("Ванильный HUD", false);
   private final NumberSetting scale = new NumberSetting("Масштаб", 1.0F, 1.0F, 2.0F, 0.1F);

   public Potions() {
      this.collectSettings();
   }

   public BooleanSetting n() {
      return this.vanillaHud;
   }

   public NumberSetting o() {
      return this.scale;
   }
}
