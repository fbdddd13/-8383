package haron.modules.hud;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;

@ModuleInfo(a = "Effect Notify", b = "Notifies about status effect changes.", c = ModuleCategory.HUD)
public class EffectNotify extends HaronModule {
}
