package haron.modules.hud;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.NumberSetting;

@ModuleInfo(a = "Media Player", b = "Показывает текущую песню на экране", c = ModuleCategory.HUD)
public class MediaPlayer extends HaronModule {
   public final NumberSetting scale = new NumberSetting("Масштаб", 1.0F, 0.5F, 2.0F, 0.1F);

   public MediaPlayer() {
      this.collectSettings();
   }
}
