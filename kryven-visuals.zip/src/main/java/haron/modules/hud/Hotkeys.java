package haron.modules.hud;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.NumberSetting;

@ModuleInfo(a = "Hotkeys", b = "Displays active key bindings.", c = ModuleCategory.HUD)
public class Hotkeys extends HaronModule {
   private final NumberSetting scale = new NumberSetting("Масштаб", 1.0F, 1.0F, 2.0F, 0.1F);

   public Hotkeys() {
      this.collectSettings();
   }

   public NumberSetting n() {
      int n = 742;
      return this.scale;
   }
}
