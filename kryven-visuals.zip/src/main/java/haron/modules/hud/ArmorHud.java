package haron.modules.hud;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;

@ModuleInfo(a = "Armor HUD", b = "Displays armor near the hotbar.", c = ModuleCategory.HUD)
public class ArmorHud extends HaronModule {
}
