package haron.modules.hud;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.NumberSetting;

@ModuleInfo(a = "Cooldowns HUD", b = "Displays item cooldowns on screen.", c = ModuleCategory.HUD)
public class CooldownsHud extends HaronModule {
   private final NumberSetting scale = new NumberSetting("Масштаб", 1.0F, 1.0F, 2.0F, 0.1F);

   public CooldownsHud() {
      this.collectSettings();
   }

   public NumberSetting n() {
      return this.scale;
   }
}
