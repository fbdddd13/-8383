package haron.modules.hud;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.NumberSetting;

@ModuleInfo(a = "Saturation HUD", b = "Отображение полоски сытости над едой.", c = ModuleCategory.HUD)
public class SaturationHud extends HaronModule {
   private final NumberSetting scale = new NumberSetting("Масштаб", 1.0F, 0.8F, 2.0F, 0.1F);

   public SaturationHud() {
      this.collectSettings();
   }

   public NumberSetting n() {
      int n = 610;
      return this.scale;
   }
}
