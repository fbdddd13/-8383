package haron.modules.hud;

import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.BooleanSetting;
import haron.settings.NumberSetting;

@ModuleInfo(a = "Watermark", b = "Отображает водяной знак клиента", c = ModuleCategory.HUD)
public class Watermark extends HaronModule {
   public final BooleanSetting showFps = new BooleanSetting("FPS", true);
   public final BooleanSetting showPing = new BooleanSetting("Пинг", true);
   public final NumberSetting scale = new NumberSetting("Размер", 1.0F, 0.5F, 2.0F, 0.05F);

   public Watermark() {
      this.collectSettings();
   }
}
