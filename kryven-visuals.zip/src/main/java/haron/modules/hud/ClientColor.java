package haron.modules.hud;

import haron.gui.core.ClickGuiScreen;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleInfo;
import haron.settings.ColorSetting;
import haron.settings.ModeSetting;
import java.awt.Color;

@ModuleInfo(a = "Client Color", b = "Настройка основного цвета клиента", c = ModuleCategory.HUD)
public class ClientColor extends HaronModule {
   private static ClientColor INSTANCE;
   private static final int GRADIENT_DURATION_MS = 4000;
   private static final int ASTOLFO_DURATION_MS = 6000;
   private static final int RAINBOW_DURATION_MS = 6000;
   private static final String MODE_STATIC = "Статичный";
   private static final String MODE_GRADIENT = "Градиент";
   private static final String MODE_ASTOLFO = "Астольфо";
   private static final String MODE_RAINBOW = "Радуга";
   private static final String[] MODES = new String[]{"Статичный", "Градиент", "Астольфо", "Радуга"};
   private static final Color DEFAULT_COLOR = new Color(255, 155, 35);
   private static final Color DEFAULT_GRADIENT_START = new Color(255, 210, 80);
   private static final Color DEFAULT_GRADIENT_END = new Color(255, 120, 25);
   private static final Color[] ASTOLFO_COLORS = new Color[]{new Color(255, 121, 198), new Color(170, 70, 255), new Color(80, 181, 255)};
   private static final Color[] PRESET_COLORS = new Color[]{
      new Color(150, 180, 255),
      new Color(255, 145, 190),
      new Color(190, 130, 255),
      new Color(255, 230, 105),
      new Color(255, 175, 75),
      new Color(255, 125, 55),
      new Color(100, 220, 255),
      new Color(100, 235, 190),
      new Color(120, 255, 145),
      new Color(255, 105, 115)
   };
   public final ModeSetting a = new ModeSetting("Режим", MODES, "Статичный");
   public final ColorSetting b = new ColorSetting("Цвет", DEFAULT_COLOR).a(() -> this.a.b("Статичный"));
   public final ColorSetting e = new ColorSetting("Цвет #1", DEFAULT_GRADIENT_START).a(() -> this.a.b("Градиент"));
   public final ColorSetting f = new ColorSetting("Цвет #2", DEFAULT_GRADIENT_END).a(() -> {
      int n = 688;
      return this.a.b("Градиент");
   });

   private static Color interpolate(Color color, Color color2, float f) {
      if (color == null) {
         color = Color.WHITE;
      }

      if (color2 == null) {
         color2 = Color.WHITE;
      }

      float f2 = Math.max(0.0F, Math.min(1.0F, f));
      return new Color(
         lerp(color.getRed(), color2.getRed(), f2),
         lerp(color.getGreen(), color2.getGreen(), f2),
         lerp(color.getBlue(), color2.getBlue(), f2),
         lerp(color.getAlpha(), color2.getAlpha(), f2)
      );
   }

   public Color getColor() {
      return this.n();
   }

   private static float sineProgress(int n) {
      return (float)(0.5 * (1.0 + Math.sin(System.currentTimeMillis() % n * ((Math.PI * 2) / n))));
   }

   private static float linearProgress(int n) {
      return (float)(System.currentTimeMillis() % n) / n;
   }

   public static Color defaultColor() {
      return DEFAULT_COLOR;
   }

   private static Color cycleColors(Color[] colorArray, int n) {
      if (colorArray != null && colorArray.length != 0) {
         float f = linearProgress(n) * colorArray.length;
         int n2 = (int)f % colorArray.length;
         int n3 = (n2 + 1) % colorArray.length;
         return interpolate(colorArray[n2], colorArray[n3], f - (int)f);
      } else {
         return Color.WHITE;
      }
   }

   private Color animatedGradient() {
      return interpolate(this.e.a(), this.f.a(), sineProgress(4000));
   }

   public static void setStaticColor(Color color) {
      ClientColor byzlib2 = getInstance();
      if (byzlib2 != null && color != null) {
         byzlib2.a.a("Статичный");
         byzlib2.b.setColor(color);
         ClickGuiScreen.updateColors();
      }
   }

   public static Color currentColor() {
      ClientColor byzlib2 = getInstance();
      return byzlib2 != null ? byzlib2.n() : DEFAULT_COLOR;
   }

   public static Color[] presets() {
      return (Color[])PRESET_COLORS.clone();
   }

   private static int lerp(int n, int n2, float f) {
      return (int)(n + (n2 - n) * f);
   }

   public int getRgb() {
      return this.o();
   }

   public ClientColor() {
      INSTANCE = this;
   }

   public Color n() {
      String string = this.a.d();
      if ("Статичный".equals(string)) {
         return this.b.a();
      } else if ("Градиент".equals(string)) {
         return this.animatedGradient();
      } else if ("Астольфо".equals(string)) {
         return cycleColors(ASTOLFO_COLORS, 6000);
      } else {
         return "Радуга".equals(string) ? Color.getHSBColor(linearProgress(6000), 1.0F, 1.0F) : this.b.a();
      }
   }

   public static ClientColor getInstance() {
      return INSTANCE;
   }

   public int o() {
      return this.n().getRGB();
   }
}
