package haron.markers;

import java.awt.Color;
import java.util.Map;
import java.util.Set;

public interface EventMarkerProvider {
   default Map<String, MarkerStyle> styles() {
      return this.b();
   }

   default void tick(AutoEventMarkerTracker g2mprb2) {
      int n = 344;
      this.a(g2mprb2);
   }

   default boolean handleMessage(String string, String string2, AutoEventMarkerTracker g2mprb2) {
      return this.a(string, string2, g2mprb2);
   }

   default boolean supportsServer(String string) {
      return this.a(string);
   }

   default Set<String> eventNames() {
      return this.a();
   }

   Map<String, MarkerStyle> b();

   String c();

   default MarkerStyle d() {
      return new MarkerStyle(new Color(255, 165, 0));
   }

   default void a(AutoEventMarkerTracker g2mprb2) {
   }

   boolean a(String var1);

   boolean a(String var1, String var2, AutoEventMarkerTracker var3);

   Set<String> a();

   default String command() {
      return this.c();
   }
}
