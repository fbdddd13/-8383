package haron.markers;

public enum MarkerIcon {
   HOME("home", "\ue90f"),
   REPAIR("repair", "\ue91f"),
   FAST("fast", "\ue90b"),
   SHIELD("shield", "\ue923"),
   DEATH("death", "\ue907"),
   DIAMOND("diamond", "\ue908"),
   LOCKED("locked", "\ue914"),
   MOUNTAIN("mountain", "\ue917"),
   CALENDAR("calendar", "\ue90a"),
   EVENT("calendar", "\ue90a");

   private final String id;
   private final String glyph;

   MarkerIcon(String string2, String string3) {
      this.id = string2;
      this.glyph = string3;
   }

   public String b() {
      return this.glyph;
   }

   public String a() {
      return this.id;
   }
}
