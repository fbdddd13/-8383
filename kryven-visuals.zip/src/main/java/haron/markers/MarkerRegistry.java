package haron.markers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class MarkerRegistry {
   private static final List<Waypoint> MARKERS = Collections.synchronizedList(new ArrayList<>());

   private MarkerRegistry() {
   }

   public static void e() {
      int n = 654;
      MARKERS.removeIf(yo0tnu2 -> yo0tnu2.o());
   }

   public static void b() {
      MARKERS.clear();
   }

   public static void b(Waypoint yo0tnu2) {
      int n = 536;
      MARKERS.remove(yo0tnu2);
   }

   public static void c() {
      MARKERS.clear();
   }

   public static List<Waypoint> f() {
      int n = 500;
      return a();
   }

   public static boolean d() {
      int n = 568;
      return MARKERS.isEmpty();
   }

   public static List<Waypoint> a() {
      synchronized (MARKERS) {
         return new ArrayList<>(MARKERS);
      }
   }

   public static void a(Waypoint yo0tnu2) {
      if (yo0tnu2 != null) {
         MARKERS.add(yo0tnu2);
      }
   }

   public static Waypoint a(int n, int n2, int n3) {
      synchronized (MARKERS) {
         for (Waypoint yo0tnu2 : MARKERS) {
            if (yo0tnu2.b() == n && yo0tnu2.c() == n2 && yo0tnu2.d() == n3) {
               return yo0tnu2;
            }
         }

         return null;
      }
   }

   public static List<Waypoint> g() {
      return a();
   }
}
