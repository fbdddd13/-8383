package haron.entity;

import java.util.Iterator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;

public final class EntityInterpolation {
   public static int a;
   public static boolean b;

   public static Vec3d interpolatedPosition(Entity entity, float tickDelta) {
      return b(entity, tickDelta);
   }

   private EntityInterpolation() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static Vec3d b(Entity entity, float f) {
      return a(entity, f);
   }

   public static Vec3d a(Entity entity, float f) {
      Vec3d vec3d = a(entity);
      return vec3d.add(entity.getPos().subtract(vec3d).multiply(f));
   }

   public static Vec3d a(Entity entity) {
      return new Vec3d(entity.prevX, entity.prevY, entity.prevZ);
   }

   public static boolean a(LivingEntity livingEntity) {
      if (!(livingEntity instanceof PlayerEntity playerEntity)) {
         return false;
      } else {
         if (!playerEntity.isInvisible()) {
            return false;
         }

         Iterator iterator = playerEntity.getArmorItems().iterator();

         while (iterator.hasNext()) {
            if (!((ItemStack)iterator.next()).isEmpty()) {
               return false;
            }
         }

         return true;
      }
   }
}
