package haron.animation;

@FunctionalInterface
public interface EasingFunction {
   double ease(double var1);
}
