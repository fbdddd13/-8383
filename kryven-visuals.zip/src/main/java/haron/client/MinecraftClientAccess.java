package haron.client;

import net.minecraft.client.util.Window;
import net.minecraft.client.MinecraftClient;

public interface MinecraftClientAccess {
   MinecraftClient CLIENT = MinecraftClient.getInstance();
   Window WINDOW = CLIENT.getWindow();
   MinecraftClient c = CLIENT;
   Window d = WINDOW;
}
