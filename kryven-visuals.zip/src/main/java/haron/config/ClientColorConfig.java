package haron.config;

public class ClientColorConfig {
   private String c = "Статичный";
   private float d = 0.75F;
   private float e = 0.81F;
   private float f = 0.89F;
   private float g = 0.0F;
   private float h = 0.0F;
   private float i = 1.0F;
   private float j = 0.58F;
   private float k = 0.51F;
   private float l = 0.96F;
   public static int a;
   public static boolean b;

   public float e() {
      return this.g;
   }

   public void e(float f) {
      this.h = f;
   }

   public float i() {
      return this.k;
   }

   public void i(float f) {
      this.l = f;
   }

   public float b() {
      int n = 578;
      return this.d;
   }

   public void b(float f) {
      this.e = f;
   }

   public void c(float f) {
      this.f = f;
   }

   public float c() {
      return this.e;
   }

   public float h() {
      return this.j;
   }

   public void h(float f) {
      this.k = f;
   }

   public float f() {
      return this.h;
   }

   public void f(float f) {
      this.i = f;
   }

   public float d() {
      return this.f;
   }

   public void d(float f) {
      this.g = f;
   }

   public String a() {
      return this.c;
   }

   public void a(float f) {
      this.d = f;
   }

   public void a(String string) {
      this.c = string;
   }

   public float g() {
      return this.i;
   }

   public void g(float f) {
      this.j = f;
   }

   public float j() {
      return this.l;
   }
}
