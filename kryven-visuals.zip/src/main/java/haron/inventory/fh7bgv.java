package haron.inventory;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.item.Item;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;

public class fh7bgv {
   private static Field d;
   private static Field e;
   private static Field f;
   private static Field g;
   private static Method mStart;
   private static Method mEnd;
   public static int b;
   public static boolean c;
   private static final Item[] WATCHED_ITEMS = new Item[]{
      Items.CHORUS_FRUIT,
      Items.POPPED_CHORUS_FRUIT,
      Items.ENDER_PEARL,
      Items.SHIELD,
      Items.CROSSBOW,
      Items.GOLDEN_APPLE,
      Items.ENCHANTED_GOLDEN_APPLE,
      Items.TOTEM_OF_UNDYING,
      Items.TRIDENT,
      Items.BOW,
      Items.WIND_CHARGE
   };
   public static final nzsxbq a = new nzsxbq(0, 0, 0);

   private static int readEnd(Object object) throws ReflectiveOperationException {
      return (Integer)mEnd.invoke(object);
   }

   public static ItemStack stackForGroup(ItemCooldownManager itemCooldownManager, Identifier identifier) {
      Item item = (Item)Registries.ITEM.get(identifier);
      if (item != Items.AIR) {
         return item.getDefaultStack();
      }

      for (Item item2 : WATCHED_ITEMS) {
         ItemStack itemStack = item2.getDefaultStack();
         if (identifier.equals(itemCooldownManager.getGroup(itemStack))) {
            return itemStack;
         }
      }

      return new ItemStack(Items.PAPER);
   }

   public static nzsxbq viaPublicApi(ItemCooldownManager itemCooldownManager, Item item) {
      try {
         ItemStack itemStack = item.getDefaultStack();
         if (!itemCooldownManager.isCoolingDown(itemStack)) {
            return a;
         }

         float f = itemCooldownManager.getCooldownProgress(itemStack, 0.0F);
         if (f <= 0.0F) {
            return a;
         }

         float f2 = itemCooldownManager.getCooldownProgress(itemStack, 1.0F);
         float f3 = f - f2;
         float f4 = f3 > 1.0E-4F ? 1.0F / f3 : 40.0F;
         float f5 = f * f4;
         float f6 = f5 / 20.0F;
         return new nvlzvr(f, f6);
      } catch (Throwable throwable) {
         return a;
      }
   }

   private static boolean reflectionFailed() {
      return false;
   }

   private static Map<Object, Object> readEntries(ItemCooldownManager itemCooldownManager) throws IllegalAccessException {
      return (Map<Object, Object>)e.get(itemCooldownManager);
   }

   private static int readTick(ItemCooldownManager itemCooldownManager) throws IllegalAccessException {
      return d.getInt(itemCooldownManager);
   }

   private static int readStart(Object object) throws ReflectiveOperationException {
      return (Integer)mStart.invoke(object);
   }

   public static List<welt51> collectActiveGroups(ItemCooldownManager itemCooldownManager) {
      ArrayList<welt51> arrayList = new ArrayList<>();

      try {
         int n = readTick(itemCooldownManager);
         Map<Object, Object> map = readEntries(itemCooldownManager);
         if (map == null) {
            return arrayList;
         }

         for (Map.Entry<Object, Object> entry : map.entrySet()) {
            Object object = entry.getKey();
            int n2;
            if (object instanceof Identifier && (n2 = readEnd(entry.getValue())) > n) {
               arrayList.add(new welt51((Identifier)object, n2 - n));
            }
         }
      } catch (Throwable var8) {
      }

      return arrayList;
   }

   public static nzsxbq a(ItemCooldownManager itemCooldownManager, Item item) {
      return reflectionFailed() ? viaPublicApi(itemCooldownManager, item) : a(itemCooldownManager, itemCooldownManager.getGroup(item.getDefaultStack()));
   }

   private static Field a(Class<?> clazz, String... stringArray) {
      for (String string : stringArray) {
         try {
            Field field = clazz.getDeclaredField(string);
            field.setAccessible(true);
            return field;
         } catch (NoSuchFieldException var7) {
         }
      }

      return null;
   }

   private static Class<?> a() {
      try {
         return Class.forName("net.minecraft.entity.player.ItemCooldownManager$Entry");
      } catch (ClassNotFoundException classNotFoundException) {
         try {
            return Class.forName("net.minecraft.ItemCooldownManager$ItemCooldownManager$Entry");
         } catch (ClassNotFoundException classNotFoundException2) {
            return null;
         }
      }
   }

   public static nzsxbq a(ItemCooldownManager itemCooldownManager, Identifier identifier) {
      try {
         Map<Object, Object> map = readEntries(itemCooldownManager);
         if (map == null) {
            return a;
         }

         Object object = map.get(identifier);
         return object == null ? a : new nzsxbq(readTick(itemCooldownManager), readStart(object), readEnd(object));
      } catch (Throwable throwable) {
         return a;
      }
   }

   static {
      try {
         d = a(ItemCooldownManager.class, "tick", "entries");
         e = a(ItemCooldownManager.class, "entries", "cooldowns", "TILLING_ACTIONS");
         Class<?> clazz = null;

         for (Class<?> clazz2 : ItemCooldownManager.class.getDeclaredClasses()) {
            if (clazz2.getSimpleName().equals("Entry") || clazz2.isRecord()) {
               clazz = clazz2;
               break;
            }
         }

         if (clazz == null) {
            clazz = a();
         }

         if (clazz != null) {
            for (String string : new String[]{"startTick", "startTime", "minInclusive", "translationKey"}) {
               try {
                  Method method = clazz.getDeclaredMethod(string);
                  if (method.getReturnType() == int.class) {
                     method.setAccessible(true);
                     mStart = method;
                     break;
                  }
               } catch (NoSuchMethodException var8) {
               }
            }

            for (String string : new String[]{"endTick", "endTime", "maxInclusive", "useBlockPrefixedTranslationKey"}) {
               try {
                  Method method = clazz.getDeclaredMethod(string);
                  if (method.getReturnType() == int.class) {
                     method.setAccessible(true);
                     mEnd = method;
                     break;
                  }
               } catch (NoSuchMethodException var7) {
               }
            }

            f = a(clazz, "startTick", "startTime");
            g = a(clazz, "endTick", "endTime");
         }
      } catch (Exception var9) {
      }
   }
}
