package haron.inventory;

import haron.client.MinecraftClientAccess;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;

public final class rk1ts2 implements MinecraftClientAccess {
   public static int a;
   public static boolean b;

   private rk1ts2() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static Optional<Integer> a(Predicate<ItemStack> predicate, boolean bl, boolean bl2) {
      PlayerInventory playerInventory = c.player.getInventory();
      int n = !bl ? 9 : 36;

      for (int i = 0; i < n; i++) {
         if (predicate.test(playerInventory.getStack(i))) {
            if (bl && !bl2) {
               int n2;
               if (i >= 9) {
                  n2 = i;
               } else {
                  int n3 = i;
                  n2 = (n3 ^ 36) + 2 * (n3 & 36);
               }

               return Optional.of(n2);
            }

            return Optional.of(i);
         }
      }

      return Optional.empty();
   }
}
