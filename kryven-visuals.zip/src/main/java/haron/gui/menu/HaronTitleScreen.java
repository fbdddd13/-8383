package haron.gui.menu;

import haron.client.MinecraftClientAccess;
import haron.modules.hud.ClientColor;
import haron.render.ScaledGuiProjection;
import haron.render.ScreenPoint;
import haron.render.ShapeRenderer;
import haron.render.font.ClientFonts;
import haron.render.font.FontRenderer;
import haron.render.icons.HaronIcons;
import haron.theme.pryrvd;
import java.awt.Color;
import net.minecraft.util.Util;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.haron.Kryven;

public class HaronTitleScreen extends Screen {
   private static final Logger LOGGER = LoggerFactory.getLogger(HaronTitleScreen.class);
   private static final Identifier MENU_BG = Identifier.of("haron", "textures/menu.png");
   private static final Identifier BLOOM_TEX = Identifier.of("haron", "textures/bloom.png");
   private static final float LOGO_SIZE = 72.0F;
   private static final float BTN_W = 165.0F;
   private static final float BTN_H = 28.0F;
   private static final float BTN_GAP = 6.0F;
   private static final float BTN_RADIUS = 14.0F;
   private static final float SOC_SIZE = 26.0F;
   private static final float SOC_GAP = 8.0F;
   private static final float SOC_RADIUS = 8.0F;
   private static final float EXIT_W = 150.0F;
   private static final float EXIT_H = 32.0F;
   private static final float EXIT_SLIDER_SIZE = 26.0F;
   private float exitProgress = 0.0F;
   private boolean isDraggingExit = false;
   private final Color TEXT_WHITE = new Color(245, 245, 245);
   private final Color TEXT_IDLE = new Color(210, 205, 200);
   private final Color TEXT_MUTED = new Color(130, 120, 115);
   private final Color TEXT_DARK = new Color(20, 15, 12);
   private static final String[] MENU_BUTTONS = new String[]{"Singleplayer", "Multiplayer", "Accounts", "Options"};

   private float getCenterY() {
      return this.screenH() / 2.0F - 40.0F;
   }

   private Color getBtnHoverBg() {
      Color color = this.getAccent();
      return new Color(color.getRed() / 6, color.getGreen() / 6, color.getBlue() / 6, 230);
   }

   private Color getBtnIdleBg() {
      Color color = this.getAccent();
      return new Color(color.getRed() / 10, color.getGreen() / 10, color.getBlue() / 10, 210);
   }

   private Color getBtnIdleBorder() {
      Color color = this.getAccent();
      return new Color(color.getRed() / 5, color.getGreen() / 5, color.getBlue() / 5, 200);
   }

   private void drawExitIcon(ShapeRenderer s7swsm2, MatrixStack matrixStack, float f, float f2, Color color) {
      s7swsm2.a(f - 3.0F, f2 - 4.0F, 5.0F, 8.0F, 1.2F, color, color, color, color, matrixStack);
      s7swsm2.a(f + 1.0F, f2 - 1.0F, 3.0F, 2.0F, 0.5F, color, color, color, color, matrixStack);
   }

   private void drawDiscordIcon(ShapeRenderer s7swsm2, MatrixStack matrixStack, float f, float f2, Color color) {
      s7swsm2.a(f - 4.0F, f2 - 2.5F, 8.0F, 5.0F, 2.0F, color, color, color, color, matrixStack);
      s7swsm2.a(f - 2.5F, f2 + 1.5F, 2.0F, 1.5F, 0.5F, color, color, color, color, matrixStack);
      s7swsm2.a(f + 0.5F, f2 + 1.5F, 2.0F, 1.5F, 0.5F, color, color, color, color, matrixStack);
   }

   private void drawTelegramIcon(ShapeRenderer s7swsm2, MatrixStack matrixStack, float f, float f2, Color color, Color color2) {
      s7swsm2.a(f - 3.5F, f2 - 3.0F, 7.0F, 6.0F, 1.0F, color, color, color, color, matrixStack);
      s7swsm2.a(f - 1.5F, f2 - 1.0F, 3.0F, 3.0F, 0.5F, color2, color2, color2, color2, matrixStack);
   }

   private void drawButtonIcon(int n, ShapeRenderer s7swsm2, MatrixStack matrixStack, float f, float f2, Color color) {
      switch (n) {
         case 0:
            s7swsm2.a(f - 1.5F, f2 - 4.0F, 3.0F, 3.0F, 1.5F, color, color, color, color, matrixStack);
            s7swsm2.a(f - 3.0F, f2 + 0.0F, 6.0F, 4.0F, 1.5F, color, color, color, color, matrixStack);
            break;
         case 1:
            s7swsm2.a(f - 4.0F, f2 - 3.0F, 2.5F, 2.5F, 1.2F, color, color, color, color, matrixStack);
            s7swsm2.a(f - 5.5F, f2 + 0.5F, 5.0F, 3.5F, 1.2F, color, color, color, color, matrixStack);
            s7swsm2.a(f + 1.5F, f2 - 3.0F, 2.5F, 2.5F, 1.2F, color, color, color, color, matrixStack);
            s7swsm2.a(f + 0.0F, f2 + 0.5F, 5.0F, 3.5F, 1.2F, color, color, color, color, matrixStack);
            break;
         case 2:
            s7swsm2.a(f - 3.0F, f2 - 3.0F, 2.0F, 2.0F, 0.8F, color, color, color, color, matrixStack);
            s7swsm2.a(f + 1.0F, f2 - 3.0F, 2.0F, 2.0F, 0.8F, color, color, color, color, matrixStack);
            s7swsm2.a(f - 3.0F, f2 + 1.0F, 2.0F, 2.0F, 0.8F, color, color, color, color, matrixStack);
            s7swsm2.a(f + 1.0F, f2 + 1.0F, 2.0F, 2.0F, 0.8F, color, color, color, color, matrixStack);
            break;
         case 3:
            s7swsm2.a(f - 3.5F, f2 - 3.5F, 7.0F, 7.0F, 3.5F, color, color, color, color, matrixStack);
      }
   }

   public void removed() {
      int n = 890;
      this.isDraggingExit = false;
      super.removed();
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      if (button == 0) {
         this.isDraggingExit = false;
      }

      return super.mouseReleased(mouseX, mouseY, button);
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (button == 0 && this.isDraggingExit) {
         try {
            ScreenPoint screenPoint = ScaledGuiProjection.a(mouseX, mouseY);
            int n = screenPoint.x();
            float f = this.screenW();
            float f2 = this.screenH();
            float f3 = (f - 150.0F) / 2.0F;
            float f4 = 118.0F;
            float f5 = n - (f3 + 3.0F + 13.0F);
            this.exitProgress = Math.max(0.0F, Math.min(1.0F, f5 / 118.0F));
            if (this.exitProgress >= 0.95F && this.client != null) {
               this.client.scheduleStop();
            }

            return true;
         } catch (Throwable var17) {
         }
      }

      return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button != 0) {
         return false;
      }

      try {
         ScreenPoint screenPoint = ScaledGuiProjection.a(mouseX, mouseY);
         int n = screenPoint.x();
         int n2 = screenPoint.y();
         float f3 = this.screenW();
         float f4 = this.screenH();
         float f5 = this.getCenterY();
         float f6 = f5 - 140.0F + 72.0F + 44.0F + 16.0F;

         for (int i = 0; i < MENU_BUTTONS.length; i++) {
            float f2 = (f3 - 165.0F) / 2.0F;
            float f = f6 + i * 34.0F;
            if (n >= f2 && n <= f2 + 165.0F && n2 >= f && n2 <= f + 28.0F) {
               this.onButton(i);
               return true;
            }
         }

         float f7 = f6 + MENU_BUTTONS.length * 34.0F + 6.0F;
         float f2 = 60.0F;
         float f = (f3 - 60.0F) / 2.0F;
         if (n >= f && n <= f + 26.0F && n2 >= f7 && n2 <= f7 + 26.0F) {
            Util.getOperatingSystem().open("leak by somik");
            return true;
         }

         float f8 = f + 26.0F + 8.0F;
         if (n >= f8 && n <= f8 + 26.0F && n2 >= f7 && n2 <= f7 + 26.0F) {
            return true;
         }

         float f9 = (f3 - 150.0F) / 2.0F;
         float f10 = f4 - 32.0F - 18.0F;
         if (n >= f9 && n <= f9 + 150.0F && n2 >= f10 && n2 <= f10 + 32.0F) {
            this.isDraggingExit = true;
            return true;
         }
      } catch (Throwable var19) {
      }

      return super.mouseClicked(mouseX, mouseY, button);
   }

   public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
   }

   private float screenW() {
      int n = 839;
      return MinecraftClientAccess.d.getWidth() / 2.0F;
   }

   private float screenH() {
      return MinecraftClientAccess.d.getHeight() / 2.0F;
   }

   private Color getAccent() {
      return pryrvd.ACCENT;
   }

   private void onButton(int n) {
      if (this.client != null) {
         try {
            switch (n) {
               case 0:
                  this.client.setScreen(new SelectWorldScreen(this));
                  break;
               case 1:
                  this.client.setScreen(new MultiplayerScreen(this));
                  break;
               case 2:
                  this.client.setScreen(new AltManagerScreen(this));
                  break;
               case 3:
                  this.client.setScreen(new OptionsScreen(this, this.client.options));
            }
         } catch (Throwable var3) {
         }
      }
   }

   private void doRender(DrawContext drawContext, int n, int n2, float f) {
      MatrixStack matrixStack = drawContext.getMatrices();
      ShapeRenderer s7swsm2 = Kryven.getInstance().getRender();
      if (s7swsm2 == null) {
         super.render(drawContext, n, n2, f);
      } else {
         ScaledGuiProjection.a(2.0);
         ScreenPoint screenPoint = ScaledGuiProjection.a(n, n2);
         int n3 = screenPoint.x();
         int n4 = screenPoint.y();
         float f4 = this.screenW();
         float f5 = this.screenH();
         float f6 = this.getCenterY();
         Color color3 = ClientColor.currentColor();
         s7swsm2.a(MENU_BG, 0.0F, 0.0F, f4, f5, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, color3 != null ? color3 : new Color(255, 255, 255, 255), matrixStack);
         float f7 = (f4 - 72.0F) / 2.0F;
         float f8 = f6 - 140.0F;
         float f9 = 158.40001F;
         float f10 = f7 - 43.200005F;
         float f11 = f8 - 43.200005F;
         s7swsm2.a(BLOOM_TEX, f10, f11, 158.40001F, 158.40001F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, pryrvd.a(pryrvd.ACCENT, 180), matrixStack);
         Identifier identifier = HaronIcons.get("logo_menu");
         if (identifier != null) {
            Object object = ClientColor.currentColor();
            s7swsm2.a(
               identifier,
               f7,
               f8,
               72.0F,
               72.0F,
               8.639999F,
               0.0F,
               0.0F,
               1.0F,
               1.0F,
               (Color)(object != null ? object : new Color(255, 255, 255, 255)),
               matrixStack
            );
         }

         Object object = ClientFonts.b[14];
         FontRenderer v6hnga2 = ClientFonts.a[10];
         String string2 = "KryvenVisuals";
         float f13 = ((FontRenderer)object).a(string2);
         float f15 = (f4 - f13) / 2.0F;
         float f16 = f8 + 72.0F + 6.0F;
         ((FontRenderer)object).a(string2, f15, f16, pryrvd.ACCENT, matrixStack);
         String string3 = "1.21.4";
         v6hnga2.a(string3, (f4 - v6hnga2.a(string3)) / 2.0F, f16 + 13.0F, this.TEXT_MUTED, matrixStack);
         FontRenderer v6hnga3 = ClientFonts.a[12];
         String string4 = this.client != null && this.client.getSession() != null ? this.client.getSession().getUsername() : "User";
         String string5 = "Welcome back, ";
         float f17 = v6hnga3.a(string5);
         float f18 = v6hnga3.a(string4);
         float f19 = (f4 - (f17 + f18)) / 2.0F;
         float f20 = f16 + 38.0F;
         v6hnga3.a(string5, f19, f20, this.TEXT_WHITE, matrixStack);
         v6hnga3.a(string4, f19 + f17 + 0.5F, f20, new Color(255, 255, 255, 100), matrixStack);
         v6hnga3.a(string4, f19 + f17, f20, pryrvd.ACCENT, matrixStack);
         float f21 = f20 + 16.0F;
         FontRenderer v6hnga4 = ClientFonts.b[12];

         for (int i = 0; i < MENU_BUTTONS.length; i++) {
            float f3 = (f4 - 165.0F) / 2.0F;
            float f2 = f21 + i * 34.0F;
            boolean bl = n3 >= f3 && n3 <= f3 + 165.0F && n4 >= f2 && n4 <= f2 + 28.0F;
            Color color2 = bl ? this.getBtnHoverBg() : this.getBtnIdleBg();
            Color color = bl ? this.TEXT_WHITE : this.TEXT_IDLE;
            Color color4 = bl ? pryrvd.ACCENT : this.TEXT_MUTED;
            s7swsm2.a(
               f3 - 0.8F,
               f2 - 0.8F,
               166.6F,
               29.6F,
               14.8F,
               this.getBtnIdleBorder(),
               this.getBtnIdleBorder(),
               this.getBtnIdleBorder(),
               this.getBtnIdleBorder(),
               matrixStack
            );
            s7swsm2.a(f3, f2, 165.0F, 28.0F, 14.0F, color2, color2, color2, color2, matrixStack);
            this.drawButtonIcon(i, s7swsm2, matrixStack, f3 + 12.0F, f2 + 14.0F, color4);
            String string6 = MENU_BUTTONS[i];
            float f22 = f3 + (165.0F - v6hnga4.a(string6)) / 2.0F;
            float f23 = f2 + (28.0F - v6hnga4.b(string6)) / 2.0F + 1.0F;
            v6hnga4.a(string6, f22, f23, color, matrixStack);
         }

         float f24 = f21 + MENU_BUTTONS.length * 34.0F + 6.0F;
         float f3 = 60.0F;
         float f2 = (f4 - 60.0F) / 2.0F;
         boolean bl = n3 >= f2 && n3 <= f2 + 26.0F && n4 >= f24 && n4 <= f24 + 26.0F;
         Color color2 = bl ? this.getBtnHoverBg() : this.getBtnIdleBg();
         Color color = bl ? pryrvd.ACCENT : this.TEXT_MUTED;
         s7swsm2.a(
            f2 - 0.8F,
            f24 - 0.8F,
            27.6F,
            27.6F,
            8.8F,
            this.getBtnIdleBorder(),
            this.getBtnIdleBorder(),
            this.getBtnIdleBorder(),
            this.getBtnIdleBorder(),
            matrixStack
         );
         s7swsm2.a(f2, f24, 26.0F, 26.0F, 8.0F, color2, color2, color2, color2, matrixStack);
         this.drawTelegramIcon(s7swsm2, matrixStack, f2 + 13.0F, f24 + 13.0F, color, color2);
         float f25 = f2 + 26.0F + 8.0F;
         boolean bl2 = n3 >= f25 && n3 <= f25 + 26.0F && n4 >= f24 && n4 <= f24 + 26.0F;
         Color color5 = bl2 ? this.getBtnHoverBg() : this.getBtnIdleBg();
         Color color6 = bl2 ? pryrvd.ACCENT : this.TEXT_MUTED;
         s7swsm2.a(
            f25 - 0.8F,
            f24 - 0.8F,
            27.6F,
            27.6F,
            8.8F,
            this.getBtnIdleBorder(),
            this.getBtnIdleBorder(),
            this.getBtnIdleBorder(),
            this.getBtnIdleBorder(),
            matrixStack
         );
         s7swsm2.a(f25, f24, 26.0F, 26.0F, 8.0F, color5, color5, color5, color5, matrixStack);
         this.drawDiscordIcon(s7swsm2, matrixStack, f25 + 13.0F, f24 + 13.0F, color6);
         float f26 = (f4 - 150.0F) / 2.0F;
         float f27 = f5 - 32.0F - 18.0F;
         s7swsm2.a(
            f26 - 0.8F,
            f27 - 0.8F,
            151.6F,
            33.6F,
            16.8F,
            this.getBtnIdleBorder(),
            this.getBtnIdleBorder(),
            this.getBtnIdleBorder(),
            this.getBtnIdleBorder(),
            matrixStack
         );
         s7swsm2.a(f26, f27, 150.0F, 32.0F, 16.0F, this.getBtnIdleBg(), this.getBtnIdleBg(), this.getBtnIdleBg(), this.getBtnIdleBg(), matrixStack);
         FontRenderer v6hnga5 = ClientFonts.a[11];
         String string7 = "Slide to exit";
         v6hnga5.a(string7, f26 + 50.0F, f27 + (32.0F - v6hnga5.b(string7)) / 2.0F + 1.0F, this.TEXT_MUTED, matrixStack);
         float f28 = 118.0F;
         float f29 = f26 + 3.0F + this.exitProgress * 118.0F;
         float f30 = f27 + 3.0F;
         s7swsm2.a(f29, f30, 26.0F, 26.0F, 13.0F, pryrvd.ACCENT, pryrvd.ACCENT, pryrvd.ACCENT, pryrvd.ACCENT, matrixStack);
         this.drawExitIcon(s7swsm2, matrixStack, f29 + 13.0F, f30 + 13.0F, this.TEXT_DARK);
         if (!this.isDraggingExit && this.exitProgress > 0.0F) {
            this.exitProgress = Math.max(0.0F, this.exitProgress - f * 0.15F);
         }

         ScaledGuiProjection.a();
      }
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }

   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      try {
         this.doRender(context, mouseX, mouseY, delta);
      } catch (Throwable throwable) {
         try {
            super.render(context, mouseX, mouseY, delta);
         } catch (Throwable var7) {
         }
      }
   }

   public HaronTitleScreen() {
      super(Text.literal("KryvenVisuals"));
   }
}
