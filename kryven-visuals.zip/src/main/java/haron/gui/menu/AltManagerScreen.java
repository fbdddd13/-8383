package haron.gui.menu;

import haron.client.MinecraftClientAccess;
import haron.modules.hud.ClientColor;
import haron.render.ScaledGuiProjection;
import haron.render.ScreenPoint;
import haron.render.ShapeRenderer;
import haron.render.font.ClientFonts;
import haron.render.font.FontRenderer;
import haron.theme.pryrvd;
import java.awt.Color;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.session.Session;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import ru.haron.Kryven;
import ru.haron.mixin.accessor.MinecraftClientAccessor;

public class AltManagerScreen extends Screen {
   private static final Identifier MENU_BG = Identifier.of("haron", "textures/menu.png");
   private static final float CARD_W = 128.0F;
   private static final float CARD_H = 26.0F;
   private static final float CARD_GAP = 8.0F;
   private static final float CARD_RADIUS = 8.0F;
   private static final float HEAD_SIZE = 16.0F;
   private static final int COLUMNS = 2;
   private static final int MAX_ROWS = 6;
   private static final float BOX_PAD = 12.0F;
   private static final float BOX_RADIUS = 12.0F;
   private static final float PANEL_W = 132.0F;
   private static final float INPUT_H = 18.0F;
   private static final float BTN_H = 17.0F;
   private static final float PANEL_PAD = 7.0F;
   private static final int MAX_NICK_LEN = 16;
   private final Screen parent;
   private final List<String> alts = new ArrayList<>();
   private String input = "";
   private boolean inputFocused = false;
   private int scroll = 0;
   private final Color TEXT_WHITE = new Color(245, 245, 245);
   private final Color TEXT_MUTED = new Color(130, 120, 115);
   private final Color TRASH_RED = new Color(205, 60, 60, 255);

   private String currentName() {
      try {
         return ((MinecraftClientAccessor)(Object)this.client).getSession().getUsername();
      } catch (Throwable throwable) {
         return "Player";
      }
   }

   private Color getBtnHoverBg() {
      Color color = pryrvd.ACCENT;
      return new Color(color.getRed() / 6, color.getGreen() / 6, color.getBlue() / 6, 230);
   }

   private void addCurrentInput() {
      String string = this.input.trim();
      if (string.length() >= 3 && string.length() <= 16 && !this.alts.contains(string)) {
         this.alts.add(string);
         this.save();
         this.input = "";
      }
   }

   private void addRandomAlt() {
      int n = 0;

      String string;
      while (this.alts.contains(string = this.generateRandomNick())) {
         if (++n >= 100) {
            break;
         }
      }

      if (!this.alts.contains(string)) {
         this.alts.add(string);
         this.save();
      }
   }

   private Color getBtnIdleBg() {
      Color color = pryrvd.ACCENT;
      return new Color(color.getRed() / 10, color.getGreen() / 10, color.getBlue() / 10, 210);
   }

   private Color getBtnIdleBorder() {
      Color color = pryrvd.ACCENT;
      return new Color(color.getRed() / 5, color.getGreen() / 5, color.getBlue() / 5, 200);
   }

   private float totalContentH() {
      return this.boxH() + 8.0F + this.panelH();
   }

   private String generateRandomNick() {
      String string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
      int n = 3 + (int)(Math.random() * 14.0);
      StringBuilder stringBuilder = new StringBuilder();

      for (int i = 0; i < n; i++) {
         stringBuilder.append(string.charAt((int)(Math.random() * string.length())));
      }

      return stringBuilder.toString();
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      int n = (this.alts.size() + 2 - 1) / 2;
      if (n > 6) {
         this.scroll = this.scroll - (int)Math.signum(verticalAmount);
         this.scroll = Math.max(0, Math.min(this.scroll, n - 6));
      }

      return true;
   }

   public boolean charTyped(char chr, int modifiers) {
      if (!this.inputFocused) {
         return false;
      } else if ((Character.isLetterOrDigit(chr) || chr == '_') && this.input.length() < 16) {
         this.input = $sf$3(this.input, chr);
         return true;
      } else {
         return false;
      }
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button != 0) {
         return false;
      }

      ScreenPoint screenPoint = ScaledGuiProjection.a(mouseX, mouseY);
      int n = screenPoint.x();
      int n2 = screenPoint.y();
      int n3 = Math.min(this.alts.size() - this.scroll * 2, 12);

      for (int i = 0; i < n3; i++) {
         int n4 = this.scroll * 2 + i;
         int n5 = i % 2;
         int n6 = i / 2;
         float f4 = this.cardX(n5);
         float f3 = this.cardY(n6);
         float f2 = 16.0F;
         float f = f4 + 128.0F - 16.0F - 5.0F;
         float f5 = f3 + 5.0F;
         if (n >= f && n <= f + 16.0F && n2 >= f5 && n2 <= f5 + 16.0F) {
            this.alts.remove(n4);
            this.save();
            if (this.scroll > 0 && this.scroll * 2 >= this.alts.size()) {
               this.scroll--;
            }

            return true;
         }

         if (n >= f4 && n <= f4 + 128.0F && n2 >= f3 && n2 <= f3 + 26.0F) {
            this.loginAs(this.alts.get(n4));
            return true;
         }
      }

      float f6 = this.panelX();
      float f7 = this.panelY();
      float f8 = f7 + 7.0F + 12.0F;
      float f9 = 118.0F;
      this.inputFocused = n >= f6 + 7.0F && n <= f6 + 7.0F + 118.0F && n2 >= f8 && n2 <= f8 + 18.0F;
      float f4 = f8 + 18.0F + 6.0F;
      float f3 = 17.0F;
      float f2 = 96.0F;
      if (n >= f6 + 7.0F && n <= f6 + 7.0F + 96.0F && n2 >= f4 && n2 <= f4 + 17.0F) {
         this.addCurrentInput();
         return true;
      } else {
         float f = f6 + 7.0F + 96.0F + 5.0F;
         if (n >= f && n <= f + 17.0F && n2 >= f4 && n2 <= f4 + 17.0F) {
            this.addRandomAlt();
            return true;
         } else {
            return true;
         }
      }
   }

   public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      if (keyCode == 256) {
         this.client.setScreen(this.parent);
         return true;
      }

      if (this.inputFocused) {
         if (keyCode == 259 && !this.input.isEmpty()) {
            this.input = this.input.substring(0, this.input.length() - 1);
            return true;
         }

         if (keyCode == 257) {
            this.addCurrentInput();
            return true;
         }
      }

      return super.keyPressed(keyCode, scanCode, modifiers);
   }

   private Path altsFile() {
      String string = System.getenv("APPDATA");
      if (string == null) {
         string = System.getProperty("user.home");
      }

      return Paths.get(string, "Kryven", "config", "alts.txt");
   }

   private float cardY(int n) {
      return this.gridY() + 12.0F + n * 34.0F;
   }

   private float gridX() {
      int n = 837;
      return (this.screenW() - this.gridW()) / 2.0F;
   }

   private float boxH() {
      return 220.0F;
   }

   private float screenW() {
      return MinecraftClientAccess.d.getWidth() / 2.0F;
   }

   private float boxX() {
      int n = 437;
      return this.gridX() - 12.0F;
   }

   private float panelX() {
      return (this.screenW() - 132.0F) / 2.0F;
   }

   private float panelY() {
      return this.boxY() + this.boxH() + 8.0F;
   }

   private float screenH() {
      return MinecraftClientAccess.d.getHeight() / 2.0F;
   }

   private float panelH() {
      return 68.0F;
   }

   private float gridY() {
      return (this.screenH() - this.totalContentH()) / 2.0F;
   }

   private float cardX(int n) {
      return this.gridX() + n * 136.0F;
   }

   private Color getAccent() {
      return pryrvd.ACCENT;
   }

   private float gridW() {
      return 264.0F;
   }

   private void loginAs(String string) {
      try {
         UUID uUID = UUID.nameUUIDFromBytes($sf$0(string).getBytes(StandardCharsets.UTF_8));
         Session session = new Session(string, uUID, "0", Optional.empty(), Optional.empty(), Session.AccountType.LEGACY);
         ((MinecraftClientAccessor)(Object)this.client).setSession(session);
      } catch (Throwable throwable) {
         Kryven.getLOGGER().error("[Kryven] login failed", throwable);
      }
   }

   private float boxY() {
      return this.gridY();
   }

   private float boxW() {
      return this.gridW() + 24.0F;
   }

   private void drawTrash(ShapeRenderer s7swsm2, MatrixStack matrixStack, float f, float f2, Color color) {
      float f3 = 6.0F;
      s7swsm2.a(f - 3.0F, f2 - 3.4F, 6.0F, 1.2F, 0.5F, color, color, color, color, matrixStack);
      s7swsm2.a(f - 1.4F, f2 - 4.6F, 2.8F, 1.2F, 0.5F, color, color, color, color, matrixStack);
      s7swsm2.a(f - 2.6F, f2 - 2.0F, 5.2F, 6.0F, 1.0F, color, color, color, color, matrixStack);
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }

   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      MatrixStack matrixStack = context.getMatrices();
      ShapeRenderer s7swsm2 = Kryven.getInstance().getRender();
      ScaledGuiProjection.a(2.0);
      ScreenPoint screenPoint = ScaledGuiProjection.a(mouseX, mouseY);
      int n = screenPoint.x();
      int n2 = screenPoint.y();
      float f3 = this.screenW();
      float f4 = this.screenH();
      Color color = ClientColor.currentColor();
      s7swsm2.a(MENU_BG, 0.0F, 0.0F, f3, f4, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, color != null ? color : new Color(255, 255, 255, 255), matrixStack);
      FontRenderer v6hnga2 = ClientFonts.a[14];
      FontRenderer v6hnga3 = ClientFonts.a[12];
      Identifier identifier = DefaultSkinHelper.getTexture();
      Color color2 = new Color(255, 255, 255, 255);
      s7swsm2.a(
         this.boxX() - 0.8F,
         this.boxY() - 0.8F,
         this.boxW() + 1.6F,
         this.boxH() + 1.6F,
         12.8F,
         this.getBtnIdleBorder(),
         this.getBtnIdleBorder(),
         this.getBtnIdleBorder(),
         this.getBtnIdleBorder(),
         matrixStack
      );
      s7swsm2.a(
         this.boxX(),
         this.boxY(),
         this.boxW(),
         this.boxH(),
         12.0F,
         this.getBtnIdleBg(),
         this.getBtnIdleBg(),
         this.getBtnIdleBg(),
         this.getBtnIdleBg(),
         matrixStack
      );
      int n3 = Math.min(this.alts.size() - this.scroll * 2, 12);

      for (int i = 0; i < n3; i++) {
         int n4 = this.scroll * 2 + i;
         String string = this.alts.get(n4);
         int n5 = i % 2;
         int n6 = i / 2;
         float f2 = this.cardX(n5);
         float f5 = this.cardY(n6);
         boolean bl = n >= f2 && n <= f2 + 128.0F && n2 >= f5 && n2 <= f5 + 26.0F;
         boolean bl2 = string.equals(this.currentName());
         Color color3 = bl2 ? pryrvd.ACCENT : this.getBtnIdleBorder();
         Color color4 = bl ? this.getBtnHoverBg() : this.getBtnIdleBg();
         s7swsm2.a(f2 - 0.8F, f5 - 0.8F, 129.6F, 27.6F, 8.8F, color3, color3, color3, color3, matrixStack);
         s7swsm2.a(f2, f5, 128.0F, 26.0F, 8.0F, color4, color4, color4, color4, matrixStack);
         float f6 = f2 + 5.0F;
         float f7 = f5 + 5.0F;
         s7swsm2.a(identifier, f6, f7, 16.0F, 16.0F, 3.0F, 0.125F, 0.125F, 0.125F, 0.125F, color2, matrixStack);
         s7swsm2.a(identifier, f6, f7, 16.0F, 16.0F, 3.0F, 0.625F, 0.125F, 0.125F, 0.125F, color2, matrixStack);
         v6hnga2.a(string, f6 + 16.0F + 6.0F, f5 + (26.0F - v6hnga2.b(string)) / 2.0F + 1.0F, this.TEXT_WHITE, matrixStack);
         float f = 16.0F;
         float f8 = f2 + 128.0F - 16.0F - 5.0F;
         float f9 = f5 + 5.0F;
         boolean bl3 = n >= f8 && n <= f8 + 16.0F && n2 >= f9 && n2 <= f9 + 16.0F;
         Object object = bl3 ? this.TRASH_RED : this.getBtnIdleBg();
         s7swsm2.a(f8, f9, 16.0F, 16.0F, 5.0F, (Color)object, (Color)object, (Color)object, (Color)object, matrixStack);
         this.drawTrash(s7swsm2, matrixStack, f8 + 8.0F, f9 + 8.0F, bl3 ? color2 : this.TEXT_MUTED);
      }

      if (this.alts.isEmpty()) {
         String string = "Пусто — создай альта ниже";
         v6hnga3.a(string, (f3 - v6hnga3.a(string)) / 2.0F, this.boxY() + this.boxH() / 2.0F - 4.0F, this.TEXT_MUTED, matrixStack);
      }

      float f10 = this.panelX();
      float f11 = this.panelY();
      float f12 = this.panelH();
      s7swsm2.a(
         f10 - 0.8F,
         f11 - 0.8F,
         133.6F,
         f12 + 1.6F,
         9.0F,
         this.getBtnIdleBorder(),
         this.getBtnIdleBorder(),
         this.getBtnIdleBorder(),
         this.getBtnIdleBorder(),
         matrixStack
      );
      s7swsm2.a(f10, f11, 132.0F, f12, 8.0F, this.getBtnIdleBg(), this.getBtnIdleBg(), this.getBtnIdleBg(), this.getBtnIdleBg(), matrixStack);
      float f13 = f11 + 7.0F;
      s7swsm2.a(f10 + 7.0F, f13 + 2.0F, 4.0F, 4.0F, 2.0F, pryrvd.ACCENT, pryrvd.ACCENT, pryrvd.ACCENT, pryrvd.ACCENT, matrixStack);
      v6hnga3.a("AltManager", f10 + 7.0F + 8.0F, f13 - 1.0F, this.TEXT_MUTED, matrixStack);
      float f14 = f13 + 12.0F;
      float f2 = 118.0F;
      s7swsm2.a(f10 + 7.0F, f14, 118.0F, 18.0F, 6.0F, this.getBtnIdleBg(), this.getBtnIdleBg(), this.getBtnIdleBg(), this.getBtnIdleBg(), matrixStack);
      if (this.inputFocused) {
         s7swsm2.a(f10 + 7.0F, f14, 2.0F, 18.0F, 1.0F, pryrvd.ACCENT, pryrvd.ACCENT, pryrvd.ACCENT, pryrvd.ACCENT, matrixStack);
      }

      String string = this.input.isEmpty() && !this.inputFocused ? "Name" : $sf$1(this.input, this.inputFocused ? "_" : "");
      v6hnga2.a(
         string,
         f10 + 7.0F + 6.0F,
         f14 + (18.0F - v6hnga2.b(string)) / 2.0F + 1.0F,
         this.input.isEmpty() && !this.inputFocused ? this.TEXT_MUTED : this.TEXT_WHITE,
         matrixStack
      );
      float f15 = f14 + 18.0F + 6.0F;
      float f16 = 17.0F;
      float f17 = 96.0F;
      boolean bl = n >= f10 + 7.0F && n <= f10 + 7.0F + 96.0F && n2 >= f15 && n2 <= f15 + 17.0F;
      Color color5 = bl ? this.getBtnHoverBg() : this.getBtnIdleBg();
      s7swsm2.a(f10 + 7.0F, f15, 96.0F, 17.0F, 6.0F, color5, color5, color5, color5, matrixStack);
      String string2 = "ShaderProgramBuilder";
      v6hnga2.a(string2, f10 + 7.0F + (96.0F - v6hnga2.a(string2)) / 2.0F, f15 + (17.0F - v6hnga2.b(string2)) / 2.0F + 1.0F, this.TEXT_WHITE, matrixStack);
      float f = f10 + 7.0F + 96.0F + 5.0F;
      boolean bl4 = n >= f && n <= f + 17.0F && n2 >= f15 && n2 <= f15 + 17.0F;
      Color color6 = bl4 ? this.getBtnHoverBg() : this.getBtnIdleBg();
      s7swsm2.a(f, f15, 17.0F, 17.0F, 8.5F, color6, color6, color6, color6, matrixStack);
      String string3 = "?";
      v6hnga2.a(string3, f + (17.0F - v6hnga2.a(string3)) / 2.0F, f15 + (17.0F - v6hnga2.b(string3)) / 2.0F + 1.0F, this.TEXT_WHITE, matrixStack);
      Object object = $sf$2(this.currentName());
      v6hnga3.a((String)object, (f3 - v6hnga3.a((String)object)) / 2.0F, f4 - 16.0F, this.TEXT_MUTED, matrixStack);
      ScaledGuiProjection.a();
   }

   public AltManagerScreen(Screen screen) {
      super(Text.literal("AltManager"));
      this.parent = screen;
      this.load();
   }

   private void load() {
      this.alts.clear();

      try {
         Path path = this.altsFile();
         if (Files.exists(path)) {
            for (String string : Files.readAllLines(path, StandardCharsets.UTF_8)) {
               String string2 = string.trim();
               if (!string2.isEmpty() && !this.alts.contains(string2)) {
                  this.alts.add(string2);
               }
            }
         }
      } catch (IOException var5) {
      }
   }

   private void save() {
      try {
         Path path = this.altsFile();
         Files.createDirectories(path.getParent());
         Files.write(path, String.join("\n", this.alts).getBytes(StandardCharsets.UTF_8));
      } catch (IOException var2) {
      }
   }

   private static String $sf$0(String string) {
      return "OfflinePlayer:" + string;
   }

   private static String $sf$3(String string, char c) {
      return string + c;
   }

   private static String $sf$1(String string, String string2) {
      return string + string2;
   }

   private static String $sf$2(String string) {
      return "Ник: " + string + "  |  ESC — назад";
   }
}
