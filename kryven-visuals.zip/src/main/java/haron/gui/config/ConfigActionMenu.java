package haron.gui.config;

import haron.animation.AnimatedValue;
import haron.animation.Easings;
import haron.config.ConfigProfileEntry;
import haron.core.BooleanCoercion;
import haron.gui.core.GuiInput;
import haron.gui.core.InteractionOverlayController;
import haron.render.ShapeRenderer;
import haron.render.font.ClientFonts;
import haron.render.font.FontRenderer;
import haron.theme.pryrvd;
import haron.util.ColorUtils;
import java.awt.Color;
import java.util.function.Consumer;
import net.minecraft.client.util.math.MatrixStack;

public class ConfigActionMenu {
   private static final float c = 79.0F;
   private static final float d = 12.0F;
   private static final float e = 11.0F;
   private static final float f = 9.5F;
   private static final float g = 7.0F;
   private static final float h = 6.5F;
   private static final float i = 8.0F;
   private static final float j = 4.0F;
   private static final float k = 3.0F;
   private float m;
   private float n;
   private float o;
   private ConfigProfileEntry p;
   private Consumer<ConfigAction> t;
   private Runnable u;
   public static int a;
   public static boolean b;
   private boolean l = false;
   private final AnimatedValue q = new AnimatedValue();
   private final AnimatedValue[] r = new AnimatedValue[4];
   private final boolean[] s = new boolean[4];

   public ConfigActionMenu() {
      for (int i = 0; i < 4; i++) {
         this.r[i] = new AnimatedValue();
         this.s[i] = false;
      }
   }

   private String b(ConfigAction gpg0qq2) {
      return this.p != null && this.p.f() && gpg0qq2 == ConfigAction.SAVE_TO ? "Применить" : gpg0qq2.a();
   }

   public boolean b(int n, int n2) {
      return this.l ? GuiInput.a(this.m, this.n, 79.0F, 69.5F, n, n2) : false;
   }

   public boolean b() {
      return this.l;
   }

   public boolean c() {
      return !this.l || this.q.j() < 0.01;
   }

   public ConfigProfileEntry d() {
      return this.p;
   }

   private void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, float f3, ConfigAction gpg0qq2, Color color) {
      String string;
      switch (gpg0qq2) {
         case SAVE_TO:
            string = "\ue920";
            break;
         case SHARE:
            string = "\ue922";
            break;
         case RENAME:
            string = "\ue909";
            break;
         case DELETE:
            string = "\ue924";
            break;
         default:
            return;
      }

      ClientFonts.e[14].a(string, f, f2, color, matrixStack);
   }

   public boolean a(int n, int n2) {
      if (this.l && !(this.q.j() < 0.5)) {
         if (!GuiInput.a(this.m, this.n, 79.0F, 69.5F, n, n2)) {
            this.a();
            return true;
         }

         float f = this.m + 12.0F;
         float f2 = this.n + 11.0F;
         ConfigAction[] gpg0qqArray = ConfigAction.values();

         for (int i = 0; i < gpg0qqArray.length; i++) {
            if (GuiInput.a(f - 5.0F, f2 + i * 13.5F - 2.0F, 65.0F, 11.0F, n, n2)) {
               if (this.a(gpg0qqArray[i])) {
                  return true;
               }

               if (this.t != null) {
                  this.t.accept(gpg0qqArray[i]);
               }

               this.a();
               return true;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public void a(Consumer<ConfigAction> consumer) {
      this.t = consumer;
   }

   public void a(float f, float f2, float f3, ConfigProfileEntry lhvtx72) {
      this.o = f + f3 / 2.0F;
      this.m = this.o - 39.5F;
      this.n = f2 + 3.0F;
      this.p = lhvtx72;
      this.l = true;
      this.q.d(0.0);
      this.q.a(1.0, 0.25, Easings.F);

      for (int i = 0; i < 4; i++) {
         this.r[i].d(0.0);
         this.s[i] = false;
      }

      InteractionOverlayController.a().d(true);
      GuiInput.a(this.m, this.n, 79.0F, 69.5F);
   }

   public void a(float f, float f2, ConfigProfileEntry lhvtx72) {
      this.a(f, f2, 0.0F, lhvtx72);
   }

   public void a() {
      if (this.l) {
         this.q.a(0.0, 0.15, Easings.g);
         InteractionOverlayController.a().d(false);
         GuiInput.a();
      }
   }

   private boolean a(ConfigAction gpg0qq2) {
      if (this.p == null) {
         return false;
      } else {
         return this.p.f()
            ? BooleanCoercion.from(gpg0qq2 == ConfigAction.SAVE_TO ? 0 : 1)
            : this.p.e() && (gpg0qq2 == ConfigAction.DELETE || gpg0qq2 == ConfigAction.RENAME);
      }
   }

   public void a(Runnable runnable) {
      this.u = runnable;
   }

   public void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, int n, int n2) {
      this.q.a();
      float f = (float)this.q.j();
      if (f < 0.01F) {
         if (this.l && this.q.d()) {
            this.l = false;
            if (this.u != null) {
               this.u.run();
            }
         }
      } else {
         for (int i = 0; i < 4; i++) {
            this.r[i].a();
         }

         float f2 = Math.max(0.0F, Math.min(1.0F, f));
         int n3 = (int)(255.0F * f2);
         float f3 = 79.0F * f2;
         float f4 = 69.5F * f2;
         float f5 = this.m + 39.5F;
         float f6 = this.n + 34.75F;
         float f7 = f5 - f3 / 2.0F;
         float f8 = f6 - f4 / 2.0F;
         Color color = pryrvd.a(pryrvd.q, n3);
         Color color2 = pryrvd.a(pryrvd.r, n3);
         s7swsm2.a(f7 - 0.5F * f2, f8 - 0.5F * f2, f3 + f2, f4 + f2, 9.5F * f2, color, color, color2, color2, matrixStack);
         Color color3 = pryrvd.a(pryrvd.e, n3);
         Color color4 = pryrvd.a(pryrvd.f, n3);
         s7swsm2.a(f7, f8, f3, f4, 9.5F * f2, color3, color3, color4, color4, matrixStack);
         if (f2 > 0.1F) {
            matrixStack.push();
            matrixStack.translate(f5, f6, 0.0F);
            matrixStack.scale(f2, f2, 1.0F);
            matrixStack.translate(-f5, -f6, 0.0F);
            int n4 = (int)(this.m + 12.0F);
            int n5 = (int)(this.n + 11.0F);
            FontRenderer v6hnga2 = ClientFonts.a[12];
            ConfigAction[] gpg0qqArray = ConfigAction.values();

            for (int i = 0; i < gpg0qqArray.length; i++) {
               float f9 = n5 + i * 13.5F;
               boolean bl = this.a(gpg0qqArray[i]);
               int n6 = !bl
                     && !(f2 <= 0.5F)
                     && GuiInput.a(f7 + 12.0F * f2 - 5.0F, f8 + 11.0F * f2 + i * 13.5F * f2 - 2.0F, 55.0F * f2 + 10.0F, 7.0F * f2 + 4.0F, n, n2)
                  ? 1
                  : 0;
               if (BooleanCoercion.from(n6) != this.s[i]) {
                  this.r[i].a(n6 == 0 ? 0.0 : 1.0, 0.15, Easings.h);
                  this.s[i] = BooleanCoercion.from(n6);
               }

               float f10 = (float)this.r[i].j();
               this.a(
                  matrixStack,
                  s7swsm2,
                  v6hnga2,
                  n4,
                  f9,
                  1.0F,
                  gpg0qqArray[i],
                  this.b(gpg0qqArray[i]),
                  pryrvd.a(
                     !bl
                        ? (gpg0qqArray[i] != ConfigAction.DELETE ? ColorUtils.a(pryrvd.a, pryrvd.aa, f10) : ColorUtils.a(pryrvd.Z, pryrvd.b(pryrvd.Z, 30), f10))
                        : pryrvd.b,
                     n3
                  ),
                  n3
               );
               if (n6 != 0) {
                  GuiInput.g();
               }
            }

            matrixStack.pop();
         }
      }
   }

   private void a(
      MatrixStack matrixStack, ShapeRenderer s7swsm2, FontRenderer v6hnga2, float f, float f2, float f3, ConfigAction gpg0qq2, String string, Color color, int n
   ) {
      float f4 = 8.0F * f3;
      float f5 = f + f4 + 4.0F * f3;
      this.a(matrixStack, s7swsm2, f, f2, f4, gpg0qq2, color);
      v6hnga2.a(string, f5, f2, color, matrixStack);
   }
}
