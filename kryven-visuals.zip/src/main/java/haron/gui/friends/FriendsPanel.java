package haron.gui.friends;

import haron.animation.AnimatedValue;
import haron.animation.Easings;
import haron.core.BooleanCoercion;
import haron.gui.core.GuiInput;
import haron.gui.core.ScrollFadeOverlay;
import haron.gui.widgets.ScrollBar;
import haron.gui.widgets.SearchBox;
import haron.gui.widgets.TextInput;
import haron.gui.widgets.TextInputType;
import haron.render.ShapeRenderer;
import haron.render.font.ClientFonts;
import haron.render.font.FontRenderer;
import haron.theme.pryrvd;
import haron.util.ColorUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.client.util.math.MatrixStack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FriendsPanel {
   private static final Logger LOGGER = LoggerFactory.getLogger(FriendsPanel.class);
   private static final float a = 19.5F;
   private static final float b = 98.5F;
   private static final float c = 5.0F;
   private static final float d = 19.5F;
   private static final float e = 6.5F;
   private static final float f = 5.0F;
   private static final float g = 9.5F;
   private static final float h = 6.5F;
   private static final float i = 6.5F;
   private static final float j = 6.5F;
   private static final float k = 1.0F;
   private static final float l = 9.5F;
   private static final float m = 2.0F;
   private static final int n = 2;
   private static final Color o = pryrvd.I;
   private static final Color p = pryrvd.K;
   private static final Color q = pryrvd.O;
   private static final Color INPUT_BG_TOP = pryrvd.CELL_BG_TOP;
   private static final Color INPUT_BG_BOT = pryrvd.CELL_BG_BOT;
   private final TextInput u;
   private final ScrollBar v;
   private final ScrollFadeOverlay w;
   private Consumer<FriendEntry> B;
   private float C;
   private float D;
   private float E;
   private float F;
   private float G;
   private float H;
   private float I;
   private final List<FriendEntry> r = new ArrayList<>();
   private final List<FriendCard> s = new ArrayList<>();
   private final AnimatedValue x = new AnimatedValue();
   private boolean y = false;
   private String z = "";
   private List<FriendCard> A = new ArrayList<>();
   private final SearchBox t = new SearchBox();

   public FriendsPanel() {
      LOGGER.info("FriendsPanel initialized");
      this.t.a(this::a);
      this.u = new TextInput(TextInputType.PLAYER, "Добавить...");
      this.u.a(16);
      this.u.a(9.5F);
      this.u.a(INPUT_BG_TOP, INPUT_BG_BOT);
      this.v = new ScrollBar(2.0F, 20.0F);
      this.v.b(10.0F);
      this.v.a(pryrvd.b);
      this.v.b(pryrvd.d);
      this.w = new ScrollFadeOverlay(25, 5.0F, 9.0F);
      LOGGER.debug("FriendsPanel components initialized: TextInput, ScrollBar, PanelFadeOverlay");
   }

   private void e() {
      if (this.z.isEmpty()) {
         this.A = new ArrayList<>(this.s);
         LOGGER.trace("Search cleared, showing all {} friends", this.s.size());
      } else {
         this.A = this.s.stream().filter(t2tp1d2 -> t2tp1d2.a().a().toLowerCase().contains(this.z)).collect(Collectors.toList());
         LOGGER.trace("Search found {} matching friends for query '{}'", this.A.size(), this.z);
      }
   }

   public void b() {
      LOGGER.info("FriendsPanel refresh requested");
   }

   private void b(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, float f3, float f4, int n, int n2, float f5) {
      if (this.A.isEmpty()) {
         this.a(matrixStack, s7swsm2, f, f2, f3, f4);
      } else {
         float f6 = f + 1.0F;
         float f7 = f2 + 6.5F;
         float f8 = f3 - 2.0F;
         float f9 = f4 - 6.5F - 6.5F;
         float f10 = this.f();
         boolean bl = f10 > f9;
         if (!bl) {
            this.v.e();
         }

         s7swsm2.b().a(f, f2 + 4.0F, f3, f4 - 8.0F, matrixStack);
         float f11 = (f8 - 9.5F) / 2.0F;
         float f12 = f7 - this.v.b();
         int n3 = 0;

         for (FriendCard t2tp1d2 : this.A) {
            float f13 = f6 + n3 % 2 * (f11 + 9.5F);
            float f14 = f12 + n3 / 2 * 43.5F;
            if (f14 + 37.0F >= f7 && f14 <= f7 + f9) {
               t2tp1d2.a(matrixStack, s7swsm2, f13, f14, f11, n, n2, f5);
            }

            n3++;
         }

         s7swsm2.b().a(matrixStack);
         if (bl) {
            this.v.a(matrixStack, s7swsm2, f + f3 + 18.0F, f7, f9, f10, f9, n, n2, false);
         }

         this.w.a(matrixStack, s7swsm2, f, f2 + 1.5F, f3, f4, f5);
      }
   }

   public void b(FriendEntry fghxgs2) {
      LOGGER.debug("History entry removed: {}", fghxgs2);
   }

   public boolean c() {
      return BooleanCoercion.from(!this.t.c() && !this.u.d() ? 0 : 1);
   }

   private float f() {
      if (this.A.isEmpty()) {
         return 0.0F;
      }

      float f = (int)Math.ceil(this.A.size() / 2.0) * 43.5F - 6.5F;
      LOGGER.trace("Scroll height calculated: {} for {} friends", f, this.A.size());
      return f;
   }

   public boolean d() {
      return this.r.isEmpty();
   }

   public boolean a(int n, int n2, int n3) {
      boolean handled = this.t.c() ? this.t.a(n, n2, n3) : this.u.d() && this.u.b(n, n2, n3);
      if (handled) {
         LOGGER.trace("Key typed: char={}, keyCode={}", n, n2);
      }

      return handled;
   }

   public void a(float f, int n, int n2) {
      float f2 = this.D + 19.5F + 5.0F;
      float f3 = this.F - 19.5F - 5.0F;
      if (GuiInput.a(this.C, f2, this.E, f3, n, n2)) {
         this.v.a(f, this.f(), f3 - 6.5F - 6.5F);
         LOGGER.trace("Scroll wheel: delta={}", f);
      }
   }

   public void a(int n, int n2, double d, double d2) {
      if (this.v.c()) {
         float f = this.H - 6.5F - 6.5F;
         this.v.a(n2, this.f(), f);
         LOGGER.trace("Scroll drag: dx={}, dy={}", d, d2);
      }
   }

   public void a(FriendEntry fghxgs2) {
      LOGGER.debug("History entry added: {}", fghxgs2);
   }

   public boolean a(char c, int n) {
      boolean handled = this.t.c() ? this.t.a(c, n) : this.u.d() && this.u.a(c, n);
      if (handled) {
         LOGGER.trace("Character typed: '{}', keyCode={}", c, n);
      }

      return handled;
   }

   private void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, float f3, float f4) {
      FontRenderer v6hnga2 = ClientFonts.b[24];
      FontRenderer v6hnga3 = ClientFonts.a[15];
      String string = this.r.isEmpty() ? "Доюавь новых друзей" : "Ничего не найдено";
      String string2 = this.r.isEmpty() ? "Введи никнейм друга в поле “Добавить” и нажми на плюсик" : "Попробуй изменить запрос";
      float f5 = v6hnga2.a(string);
      float f6 = v6hnga3.a(string2);
      float f7 = f + (f3 - f5) / 2.0F;
      float f8 = f2 + f4 / 2.0F - 20.0F;
      float f9 = f + (f3 - f6) / 2.0F;
      v6hnga2.a(string, f7, f8, pryrvd.a, matrixStack);
      v6hnga3.a(string2, f9, f8 + 15.0F, pryrvd.b, matrixStack);
   }

   private void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, float f3, float f4, float f5) {
      Color color = pryrvd.b(pryrvd.m, f5);
      Color color2 = pryrvd.b(pryrvd.n, f5);
      s7swsm2.a(f - 0.5F, f2 - 0.5F, f3 + 1.0F, f4 + 1.0F, 9.5F, color, color, color2, color2, matrixStack);
      int n = (int)(255.0F * f5);
      Color color3 = pryrvd.a(pryrvd.CELL_BG_TOP, n);
      Color color4 = pryrvd.a(pryrvd.CELL_BG_BOT, n);
      s7swsm2.a(f, f2, f3, f4, 9.5F, color3, color3, color4, color4, matrixStack);
   }

   public void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, float f3, float f4, int n, int n2, float f5) {
      this.C = f;
      this.D = f2;
      this.E = f3;
      this.F = f4;
      this.v.a();
      this.x.a();
      float f6 = f3 - 98.5F - 5.0F - 19.5F - 5.0F;
      this.t.a(matrixStack, s7swsm2, f, f2, 98.5F, 19.5F, n, n2);
      float f7 = f + 98.5F + 5.0F;
      this.u.a(matrixStack, s7swsm2, f7, f2, f6, 19.5F, n, n2, f5);
      this.a(matrixStack, s7swsm2, f7 + f6 + 5.0F, f2, n, n2, f5);
      float f8 = f2 + 24.5F;
      float f9 = f4 - (f8 - f2);
      this.G = f8;
      this.H = f9;
      this.I = f3;
      this.b(matrixStack, s7swsm2, f, f8, f3, f9, n, n2, f5);
   }

   private void a(String string) {
      LOGGER.debug("Search query updated: '{}'", string);
      this.z = string.toLowerCase().trim();
      this.e();
      this.v.e();
      LOGGER.trace("Search results count: {}", this.A.size());
   }

   public void a(Consumer<FriendEntry> consumer) {
      LOGGER.debug("Setting history consumer");
      this.B = consumer;
   }

   public void a(int n, int n2) {
      this.v.d();
      LOGGER.trace("Scroll event at ({}, {})", n, n2);
   }

   public List<FriendEntry> a() {
      LOGGER.trace("Getting history entries, size: {}", this.r.size());
      return this.r;
   }

   public boolean a(float f, float f2, float f3, float f4, int n, int n2) {
      if (this.t.a(n, n2)) {
         this.u.a(false);
         LOGGER.debug("Search box focused");
         return true;
      }

      float f5 = f3 - 98.5F - 5.0F - 19.5F - 5.0F;
      float f6 = f + 98.5F + 5.0F;
      if (this.u.a(n, n2, 0)) {
         this.t.b(false);
         LOGGER.debug("Text input focused");
         return true;
      }

      if (GuiInput.a(f6 + f5 + 5.0F, f2, 19.5F, 19.5F, n, n2)) {
         this.g();
         LOGGER.info("Add friend button clicked");
         return true;
      }

      float f7 = f2 + 19.5F + 5.0F + 6.5F;
      float f8 = f4 - 19.5F - 5.0F - 6.5F - 6.5F;
      float f9 = f3 - 2.0F;
      float f10 = this.f();
      if (f10 > f8 && this.v.a(f + f3 + 18.0F, f7, f8, f10, f8, n, n2)) {
         LOGGER.trace("Scroll bar interaction");
         return true;
      }

      float f11 = f + 1.0F;
      float f12 = (f9 - 9.5F) / 2.0F;
      if (GuiInput.a(f11, f7, f9, f8, n, n2)) {
         float f13 = f7 - this.v.b();
         int n3 = 0;

         for (Iterator<FriendCard> iterator = this.A.iterator(); iterator.hasNext(); n3++) {
            if (iterator.next().a(f11 + n3 % 2 * (f12 + 9.5F), f13 + n3 / 2 * 43.5F, f12, n, n2)) {
               LOGGER.debug("Friend card clicked at index: {}", n3);
               return true;
            }
         }
      }

      return false;
   }

   private void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, int n, int n2, float f3) {
      int n3 = (int)(255.0F * f3);
      boolean bl = GuiInput.a(f, f2, 19.5F, 19.5F, n, n2);
      if (bl != this.y) {
         this.x.a(bl ? 1.0 : 0.0, 0.15, Easings.h);
         this.y = bl;
         LOGGER.trace("Add friend button hover state changed: {}", bl);
      }

      float f4 = (float)this.x.j();
      Color color = pryrvd.b(pryrvd.q, f3);
      Color color2 = pryrvd.b(pryrvd.n, f3);
      s7swsm2.a(f - 0.5F, f2 - 0.5F, 20.5F, 20.5F, 6.5F, color, color, color2, color2, matrixStack);
      Color color3 = ColorUtils.a(pryrvd.CELL_BG_TOP, o, f4);
      Color color4 = ColorUtils.a(pryrvd.CELL_BG_BOT, p, f4);
      Color color5 = pryrvd.a(color3, n3);
      Color color6 = pryrvd.a(color4, n3);
      s7swsm2.a(f, f2, 19.5F, 19.5F, 6.5F, color5, color5, color6, color6, matrixStack);
      Color color7 = pryrvd.a(ColorUtils.a(pryrvd.b, q, f4), n3);
      float f5 = f + 7.25F;
      float f6 = f2 + 7.25F;
      s7swsm2.a(f5, f6 + 2.5F - 0.75F, 5.0F, 1.5F, color7, matrixStack);
      s7swsm2.a(f5 + 2.5F - 0.75F, f6, 1.5F, 5.0F, color7, matrixStack);
      if (bl) {
         GuiInput.g();
      }
   }

   private void g() {
      LOGGER.info("Add friend action triggered");
   }
}
