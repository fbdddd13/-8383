package haron.gui.core;

import java.util.List;

public interface ToggleEntryProvider {
   List<? extends ToggleableEntry> e();

   int f();
}
