package haron.gui.core;

import haron.module.HaronModule;

public interface ToggleableEntry {
   default HaronModule e() {
      return null;
   }

   boolean b();

   default boolean c() {
      return true;
   }

   default boolean h() {
      return this.d();
   }

   default int f() {
      HaronModule jxs16t2 = this.e();
      return jxs16t2 != null ? jxs16t2.j() : -1;
   }

   default boolean d() {
      return false;
   }

   String a();

   default void a(int n) {
      HaronModule jxs16t2 = this.e();
      if (jxs16t2 != null) {
         jxs16t2.a(n);
      }
   }

   void a(boolean var1);

   default boolean g() {
      HaronModule jxs16t2 = this.e();
      return jxs16t2 != null && !jxs16t2.m().isEmpty();
   }
}
