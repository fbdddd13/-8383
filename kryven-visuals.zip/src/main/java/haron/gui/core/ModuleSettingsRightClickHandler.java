package haron.gui.core;

import haron.client.MinecraftClientAccess;
import haron.gui.modules.ModuleCard;
import haron.gui.modules.ModulesTab;
import haron.module.HaronModule;
import net.minecraft.client.gui.screen.Screen;

public final class ModuleSettingsRightClickHandler implements MinecraftClientAccess {
   public static boolean handleRightClick(double d, double d2) {
      Screen screen = c.currentScreen;
      if (!(screen instanceof ClickGuiScreen)) {
         return false;
      } else if (!(((ClickGuiScreen)screen).a() instanceof ModulesTab so7bsc2)) {
         return true;
      } else {
         ModuleCard sudbet2 = so7bsc2.findCardAtBounds((int)d, (int)d2);
         HaronModule jxs16t2;
         if (sudbet2 != null && (jxs16t2 = sudbet2.l().e()) != null && !jxs16t2.m().isEmpty()) {
            so7bsc2.openSettingsForCard(sudbet2);
            return true;
         } else {
            return true;
         }
      }
   }

   private ModuleSettingsRightClickHandler() {
   }
}
