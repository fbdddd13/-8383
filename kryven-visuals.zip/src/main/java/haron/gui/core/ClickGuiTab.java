package haron.gui.core;

import haron.render.ShapeRenderer;
import net.minecraft.client.util.math.MatrixStack;

public interface ClickGuiTab {
   default boolean b() {
      return false;
   }

   void b(float var1, float var2, int var3, int var4);

   void c(float var1, float var2, int var3, int var4);

   void a(MatrixStack var1, ShapeRenderer var2, float var3, float var4, int var5, int var6);

   default boolean a(int n, int n2, int n3) {
      return false;
   }

   ClickGuiTabType a();

   void a(float var1);

   void a(float var1, float var2, int var3, int var4, double var5, double var7);

   void a(float var1, float var2, int var3, int var4);
}
