package haron.gui.core;

public interface CategorySelectionModel {
   String[] c();

   int d();

   void a(int var1);
}
