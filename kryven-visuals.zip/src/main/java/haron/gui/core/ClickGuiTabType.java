package haron.gui.core;

public enum ClickGuiTabType {
   MODULES("modules", "\ue916"),
   MARKERS("markers", "\ue915"),
   FRIENDS("friends", "\ue90d"),
   EVENTS("events", "\ue90a"),
   CONFIGS("configs", "\ue905");

   private final String id;
   private final String icon;

   ClickGuiTabType(String string2, String string3) {
      this.id = string2;
      this.icon = string3;
   }

   public String b() {
      return this.icon;
   }

   public String a() {
      return this.id;
   }
}
