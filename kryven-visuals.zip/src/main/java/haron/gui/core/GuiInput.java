package haron.gui.core;

import haron.core.BooleanCoercion;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class GuiInput {
   private static float j;
   private static float k;
   private static float l;
   private static float m;
   public static int a;
   public static boolean b;
   private static long e = 0L;
   private static long f = 0L;
   private static final double[] c = new double[1];
   private static final double[] d = new double[1];
   private static boolean g = false;
   private static boolean h = false;
   private static boolean i = false;
   private static boolean textCursor = false;
   private static long textCursorHandle = 0L;

   public static boolean contains(float x, float y, float width, float height, double pointX, double pointY) {
      return a(x, y, width, height, pointX, pointY);
   }

   public static void setTextCursor() {
      if (!h) {
         textCursor = true;
      }
   }

   public static double e() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.getWindow() == null) {
         return 0.0;
      }

      GLFW.glfwGetCursorPos(minecraftClient.getWindow().getHandle(), c, d);
      return c[0] * minecraftClient.getWindow().getScaledWidth() / minecraftClient.getWindow().getWidth();
   }

   public static void i() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.getWindow() != null) {
         long l = minecraftClient.getWindow().getHandle();
         if (textCursor) {
            if (textCursorHandle == 0L) {
               textCursorHandle = GLFW.glfwCreateStandardCursor(221186);
            }

            GLFW.glfwSetCursor(l, textCursorHandle);
         } else if (g) {
            if (e == 0L) {
               e = GLFW.glfwCreateStandardCursor(221188);
            }

            GLFW.glfwSetCursor(l, e);
         } else {
            if (f == 0L) {
               f = GLFW.glfwCreateStandardCursor(221185);
            }

            GLFW.glfwSetCursor(l, f);
         }
      }
   }

   public static boolean b(GuiLayer v0ahvd2, double d, double d2) {
      return GuiLayerRegistry.a().d(v0ahvd2, d, d2);
   }

   public static void b() {
      h = true;
   }

   public static void c() {
      h = false;
   }

   public static void h() {
      g = false;
      textCursor = false;
   }

   public static double f() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.getWindow() == null) {
         return 0.0;
      }

      GLFW.glfwGetCursorPos(minecraftClient.getWindow().getHandle(), c, d);
      return d[0] * minecraftClient.getWindow().getScaledHeight() / minecraftClient.getWindow().getHeight();
   }

   public static boolean d() {
      return h;
   }

   public static boolean a(double d, double d2, double d3, double d4, double d5, double d6) {
      if (!(d5 >= d) || !(d6 >= d2) || !(d5 <= d + d3) || !(d6 <= d2 + d4)) {
         return false;
      } else {
         return !i ? true : BooleanCoercion.from(!(d5 < j) && !(d6 < k) && !(d5 > j + l) && !(d6 > k + m) ? 1 : 0);
      }
   }

   public static void a(float f, float f2, float f3, float f4) {
      int n = 888;
      i = true;
      j = f;
      k = f2;
      l = f3;
      m = f4;
   }

   public static boolean a(float f, float f2, float f3, float f4, double d, double d2) {
      return a((double)f, (double)f2, (double)f3, (double)f4, d, d2);
   }

   public static boolean a(GuiLayer v0ahvd2, double d, double d2) {
      return !i || d >= j && d2 >= k && d <= j + l && d2 <= k + m ? GuiLayerRegistry.a().a(v0ahvd2, d, d2) : false;
   }

   public static boolean a(GuiLayer v0ahvd2, float f, float f2, float f3, float f4, double d, double d2) {
      return a(f, f2, f3, f4, d, d2) ? a(v0ahvd2, d, d2) : false;
   }

   public static void a() {
      i = false;
   }

   public static boolean a(double d, double d2) {
      return !i ? true : BooleanCoercion.from(!(d < j) && !(d2 < k) && !(d > j + l) && !(d2 > k + m) ? 1 : 0);
   }

   public static boolean k() {
      return i;
   }

   public static void g() {
      if (!h) {
         g = true;
         textCursor = false;
      }
   }

   public static void j() {
      g = false;
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.getWindow() != null) {
         if (f == 0L) {
            f = GLFW.glfwCreateStandardCursor(221185);
         }

         GLFW.glfwSetCursor(minecraftClient.getWindow().getHandle(), f);
      }
   }
}
