package haron.gui.events;

import haron.client.MinecraftClientAccess;
import haron.gui.core.CategorySelectionModel;
import haron.gui.core.CategorySelectorOverlay;
import haron.gui.core.ClickGuiScreen;
import haron.gui.core.ClickGuiTab;
import haron.gui.core.ClickGuiTabType;
import haron.gui.core.ScrollFadeOverlay;
import haron.render.ShapeRenderer;
import haron.render.font.ClientFonts;
import haron.render.font.FontRenderer;
import haron.theme.pryrvd;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;

public class CommandBindsPanel implements CategorySelectionModel, MinecraftClientAccess, ClickGuiTab {
   public static final List<CommandKeyBind> BINDS = new ArrayList<>();
   private static final Set<Integer> HELD = new HashSet<>();
   private static final String[] CATS = new String[]{"Binds"};
   private static final float TOP_OFFSET = 20.0F;
   private static final float SIDE_PAD = 19.0F;
   private static final float TOGGLE_ROW_H = 22.0F;
   private static final float BTN_W = 75.0F;
   private static final float BTN_H = 18.0F;
   private static final float BTN_GAP = 6.0F;
   private static final float CARD_H = 32.0F;
   private static final float CARD_GAP = 6.0F;
   private final ScrollFadeOverlay p;
   private final CategorySelectorOverlay m;
   private String inputText = "";
   private boolean inputFocused = false;
   private final float[] inputRect = new float[4];
   private int q;
   private int r;
   private int k = 0;
   private float scroll = 0.0F;
   private float listVisibleH = 0.0F;
   private final float[] btnAdd = new float[4];
   private final float[] btnClear = new float[4];
   private final List<float[]> keyRects = new ArrayList<>();
   private final List<float[]> delRects = new ArrayList<>();
   private final List<CommandKeyBind> renderedBinds = new ArrayList<>();

   public static void tick() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null && minecraftClient.player != null && minecraftClient.getWindow() != null) {
         if (minecraftClient.currentScreen != null) {
            HELD.clear();
         } else {
            long l = minecraftClient.getWindow().getHandle();

            for (CommandKeyBind aprxg32 : BINDS) {
               int n = aprxg32.key;
               if (n > 0 && aprxg32.command != null && !aprxg32.command.trim().isEmpty()) {
                  boolean bl;
                  try {
                     bl = GLFW.glfwGetKey(l, n) == 1;
                  } catch (Throwable throwable) {
                     continue;
                  }

                  if (bl) {
                     if (HELD.add(n)) {
                        execute(aprxg32.command.trim());
                     }
                  } else {
                     HELD.remove(n);
                  }
               }
            }
         }
      } else {
         HELD.clear();
      }
   }

   private void drawBindsList(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, float f3, float f4, int n, int n2) {
      this.keyRects.clear();
      this.delRects.clear();
      this.renderedBinds.clear();
      if (!BINDS.isEmpty()) {
         float f5 = f2 - this.scroll;
         int n3 = 0;

         for (CommandKeyBind aprxg32 : BINDS) {
            float f6 = f5 + n3 * 38.0F;
            n3++;
            if (!(f6 + 32.0F < f2) && !(f6 > f2 + f4)) {
               s7swsm2.a(f, f6, f3, 32.0F, 7.0F, pryrvd.CELL_BG_TOP, pryrvd.CELL_BG_TOP, pryrvd.CELL_BG_BOT, pryrvd.CELL_BG_BOT, matrixStack);
               FontRenderer v6hnga2 = ClientFonts.MEDIUM[14];
               v6hnga2.a(aprxg32.command, f + 10.0F, f6 + 11.5F, new Color(235, 215, 195, 230), matrixStack);
               float f7 = 80.0F;
               float f8 = f + f3 - 120.0F;
               float f9 = f6 + 7.0F;
               boolean bl = n >= f8 && n <= f8 + 80.0F && n2 >= f9 && n2 <= f9 + 18.0F;
               String string = aprxg32.binding ? "PRESS..." : this.getKeyName(aprxg32.key);
               Color color = aprxg32.binding ? pryrvd.ACCENT_SOFT : (bl ? pryrvd.ROW_HOVER_TOP : pryrvd.CELL_BG_TOP);
               Color color3 = aprxg32.binding ? pryrvd.ACCENT_DARK : (bl ? pryrvd.ROW_HOVER_TOP : pryrvd.CELL_BG_BOT);
               s7swsm2.a(f8, f9, 80.0F, 18.0F, 4.0F, color, color, color3, color3, matrixStack);
               FontRenderer v6hnga3 = ClientFonts.MEDIUM[11];
               float f10 = v6hnga3.a(string);
               v6hnga3.a(string, f8 + (80.0F - f10) / 2.0F, f9 + 5.0F, Color.WHITE, matrixStack);
               float f11 = 20.0F;
               float f12 = f + f3 - 30.0F;
               float f13 = f6 + 7.0F;
               boolean bl2 = n >= f12 && n <= f12 + 20.0F && n2 >= f13 && n2 <= f13 + 18.0F;
               Color color4 = bl2 ? new Color(180, 50, 50, 255) : new Color(110, 35, 35, 255);
               Color color5 = bl2 ? new Color(150, 40, 40, 255) : new Color(90, 25, 25, 255);
               s7swsm2.a(f12, f13, 20.0F, 18.0F, 4.0F, color4, color4, color5, color5, matrixStack);
               float f14 = v6hnga3.a("X");
               v6hnga3.a("X", f12 + (20.0F - f14) / 2.0F, f13 + 5.0F, Color.WHITE, matrixStack);
               this.keyRects.add(new float[]{f8, f9, 80.0F, 18.0F});
               this.delRects.add(new float[]{f12, f13, 20.0F, 18.0F});
               this.renderedBinds.add(aprxg32);
            }
         }
      }
   }

   private void addBind() {
      String string = this.inputText.trim();
      if (!string.isEmpty()) {
         BINDS.add(new CommandKeyBind(string, 0));
         this.inputText = "";
      }
   }

   private String getKeyName(int n) {
      if (n > 0 && n != 256) {
         switch (n) {
            case 32:
               return "SPACE";
            case 257:
               return "ENTER";
            case 258:
               return "TAB";
            case 260:
               return "INSERT";
            case 261:
               return "DELETE";
            case 262:
               return "RIGHT";
            case 263:
               return "LEFT";
            case 264:
               return "DOWN";
            case 265:
               return "UP";
            case 266:
               return "PGUP";
            case 267:
               return "PGDN";
            case 268:
               return "HOME";
            case 269:
               return "END";
            case 290:
               return "F1";
            case 291:
               return "F2";
            case 292:
               return "F3";
            case 293:
               return "F4";
            case 294:
               return "F5";
            case 295:
               return "F6";
            case 296:
               return "F7";
            case 297:
               return "F8";
            case 298:
               return "F9";
            case 299:
               return "F10";
            case 300:
               return "F11";
            case 301:
               return "F12";
            case 340:
               return "LSHIFT";
            case 341:
               return "LCTRL";
            case 342:
               return "LALT";
            case 344:
               return "RSHIFT";
            case 345:
               return "RCTRL";
            case 346:
               return "RALT";
            default:
               try {
                  String string = GLFW.glfwGetKeyName(n, 0);
                  if (string != null) {
                     return string.toUpperCase(Locale.ROOT);
                  }
               } catch (Throwable var3) {
               }

               return $sf$1(n);
         }
      } else {
         return "NONE";
      }
   }

   private void drawInput(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, float f3, int n, int n2) {
      boolean bl = n >= f && n <= f + f3 && n2 >= f2 && n2 <= f2 + 18.0F;
      Color color2 = this.inputFocused ? pryrvd.ACCENT_SOFT : (bl ? pryrvd.ROW_HOVER_TOP : pryrvd.CELL_BG_TOP);
      Color color4 = this.inputFocused ? pryrvd.ACCENT_DARK : (bl ? pryrvd.ROW_HOVER_TOP : pryrvd.CELL_BG_BOT);
      s7swsm2.a(f, f2, f3, 18.0F, 5.0F, color2, color2, color4, color4, matrixStack);
      FontRenderer v6hnga2 = ClientFonts.MEDIUM[12];
      Color color;
      String string;
      if (this.inputText.isEmpty() && !this.inputFocused) {
         string = "Напиши бинд";
         color = new Color(160, 140, 120, 140);
      } else {
         string = this.inputText;
         if (this.inputFocused && System.currentTimeMillis() % 1000L < 500L) {
            string = $sf$0(string);
         }

         color = new Color(240, 220, 200, 230);
      }

      v6hnga2.a(string, f + 8.0F, f2 + 5.0F, color, matrixStack);
      this.inputRect[0] = f;
      this.inputRect[1] = f2;
      this.inputRect[2] = f3;
      this.inputRect[3] = 18.0F;
   }

   private void drawButton(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, String string, float[] fArray, int n, int n2, Color color) {
      boolean bl = n >= f && n <= f + 75.0F && n2 >= f2 && n2 <= f2 + 18.0F;
      Color color2 = bl ? color.brighter() : color;
      Color color3 = bl ? color : color.darker();
      s7swsm2.a(f, f2, 75.0F, 18.0F, 5.0F, color2, color2, color3, color3, matrixStack);
      FontRenderer v6hnga2 = ClientFonts.MEDIUM[12];
      float f3 = v6hnga2.a(string);
      v6hnga2.a(string, f + (75.0F - f3) / 2.0F, f2 + 5.0F, Color.WHITE, matrixStack);
      fArray[0] = f;
      fArray[1] = f2;
      fArray[2] = 75.0F;
      fArray[3] = 18.0F;
   }

   public static void onKeyPress(int n) {
      if (n > 0) {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         if (minecraftClient != null && minecraftClient.player != null) {
            if (minecraftClient.currentScreen == null) {
               for (CommandKeyBind aprxg32 : BINDS) {
                  if (aprxg32.key == n && aprxg32.command != null && !aprxg32.command.trim().isEmpty()) {
                     execute(aprxg32.command.trim());
                  }
               }
            }
         }
      }
   }

   public CommandBindsPanel() {
      this.m = new CategorySelectorOverlay(this);
      this.p = new ScrollFadeOverlay(25, 10.0F, 7.5F);
   }

   @Override
   public boolean b() {
      return this.inputFocused;
   }

   @Override
   public void b(float f, float f2, int n, int n2) {
      this.a(f, f2, n, n2);
   }

   @Override
   public void c(float f, float f2, int n, int n2) {
   }

   @Override
   public String[] c() {
      return CATS;
   }

   @Override
   public int d() {
      int n = 514;
      return this.k;
   }

   @Override
   public boolean a(int n, int n2, int n3) {
      for (CommandKeyBind aprxg32 : BINDS) {
         if (aprxg32.binding) {
            aprxg32.key = n == 256 ? 0 : n;
            aprxg32.binding = false;
            return true;
         }
      }

      if (!this.inputFocused) {
         return false;
      }

      if (n == 259) {
         if (!this.inputText.isEmpty()) {
            this.inputText = this.inputText.substring(0, this.inputText.length() - 1);
         }

         return true;
      } else {
         if (n == 257 || n == 335) {
            this.addBind();
            return true;
         }

         if (n == 256) {
            this.inputFocused = false;
            return true;
         }

         if (n == 86 && (n3 & 2) != 0) {
            try {
               long l = MinecraftClient.getInstance().getWindow().getHandle();
               String string = GLFW.glfwGetClipboardString(l);
               if (string != null) {
                  String string2 = string.replace('\n', ' ').replace('\r', ' ');
                  if (this.inputText.length() + string2.length() <= 80) {
                     this.inputText = $sf$2(this.inputText, string2);
                  }
               }
            } catch (Throwable var8) {
            }

            return true;
         } else {
            return true;
         }
      }
   }

   @Override
   public void a(int n) {
      if (n >= 0 && n < CATS.length && this.k != n) {
         this.k = n;
         this.scroll = 0.0F;
      }
   }

   public boolean a(char c, int n) {
      if (this.inputFocused) {
         if (c >= ' ' && c != 127 && this.inputText.length() < 80) {
            this.inputText = $sf$3(this.inputText, c);
         }

         return true;
      } else {
         return false;
      }
   }

   @Override
   public ClickGuiTabType a() {
      return ClickGuiTabType.EVENTS;
   }

   @Override
   public void a(float f, float f2, int n, int n2) {
      this.m.a(f, f2, n, n2);
      if (hit(this.inputRect, n, n2)) {
         this.inputFocused = true;
      } else {
         this.inputFocused = false;
         if (hit(this.btnAdd, n, n2)) {
            this.addBind();
         } else if (hit(this.btnClear, n, n2)) {
            BINDS.clear();
         } else {
            for (int i = 0; i < this.renderedBinds.size(); i++) {
               CommandKeyBind aprxg32 = this.renderedBinds.get(i);
               if (hit(this.keyRects.get(i), n, n2)) {
                  for (CommandKeyBind aprxg33 : BINDS) {
                     if (aprxg33 != aprxg32) {
                        aprxg33.binding = false;
                     }
                  }

                  aprxg32.binding = !aprxg32.binding;
                  return;
               }

               if (hit(this.delRects.get(i), n, n2)) {
                  BINDS.remove(aprxg32);
                  return;
               }
            }
         }
      }
   }

   @Override
   public void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, int n, int n2) {
      this.q = n;
      this.r = n2;
      this.m.a(matrixStack, s7swsm2, f, f2, n, n2);
      float f4 = ClickGuiScreen.d();
      float f5 = ClickGuiScreen.e();
      float f6 = f + 19.0F;
      float f7 = f2 + 20.0F;
      float f8 = f4 - 38.0F;
      float f9 = f5 - 20.0F - 9.5F;
      float f10 = f7 + 2.0F;
      float f11 = f8 - 162.0F;
      this.drawInput(matrixStack, s7swsm2, f6, f10, f11, n, n2);
      this.drawButton(matrixStack, s7swsm2, f6 + f11 + 6.0F, f10, "Добавить бинд", this.btnAdd, n, n2, new Color(40, 110, 40, 240));
      this.drawButton(matrixStack, s7swsm2, f6 + f11 + 6.0F + 75.0F + 6.0F, f10, "Удалить все", this.btnClear, n, n2, new Color(130, 40, 40, 240));
      float f12 = f7 + 22.0F + 8.0F;
      float f3;
      this.listVisibleH = f3 = f9 - 38.0F;
      this.drawBindsList(matrixStack, s7swsm2, f6, f12, f8, f3, n, n2);
      this.p.a(matrixStack, s7swsm2, f, f2, n, n2);
   }

   @Override
   public void a(float f, float f2, int n, int n2, double d, double d2) {
   }

   @Override
   public void a(float f) {
      this.scroll -= f * 12.0F;
      if (this.scroll < 0.0F) {
         this.scroll = 0.0F;
      }

      float f3;
      if (this.scroll > (f3 = Math.max(0.0F, BINDS.size() * 38.0F - this.listVisibleH))) {
         this.scroll = f3;
      }
   }

   private static void execute(String string) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null && minecraftClient.player != null) {
         if (minecraftClient.player.networkHandler != null) {
            try {
               if (string.startsWith("/")) {
                  minecraftClient.player.networkHandler.sendChatCommand(string.substring(1));
               } else {
                  minecraftClient.player.networkHandler.sendChatMessage(string);
               }
            } catch (Throwable throwable) {
               throwable.printStackTrace();
            }
         }
      }
   }

   private static boolean hit(float[] fArray, int n, int n2) {
      return n >= fArray[0] && n <= fArray[0] + fArray[2] && n2 >= fArray[1] && n2 <= fArray[1] + fArray[3];
   }

   private static String $sf$0(String string) {
      return string + "_";
   }

   private static String $sf$3(String string, char c) {
      int n = 640;
      return string + c;
   }

   private static String $sf$1(int n) {
      return "KEY " + n;
   }

   private static String $sf$2(String string, String string2) {
      return string + string2;
   }
}
