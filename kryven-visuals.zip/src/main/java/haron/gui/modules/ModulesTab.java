package haron.gui.modules;

import haron.audio.SoundPlayer;
import haron.core.BooleanCoercion;
import haron.gui.core.CategorySelectionModel;
import haron.gui.core.CategorySelectorOverlay;
import haron.gui.core.ClickGuiScreen;
import haron.gui.core.ClickGuiTab;
import haron.gui.core.ClickGuiTabType;
import haron.gui.core.ScrollFadeOverlay;
import haron.gui.core.ToggleEntryProvider;
import haron.gui.core.ToggleableEntry;
import haron.gui.widgets.IconButton;
import haron.gui.widgets.SearchBox;
import haron.module.HaronModule;
import haron.module.ModuleCategory;
import haron.module.ModuleManager;
import haron.modules.hud.ClientColor;
import haron.render.ShapeRenderer;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.client.util.math.MatrixStack;

public class ModulesTab implements CategorySelectionModel, ToggleEntryProvider, ClickGuiTab {
   private static final String[] a = new String[]{"Visuals", "HUD", "Utilities"};
   private static final ModuleCategory[] b = new ModuleCategory[]{ModuleCategory.VISUALS, ModuleCategory.HUD, ModuleCategory.UTILITIES};
   private static final float c = 117.5F;
   private static final float d = 15.0F;
   private static final float e = 19.0F;
   private static final float f = 19.0F;
   private static final float g = 15.0F;
   private static final float h = 4.0F;
   private static final float SEARCH_LEFT_PAD = 8.0F;
   private static final float SEARCH_TOP_PAD = 16.0F;
   private static final float SEARCH_GAP = 4.0F;
   private static final float COLOR_DOT_SIZE = 11.0F;
   private static final float COLOR_DOT_HIT_SIZE = 18.0F;
   private static final float COLOR_ROW_LEFT_GAP = 18.0F;
   private static final float COLOR_ROW_RIGHT_GAP = 18.0F;
   private static final float SETTINGS_SIZE = 15.0F;
   private static final float SETTINGS_RIGHT_PAD = 19.0F;
   private final CategorySelectorOverlay l;
   private final ToggleEntryListOverlay m;
   private final ScrollFadeOverlay n;
   private final SearchBox o;
   private final IconButton p;
   private List<ModuleListEntry> r;
   private int i = 0;
   private String q = "";
   private boolean s = false;
   private final Map<ModuleCategory, List<ModuleListEntry>> j = new HashMap<>();
   private final List<ModuleListEntry> k = new ArrayList<>();

   public void openSettingsForCard(ModuleCard sudbet2) {
      if (sudbet2 != null && !sudbet2.f()) {
         sudbet2.b();
      }
   }

   public boolean hasOpenSettingsAt(int n, int n2) {
      return this.m.hasOpenSettingsAt(n, n2);
   }

   private static int colorDistance(Color color, Color color2) {
      if (color != null && color2 != null) {
         int n = color.getRed() - color2.getRed();
         int n2 = color.getGreen() - color2.getGreen();
         int n3 = color.getBlue() - color2.getBlue();
         return Math.abs(n) + Math.abs(n2) + Math.abs(n3);
      } else {
         return 999999;
      }
   }

   private boolean isSelectedColor(Color color) {
      return colorDistance(ClientColor.currentColor(), color) < 16;
   }

   private boolean isInsideColorDot(float f, float f2, int n, int n2) {
      float f3 = 9.0F;
      return n >= f - 9.0F && n <= f + 9.0F && n2 >= f2 - 9.0F && n2 <= f2 + 9.0F;
   }

   private float getSettingsX(float f) {
      return f + ClickGuiScreen.d() - 19.0F - 15.0F;
   }

   private float getSettingsY(float f) {
      return this.getSearchY(f);
   }

   public void openSettings(HaronModule jxs16t2) {
      this.m.a(jxs16t2);
   }

   private void renderColorDots(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, int n, int n2) {
      Color[] colorArray = ClientColor.presets();
      if (colorArray != null && colorArray.length != 0) {
         float f3 = this.getSearchX(f);
         float f4 = this.getSearchY(f2);
         float f5 = 117.5F;
         float f6 = 15.0F;
         float f7 = this.getSettingsX(f);
         float f8 = f3 + 117.5F + 18.0F;
         float f9 = f7 - 18.0F;
         float f10 = Math.max(0.0F, f9 - f8);
         float f11 = colorArray.length <= 1 ? 0.0F : f10 / (colorArray.length - 1);
         float f12 = 16.0F;
         if (colorArray.length > 1 && f11 < 16.0F) {
            f11 = 16.0F;
         }

         float f13 = f4 + 7.5F;

         for (int i = 0; i < colorArray.length; i++) {
            Color color2 = colorArray[i];
            float f16 = f8 + i * f11;
            boolean bl = this.isInsideColorDot(f16, f13, n, n2);
            boolean bl2 = this.isSelectedColor(color2);
            float f17 = 11.0F;
            if (bl2) {
               f17 = 13.0F;
            } else if (bl) {
               f17 = 12.5F;
            }

            if (bl2 || bl) {
               float f15 = bl2 ? f17 + 6.0F : f17 + 4.0F;
               float f14 = f16 - f15 / 2.0F;
               float f18 = f13 - f15 / 2.0F;
               Color color;
               if (bl2) {
                  Color color3 = new Color(color2.getRed(), color2.getGreen(), color2.getBlue());
                  color = withAlpha(color3, 180);
               } else {
                  color = withAlpha(Color.WHITE, 60);
               }

               s7swsm2.a(f14, f18, f15, f15, f15 / 2.0F, color, color, color, color, matrixStack);
            }

            float f15 = f16 - f17 / 2.0F;
            float f14 = f13 - f17 / 2.0F;
            Color color4 = new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), 255);
            s7swsm2.a(f15, f14, f17, f17, f17 / 2.0F, color4, color4, color4, color4, matrixStack);
            Color color = withAlpha(Color.WHITE, bl2 ? 65 : (bl ? 45 : 25));
            s7swsm2.a(f15 + 2.0F, f14 + 2.0F, f17 - 4.0F, f17 - 4.0F, (f17 - 4.0F) / 2.0F, color, color, color, color, matrixStack);
         }
      }
   }

   private static Color withAlpha(Color color, int n) {
      if (color == null) {
         color = Color.WHITE;
      }

      return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, Math.min(255, n)));
   }

   public ModuleCard getCardAt(int n, int n2) {
      return this.m.findCardByBounds(n, n2);
   }

   private float getSearchX(float f) {
      return f + 8.0F;
   }

   private float getSearchY(float f) {
      return f + 16.0F;
   }

   public ModuleCard findCardAtBounds(int n, int n2) {
      for (ModuleCard sudbet2 : this.m.a()) {
         if (!sudbet2.f() && sudbet2.e(n, n2)) {
            return sudbet2;
         }
      }

      return null;
   }

   private boolean handleColorDotsClick(float f, float f2, int n, int n2) {
      Color[] colorArray = ClientColor.presets();
      if (colorArray != null && colorArray.length != 0) {
         float f3 = this.getSearchX(f);
         float f4 = this.getSearchY(f2);
         float f5 = 117.5F;
         float f6 = 15.0F;
         float f7 = this.getSettingsX(f);
         float f8 = f3 + 117.5F + 18.0F;
         float f9 = f7 - 18.0F;
         float f10 = Math.max(0.0F, f9 - f8);
         float f11 = colorArray.length <= 1 ? 0.0F : f10 / (colorArray.length - 1);
         float f12 = 16.0F;
         if (colorArray.length > 1 && f11 < 16.0F) {
            f11 = 16.0F;
         }

         float f13 = f4 + 7.5F;

         for (int i = 0; i < colorArray.length; i++) {
            float f14 = f8 + i * f11;
            if (this.isInsideColorDot(f14, f13, n, n2)) {
               ClientColor.setStaticColor(colorArray[i]);

               try {
                  SoundPlayer.play("disabled1", 0.45F);
               } catch (Throwable var20) {
               }

               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public int getCurrentSubCategory() {
      return this.i;
   }

   public ModulesTab() {
      for (ModuleCategory jtlzd02 : ModuleCategory.values()) {
         ArrayList<ModuleListEntry> arrayList = new ArrayList<>();
         Iterator<HaronModule> iterator = ModuleManager.byCategory(jtlzd02).iterator();

         while (iterator.hasNext()) {
            arrayList.add(new ModuleListEntry(iterator.next()));
         }

         arrayList.sort(Comparator.comparing(l7ueve2 -> l7ueve2.a().toLowerCase()));
         this.j.put(jtlzd02, arrayList);
         this.k.addAll(arrayList);
      }

      this.k.sort(Comparator.comparing(l7ueve2 -> l7ueve2.a().toLowerCase()));
      this.r = new ArrayList<>();
      this.l = new CategorySelectorOverlay(this);
      this.m = new ToggleEntryListOverlay(this);
      this.n = new ScrollFadeOverlay();
      this.o = new SearchBox(117.5F, 15.0F);
      this.o.a(this::a);
      this.p = new IconButton();
      this.p.a(void_ -> this.s());
   }

   @Override
   public List<? extends ToggleableEntry> e() {
      if (!this.s) {
         List<ModuleListEntry> list = this.j.get(this.g());
         return list == null ? Collections.emptyList() : list;
      } else {
         return this.r != null && !this.r.isEmpty() ? this.r : Collections.emptyList();
      }
   }

   public boolean i() {
      Iterator<ModuleCard> iterator = this.m.a().iterator();

      while (iterator.hasNext()) {
         if (!iterator.next().f()) {
            return true;
         }
      }

      return false;
   }

   @Override
   public boolean b() {
      return BooleanCoercion.from(!this.o.c() && !this.m.c() ? 0 : 1);
   }

   @Override
   public void b(float f, float f2, int n, int n2) {
      this.o.b(false);
      this.m.b();
      this.m.b(f, f2, n, n2);
   }

   private boolean b(String string, String string2) {
      String[] stringArray = string.split(" ");
      StringBuilder stringBuilder = new StringBuilder();

      for (String string3 : stringArray) {
         if (!string3.isEmpty()) {
            stringBuilder.append(string3.charAt(0));
         }
      }

      return stringBuilder.toString().contains(string2.replace(" ", ""));
   }

   private void s() {
   }

   @Override
   public String[] c() {
      return a;
   }

   @Override
   public void c(float f, float f2, int n, int n2) {
      this.m.c(f, f2, n, n2);
   }

   public void n() {
      this.m.h();
   }

   public List<ModuleCard> h() {
      return this.m.a();
   }

   @Override
   public int f() {
      return 2;
   }

   public void l() {
      this.m.f();
   }

   @Override
   public int d() {
      return this.i;
   }

   @Override
   public ClickGuiTabType a() {
      return ClickGuiTabType.MODULES;
   }

   public boolean a(char c, int n) {
      if (this.m.p()) {
         return this.m.a(c, n);
      } else {
         return this.o.c() ? this.o.a(c, n) : this.m.a(c, n);
      }
   }

   public void a(ModuleCategory jtlzd02) {
      for (int i = 0; i < b.length; i++) {
         if (b[i] == jtlzd02) {
            if (this.i != i) {
               this.i = i;
               this.m.d();
               return;
            }

            return;
         }
      }
   }

   private void a(String string) {
      String string2 = this.q = string == null ? "" : string.toLowerCase().trim();
      if (this.q.isEmpty()) {
         this.s = false;
         if (this.r != null) {
            this.r.clear();
         }
      } else {
         this.s = true;
         this.r = new ArrayList<>();

         for (int i = 0; i < this.k.size(); i++) {
            ModuleListEntry l7ueve2 = this.k.get(i);
            if (l7ueve2.a().toLowerCase().contains(this.q)) {
               this.r.add(l7ueve2);
            }
         }

         this.m.d();
      }
   }

   public void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, int n, int n2) {
      this.m.a(matrixStack, s7swsm2, n, n2);
   }

   private boolean a(String string, String string2) {
      String string3 = string.toLowerCase();
      return string3.contains(string2) || string3.replace(" ", "").contains(string2.replace(" ", "")) || this.b(string3, string2);
   }

   @Override
   public void a(float f, float f2, int n, int n2, double d, double d2) {
      this.m.a(f, f2, n, n2, d, d2);
   }

   @Override
   public void a(float f, float f2, int n, int n2) {
      this.m.b();
      if (!this.o.a(n, n2) && !this.p.a(n, n2)) {
         if (!this.handleColorDotsClick(f, f2, n, n2)) {
            this.m.a(f, f2, n, n2);
         }
      }
   }

   public void a(MatrixStack matrixStack, ShapeRenderer s7swsm2) {
      this.m.a(matrixStack, s7swsm2);
   }

   @Override
   public void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, int n, int n2) {
      this.m.b();
      float f3 = this.getSearchX(f);
      float f4 = this.getSearchY(f2);
      float f5 = 117.5F;
      float f6 = 15.0F;
      this.o.a(matrixStack, s7swsm2, f3, f4, 117.5F, 15.0F, n, n2);
      this.renderColorDots(matrixStack, s7swsm2, f, f2, n, n2);
      float f7 = this.getSettingsX(f);
      float f8 = this.getSettingsY(f2);
      this.p.a(matrixStack, s7swsm2, f7, f8, 15.0F, n, n2);
      this.m.a(matrixStack, s7swsm2, f, f2, n, n2);
      this.n.a(matrixStack, s7swsm2, f, f2, n, n2);
   }

   @Override
   public void a(int n) {
      if (n >= 0 && n < b.length && this.i != n) {
         this.i = n;
         this.m.d();
      }
   }

   @Override
   public boolean a(int n, int n2, int n3) {
      if (this.m.p()) {
         this.m.a(n, n2, n3);
         return true;
      } else if (this.o.c() && this.o.a(n, n2, n3)) {
         return true;
      } else if (n == 256 && this.m.hasOpenSettings()) {
         this.m.closeOpenSettings();
         return true;
      } else {
         return this.m.a(n, n2, n3);
      }
   }

   public void a(float f, int n, int n2) {
      this.m.a(f, n, n2);
   }

   @Override
   public void a(float f) {
      this.m.a(f);
   }

   public void m() {
      int n = 986;
      this.m.g();
   }

   public void o() {
      int n = 246;
      this.o.b(false);
      this.o.b();
      this.m.i();
   }

   public boolean p() {
      return this.o.c();
   }

   public void k() {
      this.m.e();
   }

   public ModuleCategory g() {
      return b[this.i];
   }

   public boolean j() {
      return this.m.j();
   }

   public String q() {
      int n = 991;
      return this.q;
   }

   public boolean r() {
      return this.s;
   }
}
