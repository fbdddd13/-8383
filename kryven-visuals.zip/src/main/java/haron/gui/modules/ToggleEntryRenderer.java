package haron.gui.modules;

import haron.animation.Easings;
import haron.core.BooleanCoercion;
import haron.gui.core.GuiInput;
import haron.gui.core.ToggleableEntry;
import haron.render.ShapeRenderer;
import haron.render.font.ClientFonts;
import haron.render.font.FontRenderer;
import haron.theme.pryrvd;
import haron.util.ColorUtils;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.util.math.MatrixStack;

public class ToggleEntryRenderer {
   private static final float c = 9.5F;
   private static final float d = 11.0F;
   private static final float e = 18.0F;
   private static final float f = 10.0F;
   private static final float g = 5.0F;
   private static final float h = 12.0F;
   private static final float i = 4.0F;
   private final Map<ToggleableEntry, ModuleRowAnimationState> m = new HashMap<>();
   public static int a;
   public static boolean b;

   private static Color mixColors(Color color, Color color2, int n) {
      if (n <= 0) {
         return color;
      }

      if (n >= 255) {
         return color2;
      }

      float f = n / 255.0F;
      int n2 = (int)(color.getRed() + (color2.getRed() - color.getRed()) * f);
      int n3 = (int)(color.getGreen() + (color2.getGreen() - color.getGreen()) * f);
      int n4 = (int)(color.getBlue() + (color2.getBlue() - color.getBlue()) * f);
      int n5 = Math.max(color.getAlpha(), color2.getAlpha());
      return new Color(n2, n3, n4, n5);
   }

   public static float b() {
      int n = 63;
      return 11.0F;
   }

   public static float c() {
      return 12.0F;
   }

   public static float d() {
      return 4.0F;
   }

   public static float a() {
      return 18.0F;
   }

   public void a(ToggleableEntry mt5wd72) {
      if (!this.m.containsKey(mt5wd72)) {
         ModuleRowAnimationState q03vqa2 = new ModuleRowAnimationState();
         q03vqa2.a.d(!mt5wd72.b() ? 0.0 : 1.0);
         q03vqa2.g = mt5wd72.b();
         this.m.put(mt5wd72, q03vqa2);
      }
   }

   public ModuleRowRenderResult a(
      MatrixStack matrixStack,
      ShapeRenderer s7swsm2,
      ToggleableEntry mt5wd72,
      float f,
      float f2,
      float f3,
      float f4,
      int n,
      int n2,
      boolean bl,
      boolean bl2,
      boolean bl3,
      boolean bl4
   ) {
      this.a(mt5wd72);
      ModuleRowAnimationState q03vqa2 = this.m.get(mt5wd72);
      FontRenderer v6hnga2 = ClientFonts.b[14];
      float f5 = f + f3 - 11.0F - 18.0F;
      float f6 = f2 + f4 / 2.0F - 5.0F;
      float f7 = f5 - 4.0F - 12.0F;
      float f8 = f2 + f4 / 2.0F - 6.0F - 0.5F;
      boolean bl7 = mt5wd72.g() || mt5wd72.h();
      int n3 = !bl && !bl2 && GuiInput.a(f, f2, f3, f4, n, n2) ? 1 : 0;
      int n4 = bl7 && !bl && GuiInput.a(f7, f8, 12.0F, 12.0F, n, n2) && n3 != 0 ? 1 : 0;
      int n5 = n3 != 0 && n4 == 0 ? 1 : 0;
      int n6 = n5;
      int n7 = bl7 && n3 != 0 && mt5wd72.d() ? 1 : 0;
      boolean bl8 = bl4 && !bl3;
      boolean bl6 = !bl4 && bl3;
      if (bl7) {
         if (bl4) {
            if (bl2) {
               if (bl8) {
                  q03vqa2.b.a(0.0, 0.15, Easings.h);
                  q03vqa2.d.a(1.0, 0.15, Easings.h);
               }

               q03vqa2.c.d(1.0);
            } else if (bl8 && q03vqa2.e) {
               q03vqa2.b.a(0.0, 0.15, Easings.h);
               q03vqa2.c.a(0.0, 0.2, Easings.h);
               q03vqa2.e = false;
            }
         } else if (bl6) {
            if (n3 != 0) {
               q03vqa2.b.a(1.0, 0.15, Easings.h);
               q03vqa2.c.a(1.0, 0.2, Easings.h);
               q03vqa2.e = true;
            }

            if (n4 == 0) {
               q03vqa2.d.a(0.0, 0.15, Easings.h);
               q03vqa2.f = false;
            }
         } else if (BooleanCoercion.from(n7) != q03vqa2.e) {
            q03vqa2.b.a(n3 == 0 ? 0.0 : 1.0, 0.15, Easings.h);
            q03vqa2.c.a(n3 == 0 ? 0.0 : 1.0, 0.2, Easings.h);
            q03vqa2.e = BooleanCoercion.from(n7);
         }
      } else if (BooleanCoercion.from(n3) != q03vqa2.e) {
         q03vqa2.b.a(n3 == 0 ? 0.0 : 1.0, 0.15, Easings.h);
         q03vqa2.e = BooleanCoercion.from(n3);
      }

      if (bl7 && !bl2 && BooleanCoercion.from(n4) != q03vqa2.f) {
         q03vqa2.d.a(n4 == 0 ? 0.0 : 1.0, 0.15, Easings.h);
         q03vqa2.f = BooleanCoercion.from(n4);
      }

      boolean bl5;
      if ((bl5 = mt5wd72.b()) != q03vqa2.g) {
         q03vqa2.a.a(!bl5 ? 0.0 : 1.0, 0.2, Easings.h);
         q03vqa2.g = bl5;
      }

      q03vqa2.b.a();
      q03vqa2.a.a();
      q03vqa2.c.a();
      q03vqa2.d.a();
      float f9 = (float)q03vqa2.b.j();
      float f10 = (float)q03vqa2.a.j();
      float f11 = (float)q03vqa2.c.j();
      float f12 = (float)q03vqa2.d.j();
      this.a(matrixStack, s7swsm2, f, f2, f3, f4, f9);
      v6hnga2.a(
         mt5wd72.a(),
         (int)(f + 11.0F),
         (int)(f2 + f4 / 2.0F - v6hnga2.b(mt5wd72.a()) / 4.0F),
         ColorUtils.a(pryrvd.b, pryrvd.ROW_TEXT_INACTIVE, f10),
         matrixStack
      );
      if (bl7 && f11 > 0.01F) {
         this.a(matrixStack, s7swsm2, f7, f8, f11, f12, mt5wd72);
      }

      this.a(matrixStack, s7swsm2, f5, f6, f10);
      return new ModuleRowRenderResult(BooleanCoercion.from(n6), BooleanCoercion.from(n4), f7, f8);
   }

   private void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, float f3, float f4, float f5) {
      Color color = pryrvd.a(pryrvd.ACCENT, (int)(f5 * 55.0F));
      s7swsm2.a(f - 2.0F, f2 - 2.0F, f3 + 4.0F, f4 + 4.0F, 11.0F, color, color, color, color, matrixStack);
      Color color2 = pryrvd.a(pryrvd.ACCENT, (int)(f5 * 30.0F));
      s7swsm2.a(f - 1.0F, f2 - 1.0F, f3 + 2.0F, f4 + 2.0F, 10.0F, color2, color2, color2, color2, matrixStack);
      s7swsm2.a(f, f2, f3, f4, 9.5F, pryrvd.ROW_BG_TOP, pryrvd.ROW_BG_TOP, pryrvd.ROW_BG_BOT, pryrvd.ROW_BG_BOT, matrixStack);
      int n = (int)(f5 * 40.0F);
      Color color3 = pryrvd.a(pryrvd.ACCENT, n);
      s7swsm2.a(f, f2, f3, f4, 9.5F, color3, color3, color3, color3, matrixStack);
   }

   private void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, float f3, float f4, ToggleableEntry mt5wd72) {
      ClientFonts.e[24].a("\ue900", f, f2, pryrvd.a(ColorUtils.a(pryrvd.b, pryrvd.N, f4), (int)(255.0F * f3)), matrixStack);
   }

   private void a(MatrixStack matrixStack, ShapeRenderer s7swsm2, float f, float f2, float f3) {
      float f4 = f + 0.5F + 8.0F * f3;
      float f5 = f2 + 0.5F;
      if (f3 > 0.01F) {
         s7swsm2.a(f + 1.0F, f2 - 3.0F, 8.0F, pryrvd.a(pryrvd.ROW_ACCENT, (int)(255.0F * f3 * 0.5F)), matrixStack);
      }

      Color color = ColorUtils.a(pryrvd.q, pryrvd.C, f3);
      Color color2 = ColorUtils.a(pryrvd.r, pryrvd.D, f3);
      s7swsm2.a(f - 0.5F, f2 - 0.5F, 19.0F, 11.0F, 5.0F, color, color, color2, color2, matrixStack);
      Color color3 = ColorUtils.a(pryrvd.f, pryrvd.ROW_ACCENT, f3);
      Color color4 = ColorUtils.a(pryrvd.H, pryrvd.ROW_ACCENT, f3);
      s7swsm2.a(f, f2, 18.0F, 10.0F, 5.0F, color3, color3, color4, color4, matrixStack);
      s7swsm2.a(f4, f5, 9.0F, 9.0F, 9.0F, ColorUtils.a(pryrvd.b, pryrvd.a, f3), matrixStack);
   }
}
