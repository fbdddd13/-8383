package haron.theme;

import java.awt.Color;

public final class pryrvd {
   public static Color ACCENT;
   public static Color ACCENT_SOFT;
   public static Color ACCENT_DARK;
   public static Color PANEL_BG_TOP;
   public static Color PANEL_BG_BOT;
   public static Color CELL_BG_TOP;
   public static Color CELL_BG_BOT;
   public static Color PANEL_BORDER_TOP;
   public static Color PANEL_BORDER_BOT;
   public static Color ROW_BG_TOP;
   public static Color ROW_BG_BOT;
   public static Color ROW_HOVER_TOP;
   public static Color ROW_HOVER_BOT;
   public static Color ROW_ACCENT;
   public static Color ROW_TEXT_INACTIVE;
   public static Color WIDGET_BG_TOP;
   public static Color WIDGET_BG_BOT;
   public static Color WIDGET_BORDER_TOP;
   public static Color WIDGET_BORDER_BOT;
   public static Color LOGO_TEXT;
   public static Color SCROLLBAR_THUMB;
   public static Color b;
   public static Color e;
   public static Color f;
   public static Color m;
   public static Color n;
   public static Color q;
   public static Color r;
   public static Color w;
   public static Color C;
   public static Color D;
   public static Color I;
   public static Color K;
   public static Color aa;
   public static int ae;
   public static boolean af;
   public static Color a = new Color(223, 223, 243);
   public static Color c = new Color(212, 132, 42);
   public static Color d = new Color(110, 85, 50);
   public static Color g = new Color(22, 22, 30);
   public static Color h = new Color(18, 18, 24);
   public static Color i = new Color(30, 25, 20);
   public static Color j = new Color(25, 22, 18);
   public static Color k = new Color(25, 22, 18);
   public static Color l = new Color(20, 18, 14);
   public static Color o = new Color(21, 21, 28);
   public static Color p = new Color(30, 30, 40);
   public static Color s = new Color(50, 40, 28);
   public static Color t = new Color(28, 24, 18);
   public static Color u = new Color(35, 30, 22);
   public static Color v = new Color(22, 20, 16);
   public static Color x = new Color(18, 18, 24);
   public static Color y = new Color(212, 132, 42);
   public static Color z = new Color(174, 100, 20);
   public static Color A = new Color(212, 132, 42, 100);
   public static Color B = new Color(240, 160, 50);
   public static Color E = new Color(87, 55, 15);
   public static Color F = new Color(14, 14, 19);
   public static Color G = new Color(42, 38, 30);
   public static Color H = new Color(0, 0, 0, 55);
   public static Color J = new Color(22, 22, 28);
   public static Color L = new Color(40, 20, 20);
   public static Color M = new Color(30, 15, 15);
   public static Color N = new Color(130, 110, 80);
   public static Color O = new Color(96, 96, 96);
   public static Color P = new Color(85, 70, 45);
   public static Color Q = new Color(240, 160, 50);
   public static Color R = new Color(180, 110, 30);
   public static Color S = new Color(15, 15, 21);
   public static Color T = new Color(18, 18, 25);
   public static Color U = new Color(170, 150, 120);
   public static Color V = new Color(24, 24, 32);
   public static Color W = new Color(220, 53, 69);
   public static Color X = new Color(40, 167, 69);
   public static Color Y = new Color(255, 180, 50);
   public static Color Z = new Color(255, 80, 80);
   public static Color FriendCard = new Color(0, 0, 0);
   public static Color FriendsPanel = new Color(30, 30, 40);
   public static Color ad = new Color(0, 0, 0, 125);

   private static Color withAlpha(Color color, int n) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), n);
   }

   private pryrvd() {
   }

   public static void update(Color color) {
      if (color == null) {
         color = new Color(255, 155, 35);
      }

      float[] fArray = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
      float f = fArray[0];
      float f2 = fArray[1];
      float f3 = Math.min(1.0F, f2 * 0.67F);
      ACCENT = color;
      ACCENT_SOFT = Color.getHSBColor(f, Math.min(1.0F, f2 * 0.82F), 0.75F);
      ACCENT_DARK = Color.getHSBColor(f, Math.min(1.0F, f2 * 0.84F), 0.59F);
      PANEL_BG_TOP = Color.getHSBColor(f, f3, 0.15F);
      PANEL_BG_BOT = Color.getHSBColor(f, f3, 0.19F);
      PANEL_BORDER_TOP = Color.getHSBColor(f, f3, 0.28F);
      PANEL_BORDER_BOT = PANEL_BG_BOT;
      CELL_BG_TOP = Color.getHSBColor(f, f3, 0.2F);
      CELL_BG_BOT = Color.getHSBColor(f, f3, 0.24F);
      ROW_BG_TOP = CELL_BG_TOP;
      ROW_BG_BOT = CELL_BG_BOT;
      ROW_HOVER_TOP = new Color(color.getRed(), color.getGreen(), color.getBlue(), 30);
      ROW_HOVER_BOT = new Color(color.getRed(), color.getGreen(), color.getBlue(), 45);
      ROW_ACCENT = color;
      ROW_TEXT_INACTIVE = Color.getHSBColor(f, Math.min(1.0F, f2 * 0.12F), 0.86F);
      WIDGET_BG_TOP = Color.getHSBColor(f, f3, 0.16F);
      WIDGET_BG_BOT = Color.getHSBColor(f, f3, 0.2F);
      WIDGET_BORDER_TOP = Color.getHSBColor(f, f3, 0.24F);
      WIDGET_BORDER_BOT = Color.getHSBColor(f, f3, 0.15F);
      LOGO_TEXT = Color.getHSBColor(f, Math.min(1.0F, f2 * 0.3F), 1.0F);
      SCROLLBAR_THUMB = Color.getHSBColor(f, f3 * 0.5F, 0.3F);
      y = C = Color.getHSBColor(f, Math.min(1.0F, f2 * 0.93F), 0.83F);
      A = withAlpha(C, 100);
      D = Color.getHSBColor(f, Math.min(1.0F, f2), 0.71F);
      c = C;
      z = Color.getHSBColor(f, Math.min(1.0F, f2 * 1.1F), 0.68F);
      Q = B = Color.getHSBColor(f, Math.min(1.0F, f2 * 0.85F), 0.94F);
      Y = Color.getHSBColor(f, Math.min(1.0F, f2 * 0.85F), 1.0F);
      R = Color.getHSBColor(f, Math.min(1.0F, f2), 0.71F);
      E = Color.getHSBColor(f, Math.min(1.0F, f2 * 0.8F), 0.34F);
      N = Color.getHSBColor(f, f3 * 0.5F, 0.51F);
      P = Color.getHSBColor(f, f3 * 0.5F, 0.33F);
      b = Color.getHSBColor(f, Math.min(1.0F, f2 * 0.5F), 0.35F);
      d = Color.getHSBColor(f, Math.min(1.0F, f2 * 0.5F), 0.43F);
      float f4 = f3 * 0.5F;
      pryrvd.f = Color.getHSBColor(f, f4, 0.067F);
      e = g = Color.getHSBColor(f, f4, 0.086F);
      x = h = Color.getHSBColor(f, f4, 0.071F);
      i = Color.getHSBColor(f, f4, 0.118F);
      k = j = Color.getHSBColor(f, f4, 0.098F);
      l = Color.getHSBColor(f, f4, 0.078F);
      o = Color.getHSBColor(f, f4, 0.082F);
      p = Color.getHSBColor(f, f4, 0.118F);
      s = Color.getHSBColor(f, f3, 0.2F);
      t = Color.getHSBColor(f, f4, 0.11F);
      u = Color.getHSBColor(f, f4, 0.137F);
      v = Color.getHSBColor(f, f4, 0.086F);
      m = Color.getHSBColor(f, f4, 0.122F);
      n = Color.getHSBColor(f, f4, 0.098F);
      q = Color.getHSBColor(f, f4, 0.106F);
      r = Color.getHSBColor(f, f3, 0.157F);
      I = n;
      K = Color.getHSBColor(f, f4, 0.078F);
      J = Color.getHSBColor(f, f4, 0.086F);
      G = Color.getHSBColor(f, f3 * 0.4F, 0.165F);
      V = Color.getHSBColor(f, f4, 0.094F);
      F = Color.getHSBColor(f, f4, 0.055F);
      S = Color.getHSBColor(f, f4, 0.059F);
      T = Color.getHSBColor(f, f4, 0.071F);
      FriendsPanel = p;
      FriendCard = Color.BLACK;
      ad = new Color(0, 0, 0, 125);
      a = new Color(223, 223, 243);
      aa = Color.WHITE;
      w = new Color(255, 255, 255, 13);
      H = new Color(0, 0, 0, 55);
   }

   public static Color b(Color color, float f) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, Math.min(255, (int)(color.getAlpha() * f))));
   }

   public static Color b(Color color, int n) {
      int n2 = color.getRed();
      int n3 = Math.min(255, (n2 ^ n) + 2 * (n2 & n));
      int n4 = color.getGreen();
      return new Color(n3, Math.min(255, 2 * (n4 | n) - (n4 ^ n)), Math.min(255, color.getBlue() - ~n - 1), color.getAlpha());
   }

   public static Color c(Color color, int n) {
      int n2 = Math.max(0, color.getRed() - n);
      int n3 = color.getGreen();
      int n4 = Math.max(0, (n3 ^ n) - 2 * (~n3 & n));
      int n5 = color.getBlue();
      return new Color(n2, n4, Math.max(0, (n5 ^ n) - 2 * (~n5 & n)), color.getAlpha());
   }

   public static Color a(Color color, int n) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, Math.min(255, n)));
   }

   public static Color a(Color color, float f) {
      return a(color, (int)(255.0F * f));
   }

   static {
      update(new Color(255, 155, 35));
   }
}
