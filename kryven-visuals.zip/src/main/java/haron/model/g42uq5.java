package haron.model;

public class g42uq5 {
   public yur0a9 b;
   public qvj2pe[] a = new qvj2pe[6];
   public yur0a9 c = new yur0a9(0.0F, 0.0F, 0.0F);
   public yur0a9 d = new yur0a9(0.0F, 0.0F, 0.0F);
   public float e = 0.0F;
   public boolean f = false;

   public g42uq5(float f, float f2, float f3) {
      this.b = new yur0a9(f, f2, f3);
   }
}
