package haron.cosmetic;

import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelPart;

public final class WheelchairCosmeticModel {
   public static final Identifier TEXTURE = Identifier.of("haron", "textures/cosmetics/cosmetic_wheelchair.png");
   private static final float GROUND = 24.0F;
   public static final float SEAT_H = 11.0F;
   private final ModelPart root = createModelData().createModel();
   private final ModelPart leftWheel = this.root.getChild("left_wheel");
   private final ModelPart rightWheel = this.root.getChild("right_wheel");

   public void render(MatrixStack matrixStack, VertexConsumer vertexConsumer, int n, int n2) {
      this.root.render(matrixStack, vertexConsumer, n, n2);
   }

   private static void seat(ModelPartData modelPartData) {
      modelPartData.addChild(
         "seat",
         ModelPartBuilder.create()
            .uv(64, 64)
            .cuboid(-5.5F, y(11.0F), -6.0F, 11.0F, 1.5F, 10.0F)
            .uv(64, 64)
            .cuboid(-5.5F, y(21.0F), 2.5F, 11.0F, 10.0F, 1.5F)
            .uv(0, 0)
            .cuboid(-7.5F, y(6.0F) - 0.6F, 0.9F, 15.0F, 1.2F, 1.2F)
            .uv(64, 0)
            .cuboid(-5.0F, y(9.5F), -13.5F, 10.0F, 1.2F, 4.5F),
         ModelTransform.NONE
      );
   }

   private static void wheel(ModelPartData modelPartData, String string, float f, float f2, float f3) {
      ModelPartData modelPartData2 = modelPartData.addChild(
         string, ModelPartBuilder.create().uv(64, 0).cuboid(-1.6F, -1.6F, -1.6F, 3.2F, 3.2F, 3.2F), ModelTransform.pivot(f, f2, f3)
      );
      float f4 = 12.0F * MathHelper.sin((float) (Math.PI / 8));
      float f5 = 6.0F * MathHelper.cos((float) (Math.PI / 8));

      for (int i = 0; i < 4; i++) {
         modelPartData2.addChild(
            $sf$2(i),
            ModelPartBuilder.create()
               .uv(64, 0)
               .cuboid(-0.6F, -6.0F, -0.6F, 1.2F, 12.0F, 1.2F)
               .uv(0, 64)
               .cuboid(-1.1F, -f5 - 0.65F, -f4 / 2.0F, 2.2F, 1.3F, f4)
               .uv(0, 64)
               .cuboid(-1.1F, f5 - 0.65F, -f4 / 2.0F, 2.2F, 1.3F, f4),
            ModelTransform.rotation(i * (float) Math.PI / 4.0F, 0.0F, 0.0F)
         );
      }
   }

   private static void sideFrame(ModelPartData modelPartData, String string, float f) {
      float f2 = 6.2F;
      modelPartData.addChild(
         $sf$1(string),
         ModelPartBuilder.create()
            .uv(0, 0)
            .cuboid(f * 6.2F - 0.75F, y(16.0F), -5.0F, 1.5F, 1.5F, 9.0F)
            .uv(0, 0)
            .cuboid(f * 6.2F - 0.6F, y(16.0F), 2.5F, 1.2F, 5.0F, 1.2F)
            .uv(0, 0)
            .cuboid(f * 4.6F - 0.6F, y(9.5F), -5.0F, 1.2F, 5.5F, 7.0F)
            .uv(0, 0)
            .cuboid(f * 4.6F - 0.6F, y(9.5F), -13.0F, 1.2F, 1.2F, 8.0F),
         ModelTransform.NONE
      );
   }

   public static TexturedModelData createModelData() {
      ModelData modelData = new ModelData();
      ModelPartData modelPartData = modelData.getRoot();
      seat(modelPartData);

      for (int i = 0; i < 2; i++) {
         boolean bl = i == 0;
         String string = bl ? "left" : "right";
         float f = bl ? 1.0F : -1.0F;
         sideFrame(modelPartData, string, f);
         wheel(modelPartData, $sf$0(string), f * 7.5F, y(6.0F), 1.5F);
      }

      return TexturedModelData.of(modelData, 128, 128);
   }

   public void setAngles(float f) {
      float f2;
      this.leftWheel.pitch = f2 = -f * 0.75F;
      this.rightWheel.pitch = f2;
   }

   private static float y(float f) {
      return 24.0F - f;
   }

   private static String $sf$0(String string) {
      return string + "_wheel";
   }

   private static String $sf$1(String string) {
      return string + "_frame";
   }

   private static String $sf$2(int n) {
      return "spoke" + n;
   }
}
