package haron.cosmetic;

import haron.modules.visuals.Cosmetics;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.util.Arm;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.util.math.RotationAxis;

public final class CosmeticRenderer {
   private static final float SIT_DROP = 0.0625F;
   private static RabbitCosmeticModel rabbit;
   private static WheelchairCosmeticModel wheelchair;
   private static Cosmetics module;
   private static boolean worldPass;

   private static boolean active() {
      Cosmetics xjw3p82 = module();
      return xjw3p82 != null && xjw3p82.k();
   }

   public static void render(PlayerEntityRenderState playerEntityRenderState, MatrixStack matrixStack, VertexConsumerProvider vertexConsumerProvider, int n) {
      RabbitCosmeticModel ekqa5y2 = rabbitModel();
      float f = module() == null ? 1.0F : module().scale();
      matrixStack.push();
      matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F - playerEntityRenderState.bodyYaw));
      matrixStack.scale(-f, -f, f);
      matrixStack.translate(0.0F, -1.501F / f, 0.0F);
      ekqa5y2.setAngles(playerEntityRenderState);
      boolean bl = trimSelf() && isSelf(playerEntityRenderState);
      ekqa5y2.firstPersonTrim(bl);
      ekqa5y2.render(matrixStack, vertexConsumerProvider.getBuffer(RenderLayer.getEntityCutoutNoCull(RabbitCosmeticModel.TEXTURE)), n, OverlayTexture.DEFAULT_UV);
      ekqa5y2.firstPersonTrim(false);
      if (!bl) {
         renderHeld(ekqa5y2, playerEntityRenderState.leftHandItemState, Arm.LEFT, matrixStack, vertexConsumerProvider, n);
         renderHeld(ekqa5y2, playerEntityRenderState.rightHandItemState, Arm.RIGHT, matrixStack, vertexConsumerProvider, n);
      }

      matrixStack.pop();
   }

   public static WheelchairCosmeticModel wheelchairModel() {
      int n = 314;
      return wheelchair;
   }

   public static boolean firstPerson() {
      return MinecraftClient.getInstance().options.getPerspective().isFirstPerson();
   }

   public static boolean firstPersonBody() {
      return firstPerson() && active() && module().isFirstPersonBody();
   }

   public static RabbitCosmeticModel rabbitModel() {
      int n = 902;
      return rabbit;
   }

   public static boolean isSelf(PlayerEntityRenderState playerEntityRenderState) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      return minecraftClient.player != null && playerEntityRenderState.id == minecraftClient.player.getId();
   }

   public static void renderArm(Arm arm, MatrixStack matrixStack, VertexConsumerProvider vertexConsumerProvider, int n) {
      RabbitCosmeticModel ekqa5y2 = rabbitModel();
      ekqa5y2.resetArm(arm);
      ekqa5y2.arm(arm).roll = arm == Arm.LEFT ? -0.1F : 0.1F;
      ekqa5y2.arm(arm)
         .render(matrixStack, vertexConsumerProvider.getBuffer(RenderLayer.getEntityCutoutNoCull(RabbitCosmeticModel.TEXTURE)), n, OverlayTexture.DEFAULT_UV);
   }

   public static void worldPass(boolean bl) {
      worldPass = bl;
   }

   public static boolean trimSelf() {
      return worldPass && firstPerson();
   }

   private static void renderHeld(
      RabbitCosmeticModel ekqa5y2, ItemRenderState itemRenderState, Arm arm, MatrixStack matrixStack, VertexConsumerProvider vertexConsumerProvider, int n
   ) {
      if (!itemRenderState.isEmpty()) {
         matrixStack.push();
         ekqa5y2.applyArmTransform(arm, matrixStack);
         matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0F));
         matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F));
         matrixStack.translate(arm == Arm.LEFT ? -1.0F : 0.0625F, 0.125F, -0.625F);
         itemRenderState.render(matrixStack, vertexConsumerProvider, n, OverlayTexture.DEFAULT_UV);
         matrixStack.pop();
      }
   }

   public static boolean shouldSit(PlayerEntityRenderState playerEntityRenderState) {
      return active() && module().wheelchair() && !playerEntityRenderState.invisible && isSelf(playerEntityRenderState);
   }

   public static float sitDrop() {
      return 0.0625F;
   }

   public static boolean shouldReplaceArm() {
      return active() && module().rabbit();
   }

   public static void renderChair(PlayerEntityRenderState playerEntityRenderState, MatrixStack matrixStack, VertexConsumerProvider vertexConsumerProvider, int n) {
      WheelchairCosmeticModel h1f1ug2 = wheelchairModel();
      matrixStack.push();
      matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F - playerEntityRenderState.bodyYaw));
      matrixStack.scale(-1.0F, -1.0F, 1.0F);
      matrixStack.translate(0.0F, -1.501F, 0.0F);
      h1f1ug2.setAngles(playerEntityRenderState.limbFrequency);
      h1f1ug2.render(matrixStack, vertexConsumerProvider.getBuffer(RenderLayer.getEntityCutoutNoCull(WheelchairCosmeticModel.TEXTURE)), n, OverlayTexture.DEFAULT_UV);
      matrixStack.pop();
   }

   private CosmeticRenderer() {
   }

   private static Cosmetics module() {
      return module;
   }

   public static boolean shouldReplace(PlayerEntityRenderState playerEntityRenderState) {
      return active() && module().rabbit() && !playerEntityRenderState.invisible && isSelf(playerEntityRenderState);
   }
}
