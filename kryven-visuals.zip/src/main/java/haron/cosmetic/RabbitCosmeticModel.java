package haron.cosmetic;

import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelPart;

public final class RabbitCosmeticModel {
   public static final Identifier TEXTURE = Identifier.of("haron", "textures/cosmetics/cosmetic_rabbit.png");
   private final ModelPart root = createModelData().createModel();
   private final ModelPart body = this.root.getChild("body");
   private final ModelPart head = this.root.getChild("head");
   private final ModelPart leftEar = this.head.getChild("left_ear");
   private final ModelPart rightEar = this.head.getChild("right_ear");
   private final ModelPart leftArm = this.root.getChild("left_arm");
   private final ModelPart rightArm = this.root.getChild("right_arm");
   private final ModelPart leftLeg = this.root.getChild("left_leg");
   private final ModelPart rightLeg = this.root.getChild("right_leg");
   private final ModelPart tail = this.body.getChild("tail");

   public void render(MatrixStack matrixStack, VertexConsumer vertexConsumer, int n, int n2) {
      this.root.render(matrixStack, vertexConsumer, n, n2);
   }

   private void holdPose(ModelPart modelPart, boolean bl, float f) {
      if (bl) {
         modelPart.pitch = modelPart.pitch * 0.5F - 0.31F;
         modelPart.yaw = 0.0F;
         modelPart.roll = f * 0.08F;
      }
   }

   private void swingArm(PlayerEntityRenderState playerEntityRenderState) {
      float f = playerEntityRenderState.handSwingProgress;
      if (!(f <= 0.0F)) {
         ModelPart modelPart = playerEntityRenderState.preferredArm == Arm.LEFT ? this.leftArm : this.rightArm;
         this.body.yaw = MathHelper.sin(MathHelper.sqrt(f) * (float) (Math.PI * 2)) * 0.2F;
         float f2 = 1.0F - f;
         f2 *= f2;
         f2 *= f2;
         f2 = 1.0F - f2;
         float f3 = MathHelper.sin(f2 * (float) Math.PI);
         float f4 = MathHelper.sin(f * (float) Math.PI) * -(this.head.pitch - 0.7F) * 0.75F;
         modelPart.pitch -= f3 * 1.2F + f4;
         modelPart.yaw = modelPart.yaw + this.body.yaw * 2.0F;
         modelPart.roll = modelPart.roll + MathHelper.sin(f * (float) Math.PI) * -0.4F;
         ModelPart modelPart2 = modelPart == this.leftArm ? this.rightArm : this.leftArm;
         modelPart2.yaw = modelPart2.yaw + this.body.yaw * 2.0F;
      }
   }

   public static TexturedModelData createModelData() {
      ModelData modelData = new ModelData();
      ModelPartData modelPartData2 = modelData.getRoot();
      ModelPartData modelPartData3 = modelPartData2.addChild(
         "body", ModelPartBuilder.create().uv(0, 0).cuboid(-4.0F, 0.0F, -2.5F, 8.0F, 11.0F, 5.0F), ModelTransform.pivot(0.0F, 0.0F, 0.0F)
      );
      modelPartData3.addChild(
         "tail", ModelPartBuilder.create().uv(32, 0).cuboid(-2.5F, 6.0F, 2.5F, 5.0F, 5.0F, 3.0F), ModelTransform.NONE
      );
      modelPartData3.addChild(
         "belly", ModelPartBuilder.create().uv(32, 0).cuboid(-3.0F, 2.0F, -3.0F, 6.0F, 8.0F, 0.6F), ModelTransform.NONE
      );
      ModelPartData modelPartData4 = modelPartData2.addChild(
         "head", ModelPartBuilder.create().uv(0, 0).cuboid(-4.0F, -7.0F, -4.0F, 8.0F, 7.0F, 8.0F), ModelTransform.pivot(0.0F, 0.0F, 0.0F)
      );
      modelPartData4.addChild(
         "muzzle", ModelPartBuilder.create().uv(32, 0).cuboid(-3.0F, -3.5F, -8.0F, 6.0F, 3.5F, 4.0F), ModelTransform.NONE
      );
      modelPartData4.addChild(
         "nose", ModelPartBuilder.create().uv(32, 32).cuboid(-1.2F, -3.1F, -8.6F, 2.4F, 1.8F, 0.6F), ModelTransform.NONE
      );
      modelPartData4.addChild(
         "right_eye", ModelPartBuilder.create().uv(0, 32).cuboid(-3.4F, -6.0F, -4.5F, 1.8F, 1.8F, 0.6F), ModelTransform.NONE
      );
      modelPartData4.addChild(
         "left_eye", ModelPartBuilder.create().uv(0, 32).cuboid(1.6F, -6.0F, -4.5F, 1.8F, 1.8F, 0.6F), ModelTransform.NONE
      );

      for (String string : new String[]{"left", "right"}) {
         float f = string.equals("left") ? 2.2F : -2.2F;
         ModelPartData modelPartData = modelPartData4.addChild(
            $sf$0(string),
            ModelPartBuilder.create().uv(0, 0).cuboid(-1.5F, -9.0F, -1.0F, 3.0F, 9.0F, 2.0F),
            ModelTransform.pivot(f, -6.0F, 0.0F)
         );
         modelPartData.addChild(
            "inner", ModelPartBuilder.create().uv(32, 32).cuboid(-1.0F, -8.5F, -1.3F, 2.0F, 7.5F, 0.5F), ModelTransform.NONE
         );
      }

      for (String string : new String[]{"left", "right"}) {
         boolean bl = string.equals("left");
         ModelPartData modelPartData = modelPartData2.addChild(
            $sf$1(string),
            ModelPartBuilder.create().uv(0, 0).mirrored(bl).cuboid(-2.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F),
            ModelTransform.pivot(bl ? 5.0F : -5.0F, 2.0F, 0.0F)
         );
         modelPartData.addChild(
            "paw", ModelPartBuilder.create().uv(32, 0).mirrored(bl).cuboid(-2.25F, 6.5F, -2.25F, 4.5F, 4.0F, 4.5F), ModelTransform.NONE
         );
      }

      for (String string : new String[]{"left", "right"}) {
         boolean bl = string.equals("left");
         ModelPartData modelPartData = modelPartData2.addChild(
            $sf$2(string),
            ModelPartBuilder.create().uv(0, 0).mirrored(bl).cuboid(-2.0F, 0.0F, -2.5F, 4.0F, 13.0F, 5.0F),
            ModelTransform.pivot(bl ? 2.0F : -2.0F, 11.0F, 0.0F)
         );
         modelPartData.addChild(
            "foot", ModelPartBuilder.create().uv(32, 0).mirrored(bl).cuboid(-2.0F, 11.0F, -6.0F, 4.0F, 2.0F, 8.0F), ModelTransform.NONE
         );
      }

      return TexturedModelData.of(modelData, 64, 64);
   }

   public void setAngles(PlayerEntityRenderState playerEntityRenderState) {
      float f = playerEntityRenderState.limbFrequency;
      float f2 = Math.min(playerEntityRenderState.limbAmplitudeMultiplier, 1.0F);
      float f3 = playerEntityRenderState.age;
      this.root.setPivot(0.0F, 0.0F, 0.0F);
      this.root.setAngles(0.0F, 0.0F, 0.0F);
      this.body.setPivot(0.0F, 0.0F, 0.0F);
      this.body.setAngles(0.0F, 0.0F, 0.0F);
      this.head.setPivot(0.0F, 0.0F, 0.0F);
      this.leftArm.setPivot(5.0F, 2.0F, 0.0F);
      this.rightArm.setPivot(-5.0F, 2.0F, 0.0F);
      this.head.yaw = playerEntityRenderState.yawDegrees * (float) (Math.PI / 180.0);
      this.head.pitch = playerEntityRenderState.pitch * (float) (Math.PI / 180.0);
      float f4 = f * 0.6662F;
      this.rightLeg.pitch = MathHelper.cos(f4) * 1.15F * f2;
      this.leftLeg.pitch = MathHelper.cos(f4 + (float) Math.PI) * 1.15F * f2;
      this.rightArm.pitch = MathHelper.cos(f4 + (float) Math.PI) * 0.85F * f2;
      this.leftArm.pitch = MathHelper.cos(f4) * 0.85F * f2;
      this.rightArm.roll = 0.08F;
      this.leftArm.roll = -0.08F;
      float f5 = Math.abs(MathHelper.sin(f4)) * f2;
      this.root.pivotY = -f5 * 1.6F;
      float f6 = MathHelper.sin(f3 * 0.07F) * 0.06F;
      float f7 = MathHelper.cos(f4 - 0.9F) * 0.4F * f2;
      this.rightEar.pitch = -0.22F + f6 + f7;
      this.leftEar.pitch = -0.22F - f6 + f7;
      this.rightEar.roll = -0.2F - f6;
      this.leftEar.roll = 0.2F + f6;
      this.tail.pitch = MathHelper.sin(f3 * 0.2F) * 0.08F;
      this.holdPose(this.rightArm, !playerEntityRenderState.rightHandItemState.isEmpty(), 1.0F);
      this.holdPose(this.leftArm, !playerEntityRenderState.leftHandItemState.isEmpty(), -1.0F);
      this.swingArm(playerEntityRenderState);
      if (playerEntityRenderState.isInSneakingPose) {
         this.body.pitch = 0.42F;
         this.root.pivotY += 2.5F;
         this.head.pivotY = 3.4F;
         this.head.pivotZ = -1.6F;
         this.rightArm.pitch += 0.4F;
         this.leftArm.pitch += 0.4F;
         this.rightLeg.pivotZ = 3.0F;
         this.leftLeg.pivotZ = 3.0F;
         this.rightLeg.pivotY = 8.5F;
         this.leftLeg.pivotY = 8.5F;
      } else {
         this.rightLeg.setPivot(-2.0F, 11.0F, 0.0F);
         this.leftLeg.setPivot(2.0F, 11.0F, 0.0F);
      }
   }

   public ModelPart arm(Arm arm) {
      return arm == Arm.LEFT ? this.leftArm : this.rightArm;
   }

   public void resetArm(Arm arm) {
      int n = 840;
      ModelPart modelPart = this.arm(arm);
      modelPart.resetTransform();
      modelPart.visible = true;
   }

   public void applyArmTransform(Arm arm, MatrixStack matrixStack) {
      this.root.rotate(matrixStack);
      this.arm(arm).rotate(matrixStack);
   }

   public void firstPersonTrim(boolean bl) {
      this.root.visible = !bl;
   }

   private static String $sf$0(String string) {
      return string + "_ear";
   }

   private static String $sf$1(String string) {
      return string + "_arm";
   }

   private static String $sf$2(String string) {
      return string + "_leg";
   }
}
