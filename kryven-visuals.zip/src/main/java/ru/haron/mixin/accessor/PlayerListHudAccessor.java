package ru.haron.mixin.accessor;

import net.minecraft.text.Text;
import net.minecraft.client.gui.hud.PlayerListHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(PlayerListHud.class)
public interface PlayerListHudAccessor {
   @Accessor("footer")
   Text getFooter();

   @Accessor("visible")
   void setVisible(boolean var1);

   @Accessor("visible")
   boolean isVisible();

   @Accessor("header")
   Text getHeader();
}
