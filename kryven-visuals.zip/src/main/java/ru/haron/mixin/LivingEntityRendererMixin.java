package ru.haron.mixin;

import haron.events.EventDispatcher;
import haron.events.LivingEntityModelRenderEvent;
import haron.module.ModuleManager;
import haron.modules.visuals.SelfNametag;
import haron.render.SelfNametagRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.util.Formatting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.text.MutableText;
import net.minecraft.text.TextColor;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin<T extends LivingEntity, S extends LivingEntityRenderState, M extends EntityModel<? super S>> extends EntityRenderer<T, S> {
   @Shadow
   protected M model;
   private static LivingEntity capturedEntity;

   protected LivingEntityRendererMixin() {
      super((EntityRendererFactory.Context)null);
   }

   @Inject(
      method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
      at = @At("HEAD")
   )
   private void captureEntity(T t, S s, float f, CallbackInfo callbackInfo) {
      capturedEntity = t;
   }

   @Inject(
      method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/entity/LivingEntityRenderer;shouldRenderFeatures(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;)Z"
      )
   )
   private void onRenderEntity(S s, MatrixStack MatrixStackVar, VertexConsumerProvider VertexConsumerProviderVar, int i, CallbackInfo callbackInfo) {
      EventDispatcher.EVENT_BUS.post(new LivingEntityModelRenderEvent(capturedEntity, s, MatrixStackVar, this.model, VertexConsumerProviderVar));
   }

   @Inject(method = "render", at = @At("TAIL"))
   private void renderSelfNametag(S s, MatrixStack MatrixStackVar, VertexConsumerProvider VertexConsumerProviderVar, int i, CallbackInfo callbackInfo) {
      if (s instanceof PlayerEntityRenderState playerState) {
         MinecraftClient client = MinecraftClient.getInstance();
         if (client.player != null) {
            if (playerState.id == client.player.getId()) {
               if (ModuleManager.SELF_NAMETAG.k()) {
                  if (!client.options.getPerspective().isFirstPerson()) {
                     if (!(playerState.squaredDistanceToCamera >= 4096.0)) {
                        SelfNametag selfNametag = ModuleManager.SELF_NAMETAG;
                        boolean showHP = selfNametag.showHP.a();
                        MutableText nameLine = Text.literal(playerState.name);
                        PlayerListEntry entry;
                        if (client.getNetworkHandler() != null
                           && (entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid())) != null
                           && entry.getDisplayName() != null) {
                           nameLine = entry.getDisplayName().copy();
                        }

                        float hp = client.player.getHealth();
                        int hpInt = Math.round(hp);
                        MatrixStackVar.push();
                        SelfNametagRenderState.isSelfNametagRender = true;
                        float sneakOffset = client.player.isSneaking() ? 0.15F : 0.0F;
                        MatrixStackVar.translate(0.0, 0.22 - sneakOffset, 0.0);
                        super.renderLabelIfPresent(s, nameLine, MatrixStackVar, VertexConsumerProviderVar, i);
                        if (showHP) {
                           MatrixStackVar.translate(0.0, -0.22, 0.0);
                           MutableText hpLine = Text.literal(hpInt + " Здоровье")
                              .styled(style -> style.withColor(TextColor.fromFormatting(Formatting.RED)));
                           super.renderLabelIfPresent(s, hpLine, MatrixStackVar, VertexConsumerProviderVar, i);
                        }

                        SelfNametagRenderState.isSelfNametagRender = false;
                        MatrixStackVar.pop();
                     }
                  }
               }
            }
         }
      }
   }
}
