package ru.haron.mixin;

import haron.module.ModuleManager;
import haron.modules.visuals.RenderTweaks;
import haron.modules.visuals.TimeChanger;
import haron.modules.visuals.WorldCustomizer;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ColorHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public abstract class ClientWorldMixin {
   @Inject(method = "getSkyColor", at = @At("HEAD"), cancellable = true)
   private void onGetSkyColor(Vec3d Vec3dVar, float f, CallbackInfoReturnable<Integer> callbackInfoReturnable) {
      WorldCustomizer worldCustomizer = ModuleManager.WORLD_CUSTOMIZER;
      if (worldCustomizer.r()) {
         callbackInfoReturnable.setReturnValue(worldCustomizer.t());
      } else {
         RenderTweaks renderTweaks = ModuleManager.RENDER_TWEAKS;
         if (renderTweaks.n()) {
            float fMax = Math.max(0.0F, Math.min(1.0F, (float)(1.0 - Math.cos(((ClientWorld)(Object)this).getSkyAngle(f) * Math.PI * 2.0) * 2.0 + 0.5)));
            callbackInfoReturnable.setReturnValue(ColorHelper.fromFloats(1.0F, 0.7529412F * fMax, 0.84705883F * fMax, 1.0F * fMax));
         }
      }
   }

   @Inject(method = "getCloudsColor", at = @At("HEAD"), cancellable = true)
   private void onGetCloudsColor(float f, CallbackInfoReturnable<Integer> callbackInfoReturnable) {
      if (ModuleManager.RENDER_TWEAKS.n()) {
         float fMax = Math.max(0.0F, Math.min(1.0F, (float)(Math.cos(((ClientWorld)(Object)this).getSkyAngle(f) * Math.PI * 2.0) * 2.0 + 0.5))) * 0.9F + 0.1F;
         callbackInfoReturnable.setReturnValue(ColorHelper.fromFloats(1.0F, fMax, fMax, fMax * 0.85F + 0.15F));
      }
   }

   @Inject(method = "getLightningTicksLeft", at = @At("HEAD"), cancellable = true)
   private void onGetLightningTicks(CallbackInfoReturnable<Integer> callbackInfoReturnable) {
      if (ModuleManager.RENDER_TWEAKS.n()) {
         callbackInfoReturnable.setReturnValue(0);
      }
   }

   @Inject(method = "getSkyBrightness", at = @At("HEAD"), cancellable = true)
   private void onGetSkyBrightness(float f, CallbackInfoReturnable<Float> callbackInfoReturnable) {
      TimeChanger timeChanger = ModuleManager.TIME_CHANGER;
      if (timeChanger.k()) {
         callbackInfoReturnable.setReturnValue(
            (
                     1.0F
                        - Math.max(
                           0.0F,
                           Math.min(1.0F, 1.0F - (float)(Math.cos(((ClientWorld)(Object)this).getDimension().getSkyAngle(timeChanger.n()) * Math.PI * 2.0) * 2.0 + 0.2))
                        )
                  )
                  * 0.8F
               + 0.2F
         );
      }
   }

   @Inject(method = "getStarBrightness", at = @At("HEAD"), cancellable = true)
   private void onGetStarBrightness(float f, CallbackInfoReturnable<Float> callbackInfoReturnable) {
      TimeChanger timeChanger = ModuleManager.TIME_CHANGER;
      if (timeChanger.k()) {
         float fMax = Math.max(
            0.0F, Math.min(1.0F, 1.0F - (float)(Math.cos(((ClientWorld)(Object)this).getDimension().getSkyAngle(timeChanger.n()) * Math.PI * 2.0) * 2.0 + 0.25))
         );
         callbackInfoReturnable.setReturnValue(fMax * fMax * 0.5F);
      }
   }
}
