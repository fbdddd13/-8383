package ru.haron.mixin;

import haron.events.EventDispatcher;
import haron.events.PlayerJoinedEvent;
import haron.events.PlayerLeftEvent;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class PlayerListMixin {
   @Unique
   private static final ConcurrentHashMap<UUID, String> uuidToNameCache = new ConcurrentHashMap<>();

   @Inject(method = "onPlayerList", at = @At("HEAD"))
   private void onPlayerListUpdate(PlayerListS2CPacket PlayerListS2CPacketVar, CallbackInfo callbackInfo) {
      for (PlayerListS2CPacket.Entry entryVar : PlayerListS2CPacketVar.getEntries()) {
         UUID uuidProfileId = entryVar.profileId();
         if (PlayerListS2CPacketVar.getActions().contains(PlayerListS2CPacket.Action.ADD_PLAYER)
            && entryVar.profile() != null
            && entryVar.profile().getName() != null) {
            String name = entryVar.profile().getName();
            if (!uuidToNameCache.containsKey(uuidProfileId)) {
               uuidToNameCache.put(uuidProfileId, name);
               EventDispatcher.EVENT_BUS.post(new PlayerJoinedEvent(name, uuidProfileId));
            }
         }

         if (PlayerListS2CPacketVar.getActions().contains(PlayerListS2CPacket.Action.UPDATE_LISTED) && !entryVar.listed()) {
            String str = uuidToNameCache.get(uuidProfileId);
            if (str != null) {
               EventDispatcher.EVENT_BUS.post(new PlayerLeftEvent(str, uuidProfileId));
               uuidToNameCache.remove(uuidProfileId);
            } else {
               EventDispatcher.EVENT_BUS.post(new PlayerLeftEvent("", uuidProfileId));
            }
         }
      }
   }

   @Inject(method = "onGameJoin", at = @At("HEAD"))
   private void onGameJoin(GameJoinS2CPacket GameJoinS2CPacketVar, CallbackInfo callbackInfo) {
      uuidToNameCache.clear();
   }
}
