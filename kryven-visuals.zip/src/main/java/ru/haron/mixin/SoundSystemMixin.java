package ru.haron.mixin;

import haron.events.EventDispatcher;
import haron.events.SoundPlayEvent;
import haron.util.sound.k9fqgt;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(SoundSystem.class)
public class SoundSystemMixin {
   @ModifyVariable(method = "play(Lnet/minecraft/client/sound/SoundInstance;)V", at = @At("HEAD"), argsOnly = true)
   private SoundInstance modifySound(SoundInstance SoundInstanceVar) {
      if (SoundInstanceVar != null && !(SoundInstanceVar instanceof k9fqgt)) {
         SoundPlayEvent soundPlayEvent = new SoundPlayEvent(SoundInstanceVar);
         EventDispatcher.EVENT_BUS.post(soundPlayEvent);
         if (soundPlayEvent.c()) {
            return null;
         } else {
            return soundPlayEvent.e() != 1.0F ? new k9fqgt(SoundInstanceVar, soundPlayEvent.e()) : SoundInstanceVar;
         }
      } else {
         return SoundInstanceVar;
      }
   }
}
