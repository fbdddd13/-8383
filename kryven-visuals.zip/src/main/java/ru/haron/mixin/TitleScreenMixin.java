package ru.haron.mixin;

import haron.gui.menu.HaronTitleScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public class TitleScreenMixin {
   @Inject(method = "init", at = @At("TAIL"))
   private void onInit(CallbackInfo callbackInfo) {
      MinecraftClient client = MinecraftClient.getInstance();
      client.execute(() -> {
         if (client.currentScreen instanceof TitleScreen) {
            client.setScreen(new HaronTitleScreen());
         }
      });
   }
}
