package ru.haron;

import haron.config.LocalConfigManager;
import haron.gui.core.ClickGuiKeybind;
import haron.gui.core.ClickGuiScreen;
import haron.hud.core.HudServices;
import haron.module.ModuleManager;
import haron.player.HaronPlayerTracker;
import haron.render.ShaderShapeRenderer;
import haron.render.ShapeRenderer;
import haron.render.icons.HaronIcons;
import haron.render.shader.DefaultShaders;
import java.util.concurrent.ThreadFactory;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.ClientStopping;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.minecraft.client.gui.screen.Screen;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Kryven implements Runnable, ThreadFactory, ClientModInitializer {
   public static final String CLIENT_VERSION = "1.0.0";
   private static final String TELEGRAM_BOT_URL = "leak by somik";
   private static final String TELEGRAM_CHANNEL_URL = "leak by somik";
   public static final String CLIENT_NAME = "Kryven";
   private static final Logger LOGGER = LogManager.getLogger("leak by somik");
   private static final Kryven instance = new Kryven();
   private ShapeRenderer render;
   private Screen clickGui;
   private boolean init = false;

   public void onInitializeClient() {
      HaronPlayerTracker.get().init();
      ClickGuiKeybind.register();
      ClientPlayConnectionEvents.DISCONNECT.register((clientPlayNetworkHandler, minecraftClient) -> {
         LOGGER.info("[Kryven] Disconnect — saving config");
         LocalConfigManager.get().flushSaveNow("disconnect");
      });
      ClientLifecycleEvents.CLIENT_STOPPING.register(minecraftClient -> {
         LOGGER.info("[Kryven] Client stop — saving config");
         LocalConfigManager.get().flushSaveNow("client-stop");
      });
      LOGGER.info("Kryven initialized");
   }

   public static String getBackendUrl() {
      return "leak by somik";
   }

   public static String getDirectApiUrl() {
      return "leak by somik";
   }

   public ShapeRenderer getRender() {
      int n = 110;
      return this.render;
   }

   public static String getMainUrl() {
      return "leak by somik";
   }

   public static Logger getLOGGER() {
      return LOGGER;
   }

   public Screen getClickGui() {
      return this.clickGui;
   }

   @Override
   public void run() {
   }

   public static Kryven getInstance() {
      return instance;
   }

   public void init() {
      HaronIcons.load();
      DefaultShaders.loadDefaultShaders();
      this.render = new ShaderShapeRenderer();
      HudServices.initialize();
      ModuleManager.init();
      LOGGER.info("[Kryven] Loading config (dir: {})", LocalConfigManager.get().configDirectory());

      try {
         LocalConfigManager.get().init();
         LOGGER.info("[Kryven] Config load finished");
      } catch (Exception exception) {
         LOGGER.warn("[Kryven] Config load failed", exception);
      }

      this.clickGui = new ClickGuiScreen();
      this.init = true;
      LOGGER.info("Kryven Java GUI initialized");
   }

   @Override
   public Thread newThread(Runnable runnable) {
      return null;
   }
}
