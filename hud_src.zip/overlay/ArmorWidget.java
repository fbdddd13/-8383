package hud.overlay;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.collection.DefaultedList;
import client.api.event.events.render.Render2DEvent;
import hud.HudStyle;
import hud.Widget;

public class ArmorWidget
extends Widget {
    private final List<ItemStack> items = new ArrayList<ItemStack>();

    public ArmorWidget() {
        super(30.0f, 100.0f);
    }

    @Override
    public String getName() {
        return "Armor";
    }

    @Override
    public void render(Render2DEvent.Render2DEventData event) {
        MatrixStack matrixStack = event.matrixStack();
        DrawContext context = event.context();
        this.updateItems();
        if (this.items.isEmpty()) {
            return;
        }
        float x = this.getDraggable().getX();
        float y = this.getDraggable().getY();
        float itemSize = this.scaled(12.0f);
        float gap = this.scaled(2.5f);
        float padding = this.scaled(2.5f);
        float barHeight = this.scaled(1.2f);
        float barSpace = this.scaled(2.0f);
        float cell = itemSize + barSpace;
        int count = this.items.size();
        float longSide = itemSize * (float)count + gap * (float)(count - 1) + padding * 2.0f;
        float shortSide = cell + padding * 2.0f;
        int screenWidth = mc.getWindow().getScaledWidth();
        float threshold = longSide + gap;
        boolean isVertical = x < threshold || x > (float)screenWidth - threshold;
        float width = isVertical ? itemSize + padding * 2.0f : longSide;
        float height = isVertical ? cell * (float)count + gap * (float)(count - 1) + padding * 2.0f : shortSide;
        HudStyle.panel(matrixStack, x, y, width, height, 255);

        float currentX = x + padding;
        float currentY = y + padding;
        for (ItemStack item : this.items) {
            HudStyle.item(context, item, currentX, currentY, itemSize);
            float durability = HudStyle.durability(item);
            if (durability >= 0.0f) {
                float barWidth = itemSize - this.scaled(2.0f);
                HudStyle.bar(matrixStack, currentX + this.scaled(1.0f), currentY + itemSize + this.scaled(1.0f), barWidth, barHeight, durability, HudStyle.durability(durability, 255), 255);
            }
            if (isVertical) {
                currentY += cell + gap;
            } else {
                currentX += itemSize + gap;
            }
        }
        this.getDraggable().setWidth(width);
        this.getDraggable().setHeight(height);
    }

    private void updateItems() {
        this.items.clear();
        if (mc.player == null) {
            return;
        }
        ClientPlayerEntity player = mc.player;
        DefaultedList<ItemStack> armor = player.getInventory().armor;
        for (int i = armor.size() - 1; i >= 0; --i) {
            this.items.add(armor.get(i));
        }
    }

    @Override
    public void render(MatrixStack matrixStack) {
    }
}
