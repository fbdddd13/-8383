package hud.overlay;

import java.awt.Color;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import client.api.event.events.render.Render2DEvent;
import client.api.system.draggable.Draggable;
import client.api.utils.animation.AnimationUtil;
import client.api.utils.animation.Easing;
import client.api.utils.color.UIColors;
import client.api.utils.render.RenderUtil;
import client.client.features.modules.render.InterfaceModule;
import hud.HudEditor;
import hud.HudIcon;
import hud.HudStyle;
import hud.Widget;

public class NotificationsWidget
extends Widget {
    private static final List<Notification> NOTIFICATIONS = new CopyOnWriteArrayList<Notification>();
    private static final ItemStack TOTEM = new ItemStack((ItemConvertible)Items.TOTEM_OF_UNDYING);
    private static final long LIFETIME = 3000L;
    private static final int MAX = 5;
    private final Notification[] previews = new Notification[]{
        new Notification("AttackAura", "Включён", Type.ENABLE),
        new Notification("Player", "Сломан тотем · -3", Type.TOTEM)
    };
    private final AnimationUtil previewAnimation = new AnimationUtil();

    public NotificationsWidget() {
        super(defaultX(), 40.0f);
    }

    private static float defaultX() {
        if (mc.getWindow() == null) {
            return 200.0f;
        }
        return (float)mc.getWindow().getScaledWidth() / 2.0f - 60.0f;
    }

    @Override
    public String getName() {
        return "Notifications";
    }

    public static void push(String title, String subtitle, Type type) {
        Notification notification = new Notification(title, subtitle, type);
        notification.show.run(1.0, 220L, Easing.CUBIC_OUT);
        NOTIFICATIONS.add(notification);
        while (NOTIFICATIONS.size() > MAX) {
            NOTIFICATIONS.remove(0);
        }
    }

    private float cardWidth() {
        return this.scaled(120.0f);
    }

    private boolean compact() {
        return InterfaceModule.getInstance().compactNotifications.getValue();
    }

    private float cardHeight() {
        return this.scaled(this.compact() ? 13.0f : 20.0f);
    }

    @Override
    public List<HudEditor.MenuOption> getMenuOptions() {
        InterfaceModule settings = InterfaceModule.getInstance();
        return List.of(
            new HudEditor.MenuOption("Карточки", () -> !settings.compactNotifications.getValue(), () -> settings.compactNotifications.setValue(false), true),
            new HudEditor.MenuOption("Полоска", () -> settings.compactNotifications.getValue(), () -> settings.compactNotifications.setValue(true), true)
        );
    }

    private float cardGap() {
        return this.scaled(3.5f);
    }

    @Override
    public void render(Render2DEvent.Render2DEventData event) {
        MatrixStack ms = event.matrixStack();
        DrawContext context = event.context();
        float step = this.cardHeight() + this.cardGap();
        boolean editing = mc.currentScreen instanceof ChatScreen;
        this.previewAnimation.update();
        this.previewAnimation.run(editing ? 1.0 : 0.0, 220L, Easing.CUBIC_OUT);
        float preview = (float)this.previewAnimation.getValue();

        Draggable draggable = this.getDraggable();
        float center = draggable.getX() + (draggable.getWidth() > 0.0f ? draggable.getWidth() : this.cardWidth()) / 2.0f;
        float width = this.boxWidth(preview > 0.01f ? List.of(this.previews) : NOTIFICATIONS, draggable.getWidth());
        float x = center - width / 2.0f;
        float y = draggable.getY();
        draggable.setX(x);

        if (preview > 0.01f) {
            int alpha = (int)(preview * 255.0f);
            float frameHeight = step * (float)this.previews.length - this.cardGap();
            float slide = this.scaled(6.0f) * (1.0f - preview);
            float offset = 0.0f;
            for (Notification card : this.previews) {
                this.drawCard(ms, context, card, x, y + offset - slide, width, alpha, 0.6f);
                offset += step;
            }
            this.getDraggable().setWidth(width);
            this.getDraggable().setHeight(frameHeight);
        }

        long now = System.currentTimeMillis();
        float offset = 0.0f;
        int realAlpha = (int)((1.0f - preview) * 255.0f);
        for (Notification notification : NOTIFICATIONS) {
            notification.show.update();
            notification.slot.update();
            if (now - notification.created > LIFETIME && !notification.leaving) {
                notification.leaving = true;
                notification.show.run(0.0, 220L, Easing.CUBIC_OUT);
            }
            if (notification.leaving && notification.show.getValue() <= 0.01) {
                NOTIFICATIONS.remove(notification);
                continue;
            }
            if (!notification.placed) {
                notification.slot.setValue(offset);
                notification.placed = true;
            }
            notification.slot.run(offset, 180L, Easing.CUBIC_OUT);
            float anim = (float)notification.show.getValue();
            float slide = this.scaled(6.0f) * (1.0f - anim);
            float progress = 1.0f - Math.min(1.0f, (float)(now - notification.created) / (float)LIFETIME);
            int alpha = (int)(anim * (float)realAlpha);
            if (alpha > 2) {
                this.drawCard(ms, context, notification, x, y + (float)notification.slot.getValue() - slide, width, alpha, progress);
            }
            offset += step * anim;
        }
        if (preview <= 0.01f) {
            this.getDraggable().setWidth(width);
            this.getDraggable().setHeight(Math.max(this.cardHeight(), offset - this.cardGap()));
        }
    }

    private float boxWidth(List<Notification> list, float current) {
        if (!this.compact()) {
            return this.cardWidth();
        }
        float width = 0.0f;
        for (Notification notification : list) {
            width = Math.max(width, this.stripWidth(notification));
        }
        if (width <= 0.0f) {
            return current > 0.0f ? current : this.cardWidth();
        }
        return width;
    }

    private float stripWidth(Notification notification) {
        float font = this.scaled(5.8f);
        String text = notification.title + " " + notification.subtitle.toLowerCase();
        return Math.min(this.cardWidth(), this.scaled(4.5f) * 2.0f + this.scaled(7.0f) + this.scaled(3.5f) + this.getMediumFont().getWidth(text, font));
    }

    private void drawCard(MatrixStack ms, DrawContext context, Notification notification, float x, float y, float width, int alpha, float progress) {
        if (this.compact()) {
            this.drawStrip(ms, context, notification, x, y, width, alpha, progress);
            return;
        }
        float height = this.cardHeight();
        float pad = this.scaled(4.0f);
        float iconBox = this.scaled(12.0f);
        float iconSize = this.scaled(7.0f);
        float titleFont = this.scaled(6.0f);
        float subFont = this.scaled(5.2f);
        float textGap = this.scaled(1.2f);
        HudStyle.panel(ms, x, y, width, height, alpha);

        Color color = notification.type.color();
        float boxX = x + pad;
        float boxCenter = y + height / 2.0f;
        RenderUtil.RECT.draw(ms, boxX, boxCenter - iconBox / 2.0f, iconBox, iconBox, this.scaled(2.5f), HudStyle.alpha(new Color(color.getRed(), color.getGreen(), color.getBlue(), 40), alpha));
        float iconX = boxX + iconBox / 2.0f - iconSize / 2.0f;
        if (notification.type.icon == null) {
            if (alpha > 150) {
                HudStyle.item(context, TOTEM, iconX, boxCenter - iconSize / 2.0f, iconSize);
            }
        } else {
            notification.type.icon.draw(ms, iconX, boxCenter, iconSize, HudStyle.alpha(color, alpha));
        }

        float textX = boxX + iconBox + this.scaled(4.0f);
        float textTop = boxCenter - (titleFont + subFont + textGap) / 2.0f;
        this.getMediumFont().drawText(ms, notification.title, textX, textTop, titleFont, UIColors.textColor(alpha));
        this.getMediumFont().drawText(ms, notification.subtitle, textX, textTop + titleFont + textGap, subFont, UIColors.inactiveTextColor(alpha));

        float lineHeight = this.scaled(1.0f);
        RenderUtil.RECT.draw(ms, x + HudStyle.round() / 2.0f, y + height - lineHeight, (width - HudStyle.round()) * progress, lineHeight, 0.0f, UIColors.primary(alpha));
    }

    private void drawStrip(MatrixStack ms, DrawContext context, Notification notification, float x, float y, float width, int alpha, float progress) {
        float height = this.cardHeight();
        float pad = this.scaled(4.5f);
        float iconSize = this.scaled(7.0f);
        float font = this.scaled(5.8f);
        float gap = this.scaled(3.5f);
        String title = notification.title;
        String subtitle = " " + notification.subtitle.toLowerCase();
        float titleWidth = this.getMediumFont().getWidth(title, font);
        float stripWidth = Math.min(width, this.stripWidth(notification));
        float stripX = x + (width - stripWidth) / 2.0f;
        float center = y + height / 2.0f;
        HudStyle.panel(ms, stripX, y, stripWidth, height, alpha);
        Color color = notification.type.color();
        float iconX = stripX + pad;
        if (notification.type.icon == null) {
            if (alpha > 150) {
                HudStyle.item(context, TOTEM, iconX, center - iconSize / 2.0f, iconSize);
            }
        } else {
            notification.type.icon.draw(ms, iconX, center, iconSize, HudStyle.alpha(color, alpha));
        }
        float textX = iconX + iconSize + gap;
        this.getMediumFont().drawText(ms, title, textX, HudStyle.textY(center, font), font, UIColors.textColor(alpha));
        this.getMediumFont().drawText(ms, subtitle, textX + titleWidth, HudStyle.textY(center, font), font, UIColors.inactiveTextColor(alpha));
        float lineHeight = this.scaled(0.8f);
        RenderUtil.RECT.draw(ms, stripX + HudStyle.round() / 2.0f, y + height - lineHeight, (stripWidth - HudStyle.round()) * progress, lineHeight, 0.0f, HudStyle.alpha(color, alpha));
    }

    @Override
    public void render(MatrixStack matrixStack) {
    }

    public static enum Type {
        ENABLE(HudIcon.TOGGLE_ON),
        DISABLE(HudIcon.TOGGLE_OFF),
        TOTEM(null);

        private final HudIcon icon;

        private Type(HudIcon icon) {
            this.icon = icon;
        }

        public Color color() {
            return switch (this) {
                case ENABLE -> UIColors.positiveColor();
                case DISABLE -> UIColors.negativeColor();
                case TOTEM -> new Color(242, 201, 76);
            };
        }
    }

    private static final class Notification {
        private final String title;
        private final String subtitle;
        private final Type type;
        private final long created = System.currentTimeMillis();
        private final AnimationUtil show = new AnimationUtil();
        private final AnimationUtil slot = new AnimationUtil();
        private boolean leaving;
        private boolean placed;

        private Notification(String title, String subtitle, Type type) {
            this.title = title;
            this.subtitle = subtitle;
            this.type = type;
        }
    }
}
