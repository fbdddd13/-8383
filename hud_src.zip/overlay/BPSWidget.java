package hud.overlay;

import java.util.List;
import net.minecraft.entity.Entity;
import client.api.utils.math.MathUtil;
import client.client.features.modules.render.InterfaceModule;
import hud.HudEditor;
import hud.HudIcon;
import hud.InformationWidget;
import hud.Widget;
import hud.WidgetManager;

public class BPSWidget
extends InformationWidget {
    @Override
    public String getName() {
        return "BPS";
    }

    public BPSWidget() {
        super(80.0f, 120.0f);
    }

    static String bps() {
        return String.format("%.2f", MathUtil.getEntityBPS((Entity)mc.player));
    }

    @Override
    public String getValue() {
        return bps();
    }

    @Override
    public HudIcon getIcon() {
        return HudIcon.GAUGE;
    }

    @Override
    public String getUnit() {
        return "b/s";
    }

    @Override
    protected boolean isHidden() {
        if (!InterfaceModule.getInstance().mergeInfo.getValue()) {
            return false;
        }
        for (Widget widget : WidgetManager.getInstance().getWidgets()) {
            if (widget instanceof XYZWidget && widget.isEnabled()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public List<HudEditor.MenuOption> getMenuOptions() {
        return List.of(XYZWidget.mergeOption());
    }
}
