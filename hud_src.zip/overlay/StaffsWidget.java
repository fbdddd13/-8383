package hud.overlay;

import java.awt.Color;
import hud.HudIcon;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import lombok.Generated;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.Team;
import net.minecraft.world.GameMode;
import client.api.system.configs.StaffManager;
import client.api.utils.color.UIColors;
import client.api.utils.framelimiter.FrameLimiter;
import client.api.utils.other.ReplaceUtil;
import client.api.utils.player.PlayerUtil;
import hud.ContainerWidget;

public class StaffsWidget
extends ContainerWidget {
    private final FrameLimiter frameLimiter = new FrameLimiter(false);
    private List<Staff> cacheStaffs = new ArrayList<Staff>();

    @Override
    public String getName() {
        return "Staffs";
    }

    public StaffsWidget() {
        super(100.0f, 100.0f);
    }

    @Override
    protected HudIcon getHeaderIcon() {
        return HudIcon.SHIELD;
    }

    @Override
    protected String getHeaderExtra() {
        return this.cacheStaffs.isEmpty() ? null : String.valueOf(this.cacheStaffs.size());
    }

    @Override
    protected Map<String, ContainerWidget.ContainerElement.ColoredString> getCurrentData() {
        HashMap<String, ContainerWidget.ContainerElement.ColoredString> map = new HashMap<String, ContainerWidget.ContainerElement.ColoredString>();
        for (Staff staff : this.getStaffList()) {
            Color color = switch (staff.status().ordinal()) {
                default -> throw new MatchException(null, null);
                case 0 -> UIColors.positiveColor();
                case 1 -> UIColors.middleColor();
                case 2, 3 -> UIColors.negativeColor();
            };
            String label = staff.status().getLabel();
            map.put(staff.name(), new ContainerWidget.ContainerElement.ColoredString(label, color).dot(color));
        }
        return map;
    }

    private List<Staff> getStaffList() {
        this.frameLimiter.execute(15, () -> {
            ArrayList<Staff> list = new ArrayList<Staff>();
            if (!mc.isInSingleplayer()) {
                list.addAll(this.getOnlineStaff());
                list.addAll(this.getVanishedPlayers());
            }
            this.cacheStaffs = list;
        });
        return this.cacheStaffs;
    }

    private List<Staff> getOnlineStaff() {
        ArrayList<Staff> staff = new ArrayList<Staff>();
        if (StaffsWidget.mc.player == null || StaffsWidget.mc.player.networkHandler == null || StaffsWidget.mc.world == null) {
            return staff;
        }
        for (PlayerListEntry player : StaffsWidget.mc.player.networkHandler.getPlayerList()) {
            String name;
            Team team = player.getScoreboardTeam();
            if (team == null || !PlayerUtil.isValidName(name = player.getProfile().getName())) continue;
            String prefix = ReplaceUtil.replaceSymbols(team.getPrefix().getString());
            if (!StaffManager.getInstance().contains(name) && !this.isStaffPrefix(prefix.toLowerCase())) continue;
            Status status = Status.ONLINE;
            if (player.getGameMode() == GameMode.SPECTATOR) {
                status = Status.GM3;
            } else if (StaffsWidget.mc.world.getPlayers().stream().anyMatch(p -> p.getGameProfile().getName().equals(name))) {
                status = Status.NEAR;
            }
            staff.add(new Staff(prefix + " " + name, status));
        }
        return staff;
    }

    private List<Staff> getVanishedPlayers() {
        ArrayList<Staff> vanished = new ArrayList<Staff>();
        if (StaffsWidget.mc.world == null || StaffsWidget.mc.world.getScoreboard() == null || mc.getNetworkHandler() == null) {
            return vanished;
        }
        HashSet<String> onlineNames = new HashSet<String>();
        for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
            onlineNames.add(entry.getProfile().getName());
        }
        for (Team team : StaffsWidget.mc.world.getScoreboard().getTeams()) {
            for (String name : team.getPlayerList()) {
                if (!PlayerUtil.isValidName(name) || onlineNames.contains(name)) continue;
                vanished.add(new Staff(name, Status.VANISH));
            }
        }
        return vanished;
    }

    private boolean isStaffPrefix(String prefix) {
        return prefix.contains("helper") || prefix.contains("moder") || prefix.contains("admin") || prefix.contains("owner") || prefix.contains("developer") || prefix.contains("staff") || prefix.contains("curator") || prefix.contains("куратор") || prefix.contains("разраб") || prefix.contains("модер") || prefix.contains("админ") || prefix.contains("стажер") || prefix.contains("стажёр") || prefix.contains("хелпер");
    }

    public record Staff(String name, Status status) {
    }

    public static enum Status {
        ONLINE("Online"),
        NEAR("Near"),
        GM3("Gm3"),
        VANISH("Vanish");

        private final String label;

        @Generated
        public String getLabel() {
            return this.label;
        }

        @Generated
        private Status(String label) {
            this.label = label;
        }
    }
}
