package hud.overlay;

import java.util.List;
import client.client.features.modules.render.InterfaceModule;
import hud.HudEditor;
import hud.HudIcon;
import hud.InformationWidget;

public class XYZWidget
extends InformationWidget {
    @Override
    public String getName() {
        return "XYZ";
    }

    public XYZWidget() {
        super(30.0f, 120.0f);
    }

    @Override
    public String getValue() {
        String x = String.format("%.1f", XYZWidget.mc.player.getX());
        String y = String.format("%.1f", XYZWidget.mc.player.getY());
        String z = String.format("%.1f", XYZWidget.mc.player.getZ());
        return x + "  " + y + "  " + z;
    }

    @Override
    public HudIcon getIcon() {
        return HudIcon.MAP_PIN;
    }

    @Override
    protected List<Segment> getSegments() {
        Segment coords = new Segment(HudIcon.MAP_PIN, this.getValue(), "");
        if (!InterfaceModule.getInstance().mergeInfo.getValue()) {
            return List.of(coords);
        }
        return List.of(coords, new Segment(HudIcon.GAUGE, BPSWidget.bps(), "b/s"));
    }

    @Override
    public List<HudEditor.MenuOption> getMenuOptions() {
        return List.of(mergeOption());
    }

    static HudEditor.MenuOption mergeOption() {
        InterfaceModule settings = InterfaceModule.getInstance();
        return new HudEditor.MenuOption("Объединить XYZ и BPS", () -> settings.mergeInfo.getValue(), () -> settings.mergeInfo.setValue(!settings.mergeInfo.getValue()), false);
    }
}
