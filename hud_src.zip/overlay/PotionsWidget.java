package hud.overlay;

import hud.HudIcon;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Identifier;
import net.minecraft.util.Language;
import client.api.utils.color.ColorUtil;
import client.api.utils.color.UIColors;
import client.api.utils.other.TextUtil;
import hud.ContainerWidget;

public class PotionsWidget
extends ContainerWidget {
    private static final Identifier[] BAD_EFFECTS = new Identifier[]{Identifier.of((String)"minecraft", (String)"wither"), Identifier.of((String)"minecraft", (String)"poison"), Identifier.of((String)"minecraft", (String)"slowness"), Identifier.of((String)"minecraft", (String)"weakness"), Identifier.of((String)"minecraft", (String)"mining_fatigue"), Identifier.of((String)"minecraft", (String)"nausea"), Identifier.of((String)"minecraft", (String)"blindness"), Identifier.of((String)"minecraft", (String)"hunger"), Identifier.of((String)"minecraft", (String)"levitation"), Identifier.of((String)"minecraft", (String)"unluck")};
    private static final Identifier[] COOL_EFFECTS = new Identifier[]{Identifier.of((String)"minecraft", (String)"speed"), Identifier.of((String)"minecraft", (String)"strength"), Identifier.of((String)"minecraft", (String)"regeneration")};

    public PotionsWidget() {
        super(3.0f, 120.0f);
    }

    @Override
    public String getName() {
        return "Potions";
    }

    @Override
    protected HudIcon getHeaderIcon() {
        return HudIcon.FLASK;
    }

    @Override
    protected Map<String, ContainerWidget.ContainerElement.ColoredString> getCurrentData() {
        HashMap<String, ContainerWidget.ContainerElement.ColoredString> map = new HashMap<String, ContainerWidget.ContainerElement.ColoredString>();
        for (StatusEffectInstance effect : PotionsWidget.mc.player.getActiveStatusEffects().values()) {
            Identifier id = ((RegistryKey)effect.getEffectType().getKey().get()).getValue();
            Color textColor = UIColors.textColor();
            Color miss_you = this.isBadEffect(id) ? ColorUtil.flashingColor(UIColors.negativeColor(), textColor) : (this.isCoolEffect(id) ? ColorUtil.flashingColor(UIColors.positiveColor(), textColor) : UIColors.textColor());
            String level = effect.getAmplifier() > 0 ? " " + (effect.getAmplifier() + 1) : "";
            String name = Language.getInstance().get(effect.getTranslationKey()) + level;
            String durationText = TextUtil.getDurationText(effect.getDuration());
            map.put(name, new ContainerWidget.ContainerElement.ColoredString(durationText, miss_you).effect(effect.getEffectType()));
        }
        return map;
    }

    private boolean isBadEffect(Identifier id) {
        for (Identifier badId : BAD_EFFECTS) {
            if (!badId.equals((Object)id)) continue;
            return true;
        }
        return false;
    }

    private boolean isCoolEffect(Identifier id) {
        for (Identifier coolId : COOL_EFFECTS) {
            if (!coolId.equals((Object)id)) continue;
            return true;
        }
        return false;
    }
}
