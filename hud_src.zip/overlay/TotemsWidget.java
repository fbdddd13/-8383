package hud.overlay;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import client.api.event.events.render.Render2DEvent;
import client.api.utils.color.UIColors;
import hud.HudStyle;
import hud.Widget;

public class TotemsWidget
extends Widget {
    private static final ItemStack TOTEM = new ItemStack((ItemConvertible)Items.TOTEM_OF_UNDYING);

    public TotemsWidget() {
        super(160.0f, 100.0f);
    }

    @Override
    public String getName() {
        return "Totems";
    }

    @Override
    public void render(Render2DEvent.Render2DEventData event) {
        if (mc.player == null) {
            return;
        }
        MatrixStack ms = event.matrixStack();
        DrawContext context = event.context();
        float x = this.getDraggable().getX();
        float y = this.getDraggable().getY();
        int count = this.countTotems();
        String text = String.valueOf(count);
        float pad = this.scaled(4.0f);
        float itemSize = this.scaled(10.0f);
        float fontSize = this.scaled(6.5f);
        float height = itemSize + pad * 2.0f;
        float width = pad * 2.0f + itemSize + this.scaled(3.0f) + this.getSemiBoldFont().getWidth(text, fontSize);
        HudStyle.panel(ms, x, y, width, height, 255);
        HudStyle.item(context, TOTEM, x + pad, y + pad, itemSize);
        this.getSemiBoldFont().drawText(ms, text, x + pad + itemSize + this.scaled(3.0f), HudStyle.textY(y + height / 2.0f, fontSize), fontSize, count == 0 ? HudStyle.RED : UIColors.textColor());
        this.getDraggable().setWidth(width);
        this.getDraggable().setHeight(height);
    }

    private int countTotems() {
        int count = 0;
        for (int i = 0; i < mc.player.getInventory().size(); ++i) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                count += stack.getCount();
            }
        }
        return count;
    }

    @Override
    public void render(MatrixStack matrixStack) {
    }
}
