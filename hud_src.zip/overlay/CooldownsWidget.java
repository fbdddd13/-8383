package hud.overlay;

import java.util.HashMap;
import hud.HudIcon;
import java.util.Map;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import client.api.utils.other.TextUtil;
import hud.ContainerWidget;

public class CooldownsWidget
extends ContainerWidget {
    @Override
    public String getName() {
        return "Cooldowns";
    }

    public CooldownsWidget() {
        super(120.0f, 100.0f);
    }

    @Override
    protected Map<String, ContainerWidget.ContainerElement.ColoredString> getCurrentData() {
        HashMap<String, ContainerWidget.ContainerElement.ColoredString> cooldownData = new HashMap<String, ContainerWidget.ContainerElement.ColoredString>();
        if (CooldownsWidget.mc.player == null) {
            return cooldownData;
        }
        ItemCooldownManager manager = CooldownsWidget.mc.player.getItemCooldownManager();
        float tickDelta = mc.getRenderTickCounter().getTickDelta(false);
        for (int i = 0; i < CooldownsWidget.mc.player.getInventory().size(); ++i) {
            int remaining;
            ItemStack stack = CooldownsWidget.mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            Item item = stack.getItem();
            if (!manager.isCoolingDown(stack) || (remaining = this.getRemainingCooldownTicks(stack, tickDelta)) <= 0) continue;
            String name = item.getName().getString();
            String time = remaining >= 1200 ? TextUtil.getDurationText(remaining) : String.format("%.1fs", (float)remaining / 20.0f);
            cooldownData.put(name, new ContainerWidget.ContainerElement.ColoredString(time).item(stack).progress(this.getProgress(stack, remaining)));
        }
        return cooldownData;
    }

    @Override
    protected HudIcon getHeaderIcon() {
        return HudIcon.HOURGLASS;
    }

    private float getProgress(ItemStack stack, int remaining) {
        ItemCooldownManager manager = CooldownsWidget.mc.player.getItemCooldownManager();
        ItemCooldownManager.Entry entry = (ItemCooldownManager.Entry)manager.entries.get(manager.getGroup(stack));
        if (entry == null || entry.endTick() <= entry.startTick()) {
            return 0.0f;
        }
        return (float)remaining / (float)(entry.endTick() - entry.startTick());
    }

    private int getRemainingCooldownTicks(ItemStack stack, float tickDelta) {
        ItemCooldownManager manager = CooldownsWidget.mc.player.getItemCooldownManager();
        Identifier groupId = manager.getGroup(stack);
        ItemCooldownManager.Entry entry = (ItemCooldownManager.Entry)manager.entries.get(groupId);
        if (entry != null) {
            return Math.max(0, entry.endTick() - (manager.tick + (int)tickDelta));
        }
        return 0;
    }
}
