package hud.overlay;

import hud.HudIcon;
import client.api.utils.color.UIColors;
import java.util.HashMap;
import java.util.Map;
import client.api.module.Module;
import client.api.module.ModuleManager;
import client.api.system.backend.KeyStorage;
import hud.ContainerWidget;

public class KeybindsWidget
extends ContainerWidget {
    public KeybindsWidget() {
        super(3.0f, 120.0f);
    }

    @Override
    public String getName() {
        return "Keybinds";
    }

    @Override
    protected HudIcon getHeaderIcon() {
        return HudIcon.KEYBOARD;
    }

    @Override
    protected Map<String, ContainerWidget.ContainerElement.ColoredString> getCurrentData() {
        HashMap<String, ContainerWidget.ContainerElement.ColoredString> map = new HashMap<String, ContainerWidget.ContainerElement.ColoredString>();
        for (Module m : ModuleManager.getInstance().getModules()) {
            if (!m.isEnabled() || !m.hasBind()) continue;
            map.put(m.getName(), new ContainerWidget.ContainerElement.ColoredString(KeyStorage.getBind(m.getBind())).dot(UIColors.primary()));
        }
        return map;
    }
}
