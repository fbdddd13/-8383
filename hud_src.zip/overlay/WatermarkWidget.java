package hud.overlay;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import client.api.utils.color.UIColors;
import hud.HudIcon;
import hud.HudStyle;
import hud.Widget;

public class WatermarkWidget
extends Widget {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    @Override
    public String getName() {
        return "Watermark";
    }

    public WatermarkWidget() {
        super(3.0f, 3.0f);
    }

    @Override
    public void render(MatrixStack ms) {
        if (mc.player == null) {
            return;
        }
        float x = this.getDraggable().getX();
        float y = this.getDraggable().getY();
        float height = this.scaled(14.0f);
        float centerY = y + height / 2.0f;
        float fontSize = this.scaled(6.0f);
        float iconSize = this.scaled(7.0f);
        float segPad = this.scaled(5.0f);
        float iconGap = this.scaled(3.0f);
        float logoSize = this.scaled(10.0f);

        String client = this.getClientName();
        String nick = mc.player.getName().getString();
        String fps = String.valueOf(mc.getCurrentFps());
        String ping = String.valueOf(this.getPing());
        String time = LocalTime.now().format(TIME);

        float clientSeg = segPad * 2.0f + logoSize + iconGap + this.getSemiBoldFont().getWidth(client, fontSize);
        float nickSeg = this.segWidth(nick, "", fontSize, segPad, iconSize, iconGap);
        float fpsSeg = this.segWidth(fps, " fps", fontSize, segPad, iconSize, iconGap);
        float pingSeg = this.segWidth(ping, " ms", fontSize, segPad, iconSize, iconGap);
        float timeSeg = this.segWidth(time, "", fontSize, segPad, iconSize, iconGap);
        float width = clientSeg + nickSeg + fpsSeg + pingSeg + timeSeg;

        HudStyle.panel(ms, x, y, width, height, 255);

        float cx = x + segPad;
        HudIcon.LOGO.drawGradient(ms, cx, centerY, logoSize, UIColors.primary(), UIColors.secondary());
        this.getSemiBoldFont().drawText(ms, client, cx + logoSize + iconGap, HudStyle.textY(centerY, fontSize), fontSize, UIColors.textColor());
        cx = x + clientSeg;

        float[] segments = new float[]{nickSeg, fpsSeg, pingSeg, timeSeg};
        HudIcon[] icons = new HudIcon[]{HudIcon.USER, HudIcon.DESKTOP, HudIcon.WIFI, HudIcon.CLOCK};
        String[] values = new String[]{nick, fps, ping, time};
        String[] units = new String[]{"", " fps", " ms", ""};
        for (int i = 0; i < segments.length; ++i) {
            HudStyle.separator(ms, cx, centerY, height, 255);
            float sx = cx + segPad;
            icons[i].draw(ms, sx, centerY, iconSize, UIColors.primary());
            float textX = sx + iconSize + iconGap;
            this.getMediumFont().drawText(ms, values[i], textX, HudStyle.textY(centerY, fontSize), fontSize, UIColors.textColor());
            if (!units[i].isEmpty()) {
                this.getMediumFont().drawText(ms, units[i], textX + this.getMediumFont().getWidth(values[i], fontSize), HudStyle.textY(centerY, fontSize), fontSize, UIColors.inactiveTextColor());
            }
            cx += segments[i];
        }

        this.getDraggable().setWidth(width);
        this.getDraggable().setHeight(height);
    }

    private float segWidth(String value, String unit, float fontSize, float segPad, float iconSize, float iconGap) {
        float unitWidth = unit.isEmpty() ? 0.0f : this.getMediumFont().getWidth(unit, fontSize);
        return segPad * 2.0f + iconSize + iconGap + this.getMediumFont().getWidth(value, fontSize) + unitWidth;
    }

    private int getPing() {
        if (mc.getNetworkHandler() == null) {
            return 0;
        }
        PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return entry == null ? 0 : entry.getLatency();
    }

    private String getClientName() {
        return "Client";
    }
}
