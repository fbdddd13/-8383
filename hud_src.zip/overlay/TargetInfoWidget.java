package hud.overlay;

import java.awt.Color;
import java.time.Duration;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import client.api.event.events.render.Render2DEvent;
import client.api.utils.animation.AnimationUtil;
import client.api.utils.color.ColorUtil;
import client.api.utils.color.UIColors;
import client.api.utils.combat.TotemPopTracker;
import client.api.utils.math.MathUtil;
import client.api.utils.render.RenderUtil;
import client.client.features.modules.combat.aimassist.AimAssistBridge;
import client.client.features.modules.combat.attackaura.AttackAuraModule;
import client.client.features.modules.render.InterfaceModule;
import hud.HudStyle;
import hud.Widget;

public class TargetInfoWidget
extends Widget {
    private static final EquipmentSlot[] ARMOR = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final ItemStack TOTEM = new ItemStack((ItemConvertible)Items.TOTEM_OF_UNDYING);
    private final AnimationUtil showAnimation = new AnimationUtil();
    private float healthAnimation = 0.0f;
    private LivingEntity target;

    @Override
    public String getName() {
        return "Target info";
    }

    public TargetInfoWidget() {
        super(30.0f, 30.0f);
    }

    @Override
    public void render(Render2DEvent.Render2DEventData event) {
        MatrixStack ms = event.matrixStack();
        DrawContext context = event.context();
        this.update();
        LivingEntity pretendTarget = this.getTarget();
        if (pretendTarget != null) {
            this.target = pretendTarget;
        }
        if (this.showAnimation.getValue() <= 0.0 || this.target == null) {
            return;
        }
        this.healthAnimation = MathHelper.clamp((float)MathUtil.interpolate(this.healthAnimation, this.target.getHealth() / this.target.getMaxHealth(), 0.3f), 0.0f, 1.0f);
        float anim = (float)this.showAnimation.getValue();
        int alpha = (int)(anim * 255.0f);
        boolean showItems = anim > 0.6f;
        float x = this.getDraggable().getX();
        float y = this.getDraggable().getY();
        float pad = this.scaled(4.0f);
        float headSize = this.scaled(21.0f);
        float width = this.scaled(104.0f);
        float height = headSize + pad * 2.0f;
        float nameFont = this.scaled(6.5f);
        float smallFont = this.scaled(5.5f);

        HudStyle.panel(ms, x, y, width, height, alpha);

        float headX = x + pad;
        float headY = y + pad;
        LivingEntity living = this.target;
        if (living instanceof PlayerEntity player) {
            RenderUtil.TEXTURE_RECT.drawHead(ms, player, headX, headY, headSize, headSize, this.getGap() / 2.0f, 0.0f, ColorUtil.setAlpha(Color.WHITE, alpha));
        } else {
            float headFont = headSize * 0.7f;
            this.getSemiBoldFont().drawCenteredText(ms, "?", headX + headSize / 2.0f, headY + headSize / 2.0f - headFont / 2.0f, headFont, UIColors.textColor(alpha));
        }

        float left = headX + headSize + this.scaled(4.0f);
        float right = x + width - pad;

        String healthText = String.format("%.1f", this.target.getHealth() + this.target.getAbsorptionAmount());
        float healthWidth = this.getMediumFont().getWidth(healthText, nameFont);
        float nameY = headY;
        this.getMediumFont().drawText(ms, healthText, right - healthWidth, nameY, nameFont, UIColors.primary(alpha));
        this.getMediumFont().drawWrap(ms, this.target.getName().getString(), left, nameY, right - left - healthWidth - this.scaled(4.0f), nameFont, UIColors.textColor(alpha), this.scaled(9.0f), Duration.ofMillis(2500L), Duration.ofMillis(1700L));

        float barY = nameY + nameFont + this.scaled(2.0f);
        float barHeight = this.scaled(1.6f);
        Color barColor1 = UIColors.gradient(0, alpha);
        Color barColor2 = UIColors.gradient(90, alpha);
        RenderUtil.RECT.draw(ms, left, barY, right - left, barHeight, barHeight / 2.0f, HudStyle.alpha(HudStyle.TRACK, alpha));
        RenderUtil.GRADIENT_RECT.draw(ms, left, barY, (right - left) * this.healthAnimation, barHeight, barHeight / 2.0f, barColor1, barColor2, barColor1, barColor2);

        float itemSize = this.scaled(8.0f);
        float itemGap = this.scaled(2.5f);
        float rowY = headY + headSize - itemSize - this.scaled(1.6f);
        float itemX = left;
        for (EquipmentSlot slot : ARMOR) {
            ItemStack stack = this.target.getEquippedStack(slot);
            if (showItems) {
                HudStyle.item(context, stack, itemX, rowY, itemSize);
            }
            float durability = HudStyle.durability(stack);
            if (durability >= 0.0f) {
                HudStyle.bar(ms, itemX, rowY + itemSize + this.scaled(0.6f), itemSize, this.scaled(1.0f), durability, HudStyle.durability(durability, alpha), alpha);
            }
            itemX += itemSize + itemGap;
        }

        float rowCenter = rowY + itemSize / 2.0f;
        float cursor = right;
        if (InterfaceModule.getInstance().targetWinLose.getValue()) {
            boolean win = this.isWinning();
            String text = win ? "Win" : "Lose";
            float textWidth = this.getMediumFont().getWidth(text, smallFont);
            cursor -= textWidth;
            this.getMediumFont().drawText(ms, text, cursor, HudStyle.textY(rowCenter, smallFont), smallFont, win ? UIColors.positiveColor(alpha) : UIColors.negativeColor(alpha));
            cursor -= this.scaled(4.0f);
        }
        if (InterfaceModule.getInstance().targetTotems.getValue()) {
            String text = "-" + TotemPopTracker.getInstance().getPops(this.target);
            float textWidth = this.getSemiBoldFont().getWidth(text, smallFont);
            cursor -= textWidth;
            this.getSemiBoldFont().drawText(ms, text, cursor, HudStyle.textY(rowCenter, smallFont), smallFont, HudStyle.alpha(HudStyle.RED, alpha));
            float totemSize = this.scaled(8.0f);
            cursor -= totemSize + this.scaled(1.0f);
            if (showItems) {
                HudStyle.item(context, TOTEM, cursor, rowCenter - totemSize / 2.0f, totemSize);
            }
        }

        this.getDraggable().setWidth(width);
        this.getDraggable().setHeight(height);
    }

    @Override
    public void render(MatrixStack matrixStack) {
    }

    private boolean isWinning() {
        if (mc.player == null || this.target == mc.player) {
            return true;
        }
        float mine = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        float theirs = this.target.getHealth() + this.target.getAbsorptionAmount();
        return mine >= theirs;
    }

    private void update() {
        this.showAnimation.update();
        this.showAnimation.run(this.getTarget() != null ? 1.0 : 0.0, this.getDuration(), this.getEasing());
    }

    private LivingEntity getTarget() {
        AttackAuraModule aura = AttackAuraModule.getInstance();
        if (aura.isEnabled() && aura.target != null) {
            return aura.target;
        }

        try {
            if (AimAssistBridge.getInstance().isEnabled()) {
                LivingEntity aimTarget = AimAssistBridge.getSharedTarget();
                if (aimTarget != null) {
                    return aimTarget;
                }
            }
        } catch (Throwable ignored) {
        }
        if (mc.currentScreen instanceof ChatScreen) {
            return mc.player;
        }
        return null;
    }
}
