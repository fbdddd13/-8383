package hud;

import java.awt.Color;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import client.api.system.interfaces.QuickImports;
import client.api.utils.color.ColorUtil;
import client.api.utils.color.UIColors;
import client.api.utils.render.RenderUtil;
import client.api.utils.render.fonts.Font;
import client.client.services.RenderService;

public final class HudStyle implements QuickImports {
    public static final Color DIVIDER = new Color(255, 255, 255, 18);
    public static final Color BADGE = new Color(255, 255, 255, 16);
    public static final Color TRACK = new Color(255, 255, 255, 22);
    public static final Color RED = new Color(255, 77, 77);

    private HudStyle() {
    }

    private static float widgetScale = 1.0f;

    public static void setWidgetScale(float scale) {
        widgetScale = scale;
    }

    public static float s(float value) {
        return RenderService.getInstance().scaled(value) * widgetScale;
    }

    public static Color alpha(Color color, int alpha) {
        return ColorUtil.setAlpha(color, (int)((float)color.getAlpha() * (float)alpha / 255.0f));
    }

    public static float round() {
        return s(4.0f);
    }

    public static void panel(MatrixStack ms, float x, float y, float width, float height, int alpha) {
        RenderUtil.BLUR_RECT.draw(ms, x, y, width, height, round(), UIColors.widgetBlur(alpha));
    }

    public static void divider(MatrixStack ms, float x, float y, float width, int alpha) {
        RenderUtil.RECT.draw(ms, x, y, width, s(0.5f), 0.0f, alpha(DIVIDER, alpha));
    }

    public static void separator(MatrixStack ms, float x, float centerY, float height, int alpha) {
        RenderUtil.RECT.draw(ms, x, centerY - height / 2.0f, s(0.5f), height, 0.0f, alpha(DIVIDER, alpha));
    }

    public static void dot(MatrixStack ms, float x, float centerY, float size, Color color) {
        RenderUtil.RECT.draw(ms, x, centerY - size / 2.0f, size, size, size / 2.0f, color);
    }

    public static float textY(float centerY, float size) {
        return centerY - size / 2.0f + size * 0.08f;
    }

    public static float badgeWidth(Font font, String text, float fontSize) {
        return font.getWidth(text, fontSize) + s(2.5f) * 2.0f;
    }

    public static float badge(MatrixStack ms, Font font, String text, float rightX, float centerY, float fontSize, Color textColor, int alpha) {
        float width = badgeWidth(font, text, fontSize);
        float height = fontSize + s(2.0f);
        float x = rightX - width;
        RenderUtil.RECT.draw(ms, x, centerY - height / 2.0f, width, height, s(2.0f), alpha(BADGE, alpha));
        font.drawText(ms, text, x + s(2.5f), centerY - fontSize / 2.0f, fontSize, textColor);
        return width;
    }

    public static void bar(MatrixStack ms, float x, float y, float width, float height, float progress, Color fill, int alpha) {
        float clamped = Math.max(0.0f, Math.min(1.0f, progress));
        RenderUtil.RECT.draw(ms, x, y, width, height, height / 2.0f, alpha(TRACK, alpha));
        if (clamped > 0.0f) {
            RenderUtil.RECT.draw(ms, x, y, width * clamped, height, height / 2.0f, fill);
        }
    }

    public static Color durability(float progress, int alpha) {
        return ColorUtil.interpolate(UIColors.positiveColor(alpha), UIColors.negativeColor(alpha), progress);
    }

    public static float durability(ItemStack stack) {
        if (stack.isEmpty() || !stack.isDamageable() || stack.getMaxDamage() <= 0) {
            return -1.0f;
        }
        return (float)(stack.getMaxDamage() - stack.getDamage()) / (float)stack.getMaxDamage();
    }

    public static void item(DrawContext context, ItemStack stack, float x, float y, float size) {
        if (stack == null || stack.isEmpty()) {
            return;
        }
        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(x, y, 0.0f);
        matrices.scale(size / 16.0f, size / 16.0f, 1.0f);
        context.drawItem(stack, 0, 0);
        matrices.pop();
    }

    public static void effect(DrawContext context, RegistryEntry<StatusEffect> effect, float x, float y, float size) {
        Sprite sprite = mc.getStatusEffectSpriteManager().getSprite(effect);
        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(x, y, 0.0f);
        matrices.scale(size / 18.0f, size / 18.0f, 1.0f);
        context.drawSpriteStretched(RenderLayer::getGuiTextured, sprite, 0, 0, 18, 18);
        matrices.pop();
    }
}
