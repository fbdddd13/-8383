package hud;

import lombok.Generated;
import client.api.event.events.render.Render2DEvent;
import client.api.system.draggable.Draggable;
import client.api.system.draggable.DraggableManager;
import client.api.system.interfaces.IRenderer;
import client.api.system.interfaces.QuickImports;
import client.api.utils.animation.Easing;
import client.api.utils.render.fonts.Font;
import client.api.utils.render.fonts.Fonts;
import client.client.features.modules.render.InterfaceModule;
import client.client.services.RenderService;

public abstract class Widget
implements QuickImports,
IRenderer {
    private final Easing easing = Easing.SINE_OUT;
    private final long duration = 100L;
    private final Draggable draggable;
    private boolean enabled;

    protected Widget(float x, float y) {
        this.draggable = this.create(x, y, this.getName());
    }

    public abstract String getName();

    private Draggable create(float x, float y, String name) {
        return DraggableManager.getInstance().create(InterfaceModule.getInstance(), name, x, y);
    }

    public void render(Render2DEvent.Render2DEventData event) {
        this.render(event.matrixStack());
    }

    public float scaled(float value) {
        return RenderService.getInstance().scaled(value) * this.draggable.getScale();
    }

    public float getScale() {
        return RenderService.getInstance().getScale();
    }

    public java.util.List<HudEditor.MenuOption> getMenuOptions() {
        return java.util.List.of();
    }

    public float getGap() {
        return this.scaled(3.0f);
    }

    public Font getMediumFont() {
        return Fonts.PS_MEDIUM;
    }

    public Font getSemiBoldFont() {
        return Fonts.PS_BOLD;
    }

    @Generated
    public Easing getEasing() {
        return this.easing;
    }

    @Generated
    public long getDuration() {
        return this.duration;
    }

    @Generated
    public Draggable getDraggable() {
        return this.draggable;
    }

    @Generated
    public boolean isEnabled() {
        return this.enabled;
    }

    @Generated
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
