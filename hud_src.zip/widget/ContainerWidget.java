package hud;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import lombok.Generated;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import client.api.event.events.render.Render2DEvent;
import client.api.utils.animation.AnimationUtil;
import client.api.utils.animation.Easing;
import client.api.utils.color.ColorUtil;
import client.api.utils.color.UIColors;
import client.api.utils.render.ScissorUtil;

public abstract class ContainerWidget
extends Widget {
    private final List<ContainerElement> activeElements = new ArrayList<ContainerElement>();
    private final AnimationUtil showAnimation = new AnimationUtil();
    private final AnimationUtil widthAnimation = new AnimationUtil();
    private final AnimationUtil heightAnimation = new AnimationUtil();
    private float width;
    private float height;
    private float containerHeight;

    public ContainerWidget(float x, float y) {
        super(x, y);
    }

    public boolean shouldShow() {
        return this.getActiveElements().stream().anyMatch(e -> e.getAnimation().getValue() > 0.1);
    }

    public List<ContainerElement> containerElements() {
        this.updateActiveElements();
        return this.getActiveElements();
    }

    protected abstract Map<String, ContainerElement.ColoredString> getCurrentData();

    protected boolean shouldKeep(ContainerElement element, Map<String, ContainerElement.ColoredString> currentData) {
        return currentData.containsKey(element.getFirst());
    }

    protected HudIcon getHeaderIcon() {
        return null;
    }

    protected String getHeaderExtra() {
        return null;
    }

    private float pad() {
        return this.scaled(5.0f);
    }

    private float headerHeight() {
        return this.scaled(13.0f);
    }

    private float rowHeight() {
        return this.scaled(9.5f);
    }

    private float iconSize() {
        return this.scaled(7.0f);
    }

    private float barSpace() {
        return this.scaled(3.0f);
    }

    private float headerFont() {
        return this.scaled(6.5f);
    }

    private float rowFont() {
        return this.scaled(6.0f);
    }

    @Override
    public void render(Render2DEvent.Render2DEventData event) {
        MatrixStack matrixStack = event.matrixStack();
        DrawContext context = event.context();
        float x = this.getDraggable().getX();
        float y = this.getDraggable().getY();
        this.widthAnimation.update();
        this.heightAnimation.update();
        this.showAnimation.update();
        this.showAnimation.run(this.shouldShow() || ContainerWidget.mc.currentScreen instanceof ChatScreen ? 1.0 : 0.0, this.getDuration(), this.getEasing());
        float animHeight = (float)this.heightAnimation.getValue();
        float animWidth = (float)this.widthAnimation.getValue();
        int alpha = (int)(this.showAnimation.getValue() * 255.0);
        float pad = this.pad();
        float headerHeight = this.headerHeight();
        float headerFont = this.headerFont();
        float iconSize = this.iconSize();
        float iconGap = this.scaled(3.5f);

        HudStyle.panel(matrixStack, x, y, animWidth, animHeight, alpha);

        float headerCenter = y + headerHeight / 2.0f;
        float headerX = x + pad;
        HudIcon headerIcon = this.getHeaderIcon();
        if (headerIcon != null) {
            headerIcon.draw(matrixStack, headerX, headerCenter, iconSize, UIColors.primary(alpha));
            headerX += iconSize + iconGap;
        }
        this.getMediumFont().drawText(matrixStack, this.getName(), headerX, headerCenter - headerFont / 2.0f, headerFont, UIColors.textColor(alpha));
        float headerWidth = headerX - x + this.getMediumFont().getWidth(this.getName(), headerFont) + pad;
        String extra = this.getHeaderExtra();
        if (extra != null) {
            float extraWidth = this.getMediumFont().getWidth(extra, headerFont);
            this.getMediumFont().drawText(matrixStack, extra, x + animWidth - pad - extraWidth, headerCenter - headerFont / 2.0f, headerFont, UIColors.inactiveTextColor(alpha));
            headerWidth += extraWidth + this.scaled(8.0f);
        }
        this.width = Math.max(this.scaled(78.0f), headerWidth);
        this.containerHeight = 0.0f;
        this.height = headerHeight;

        ScissorUtil.start(matrixStack, x, y, animWidth, animHeight);
        boolean hasElements = false;
        float elementY = y + headerHeight + this.scaled(3.0f);
        float rowHeight = this.rowHeight();
        float rowFont = this.rowFont();
        float rightX = x + animWidth - pad;
        for (ContainerElement element : this.containerElements()) {
            hasElements = true;
            ContainerElement.ColoredString second = element.getSecond();
            float anim = (float)element.getAnimation().getValue();
            float slide = this.scaled(2.0f) * (1.0f - anim);
            int elementAlpha = (int)((double)anim * this.showAnimation.getValue() * 255.0);
            float rowCenter = elementY + rowHeight / 2.0f - slide;
            float rowX = x + pad;
            float leading = 0.0f;
            if (second.item() != null) {
                if (elementAlpha > 150) {
                    HudStyle.item(context, second.item(), rowX, rowCenter - iconSize / 2.0f, iconSize);
                }
                leading = iconSize + iconGap;
            } else if (second.effect() != null) {
                if (elementAlpha > 150) {
                    HudStyle.effect(context, second.effect(), rowX, rowCenter - iconSize / 2.0f, iconSize);
                }
                leading = iconSize + iconGap;
            } else if (second.dot() != null) {
                float dotSize = this.scaled(3.0f);
                HudStyle.dot(matrixStack, rowX, rowCenter, dotSize, ColorUtil.setAlpha(second.dot(), elementAlpha));
                leading = dotSize + iconGap;
            }
            this.getMediumFont().drawText(matrixStack, element.getFirst(), rowX + leading, rowCenter - rowFont / 2.0f, rowFont, UIColors.textColor(elementAlpha));
            float badgeWidth = HudStyle.badge(matrixStack, this.getMediumFont(), second.text(), rightX, rowCenter, rowFont, ColorUtil.setAlpha(second.color(), elementAlpha), elementAlpha);
            float step = rowHeight;
            if (second.progress() >= 0.0f) {
                float barHeight = this.scaled(1.2f);
                HudStyle.bar(matrixStack, rowX, elementY + rowHeight - slide + this.scaled(0.5f), animWidth - pad * 2.0f, barHeight, second.progress(), UIColors.primary(elementAlpha), elementAlpha);
                step += this.barSpace();
            }
            elementY += step * anim;
            if (element.isValid()) {
                this.addHeight(step);
            }
            float rowWidth = pad * 2.0f + leading + this.getMediumFont().getWidth(element.getFirst(), rowFont) + this.scaled(10.0f) + badgeWidth;
            if (rowWidth > this.width) {
                this.width = rowWidth;
            }
        }
        ScissorUtil.stop(matrixStack);
        if (animHeight > headerHeight + 1.0f) {
            HudStyle.divider(matrixStack, x, y + headerHeight, animWidth, alpha);
        }
        if (hasElements) {
            this.height = headerHeight + this.scaled(3.0f) + this.containerHeight + this.scaled(3.0f);
        }
        this.widthAnimation.run(this.width, this.getDuration(), this.getEasing());
        this.heightAnimation.run(this.height, this.getDuration(), this.getEasing());
        this.getDraggable().setWidth((float)this.widthAnimation.getValue());
        this.getDraggable().setHeight((float)this.heightAnimation.getValue());
    }

    @Override
    public void render(MatrixStack matrixStack) {
    }

    public void addHeight(float value) {
        this.containerHeight += value;
    }

    private void updateActiveElements() {
        Easing easing = this.getEasing();
        long duration = this.getDuration();
        for (ContainerElement element : this.activeElements) {
            element.getAnimation().update();
        }
        Map<String, ContainerElement.ColoredString> currentData = this.getCurrentData();
        if (currentData == null) {
            currentData = Collections.emptyMap();
        }
        HashMap<String, ContainerElement> lookup = new HashMap<String, ContainerElement>(this.activeElements.size() * 2 + 1);
        for (ContainerElement containerElement : this.activeElements) {
            lookup.put(containerElement.getFirst(), containerElement);
        }
        for (Map.Entry<String, ContainerElement.ColoredString> entry : currentData.entrySet()) {
            String name = entry.getKey();
            ContainerElement.ColoredString value = entry.getValue();
            ContainerElement element = lookup.get(name);
            if (element == null) {
                ContainerElement newElement = new ContainerElement(name, value);
                newElement.getAnimation().run(1.0, duration, easing);
                this.activeElements.add(newElement);
                lookup.put(name, newElement);
                continue;
            }
            element.setSecond(value);
            element.setValid(true);
        }
        Iterator<ContainerElement> iterator = this.activeElements.iterator();
        while (iterator.hasNext()) {
            ContainerElement containerElement = iterator.next();
            AnimationUtil anim = containerElement.getAnimation();
            if (!this.shouldKeep(containerElement, currentData)) {
                containerElement.setValid(false);
                anim.run(0.0, duration, easing);
                if (!(anim.getValue() <= 0.1)) continue;
                iterator.remove();
                continue;
            }
            if (!containerElement.isValid()) continue;
            anim.run(1.0, duration, easing);
        }
    }

    @Generated
    public List<ContainerElement> getActiveElements() {
        return this.activeElements;
    }

    @Generated
    public AnimationUtil getShowAnimation() {
        return this.showAnimation;
    }

    @Generated
    public float getWidth() {
        return this.width;
    }

    @Generated
    public float getHeight() {
        return this.height;
    }

    public static class ContainerElement {
        private String first;
        private ColoredString second;
        private boolean valid = true;
        private final AnimationUtil animation = new AnimationUtil();

        public ContainerElement(String first, ColoredString second) {
            this.first = first;
            this.second = second;
        }

        @Generated
        public void setFirst(String first) {
            this.first = first;
        }

        @Generated
        public void setSecond(ColoredString second) {
            this.second = second;
        }

        @Generated
        public void setValid(boolean valid) {
            this.valid = valid;
        }

        @Generated
        public String getFirst() {
            return this.first;
        }

        @Generated
        public ColoredString getSecond() {
            return this.second;
        }

        @Generated
        public boolean isValid() {
            return this.valid;
        }

        @Generated
        public AnimationUtil getAnimation() {
            return this.animation;
        }

        public static class ColoredString {
            private final String text;
            private final Color color;
            private ItemStack item;
            private RegistryEntry<StatusEffect> effect;
            private Color dot;
            private float progress = -1.0f;

            public ColoredString(String text, Color color) {
                this.text = text;
                this.color = color;
            }

            public ColoredString(String text) {
                this(text, UIColors.inactiveTextColor());
            }

            public ColoredString item(ItemStack item) {
                this.item = item;
                return this;
            }

            public ColoredString effect(RegistryEntry<StatusEffect> effect) {
                this.effect = effect;
                return this;
            }

            public ColoredString dot(Color dot) {
                this.dot = dot;
                return this;
            }

            public ColoredString progress(float progress) {
                this.progress = progress;
                return this;
            }

            public String text() {
                return this.text;
            }

            public Color color() {
                return this.color;
            }

            public ItemStack item() {
                return this.item;
            }

            public RegistryEntry<StatusEffect> effect() {
                return this.effect;
            }

            public Color dot() {
                return this.dot;
            }

            public float progress() {
                return this.progress;
            }
        }
    }
}
