package hud;

import java.awt.Color;
import net.minecraft.client.util.math.MatrixStack;
import client.api.utils.render.fonts.Fonts;

public enum HudIcon {
    KEYBOARD("a"),
    FLASK("b"),
    SHIELD("c"),
    HOURGLASS("d"),
    USER("e"),
    DESKTOP("f"),
    WIFI("g"),
    CLOCK("h"),
    MAP_PIN("i"),
    GAUGE("j"),
    TOGGLE_ON("k"),
    TOGGLE_OFF("l"),
    LOGO("m");

    private static final float GLYPH_PAD = 6.0f / 64.0f;
    private final String glyph;

    private HudIcon(String glyph) {
        this.glyph = glyph;
    }

    public String getGlyph() {
        return this.glyph;
    }

    public void draw(MatrixStack ms, float x, float centerY, float size, Color color) {
        Fonts.HUD_ICONS.drawText(ms, this.glyph, x - size * GLYPH_PAD, centerY - size / 2.0f, size, color);
    }

    public void drawGradient(MatrixStack ms, float x, float centerY, float size, Color first, Color second) {
        Fonts.HUD_ICONS.drawGradientText(ms, this.glyph, x - size * GLYPH_PAD, centerY - size / 2.0f, size, first, second, size / 2.0f);
    }
}
