package hud;

import java.util.List;
import net.minecraft.client.util.math.MatrixStack;
import client.api.utils.color.UIColors;

public abstract class InformationWidget
extends Widget {
    public InformationWidget(float x, float y) {
        super(x, y);
    }

    public record Segment(HudIcon icon, String value, String unit) {
    }

    protected List<Segment> getSegments() {
        return List.of(new Segment(this.getIcon(), this.getValue(), this.getUnit()));
    }

    protected boolean isHidden() {
        return false;
    }

    @Override
    public void render(MatrixStack matrixStack) {
        if (mc.player == null || this.isHidden()) {
            this.getDraggable().setWidth(0.0f);
            this.getDraggable().setHeight(0.0f);
            return;
        }
        float x = this.getDraggable().getX();
        float y = this.getDraggable().getY();
        float fontSize = this.scaled(6.0f);
        float iconSize = this.scaled(7.0f);
        float pad = this.scaled(5.0f);
        float iconGap = this.scaled(3.5f);
        float height = this.scaled(14.0f);
        float centerY = y + height / 2.0f;
        List<Segment> segments = this.getSegments();
        float[] widths = new float[segments.size()];
        float width = 0.0f;
        for (int i = 0; i < segments.size(); ++i) {
            Segment segment = segments.get(i);
            float w = pad * 2.0f + this.getMediumFont().getWidth(segment.value(), fontSize);
            if (segment.icon() != null) {
                w += iconSize + iconGap;
            }
            if (!segment.unit().isEmpty()) {
                w += this.getMediumFont().getWidth(" " + segment.unit(), fontSize);
            }
            widths[i] = w;
            width += w;
        }
        HudStyle.panel(matrixStack, x, y, width, height, 255);
        float cx = x;
        for (int i = 0; i < segments.size(); ++i) {
            Segment segment = segments.get(i);
            if (i > 0) {
                HudStyle.separator(matrixStack, cx, centerY, height, 255);
            }
            float textX = cx + pad;
            if (segment.icon() != null) {
                segment.icon().draw(matrixStack, textX, centerY, iconSize, UIColors.primary());
                textX += iconSize + iconGap;
            }
            this.getMediumFont().drawText(matrixStack, segment.value(), textX, HudStyle.textY(centerY, fontSize), fontSize, UIColors.textColor());
            if (!segment.unit().isEmpty()) {
                float valueWidth = this.getMediumFont().getWidth(segment.value(), fontSize);
                this.getMediumFont().drawText(matrixStack, " " + segment.unit(), textX + valueWidth, HudStyle.textY(centerY, fontSize), fontSize, UIColors.inactiveTextColor());
            }
            cx += widths[i];
        }
        this.getDraggable().setWidth(width);
        this.getDraggable().setHeight(height);
    }

    public abstract String getValue();

    public abstract HudIcon getIcon();

    public String getUnit() {
        return "";
    }
}
