package hud;

import java.util.ArrayList;
import java.util.List;
import client.api.utils.animation.AnimationUtil;
import client.api.utils.animation.Easing;
import lombok.Generated;
import client.api.event.Listener;
import client.api.event.events.render.Render2DEvent;
import client.client.features.modules.render.InterfaceModule;
import hud.Widget;
import hud.overlay.ArmorWidget;
import hud.overlay.BPSWidget;
import hud.overlay.CooldownsWidget;
import hud.overlay.KeybindsWidget;
import hud.overlay.PotionsWidget;
import hud.overlay.StaffsWidget;
import hud.overlay.TargetInfoWidget;
import hud.overlay.WatermarkWidget;
import hud.overlay.XYZWidget;
import hud.overlay.TotemsWidget;
import hud.overlay.NotificationsWidget;
import client.api.utils.combat.TotemPopTracker;

public class WidgetManager {
    private static final WidgetManager instance = new WidgetManager();
    private final List<Widget> widgets = new ArrayList<Widget>();
    private final AnimationUtil editAnimation = new AnimationUtil();

    public void load() {
        this.register(new WatermarkWidget(), new KeybindsWidget(), new PotionsWidget(), new StaffsWidget(), new CooldownsWidget(), new ArmorWidget(), new TargetInfoWidget(), new BPSWidget(), new XYZWidget(), new TotemsWidget(), new NotificationsWidget());
        TotemPopTracker.getInstance().load();
        InterfaceModule.getInstance().init();
        Render2DEvent.getInstance().subscribe(new Listener<Render2DEvent.Render2DEventData>(event -> {
            if (InterfaceModule.getInstance().isEnabled()) {
                Render2DEvent.Render2DEventData data = (Render2DEvent.Render2DEventData)event;
                this.editAnimation.update();
                this.editAnimation.run(HudEditor.isEditing() ? 1.0 : 0.0, 180L, Easing.CUBIC_OUT);
                float edit = (float)this.editAnimation.getValue();
                if (edit > 0.01f) {
                    HudEditor.renderGrid(data.matrixStack(), edit);
                    HudEditor.renderUnderlay(data.matrixStack(), edit);
                }
                for (Widget widget : this.widgets) {
                    if (!widget.isEnabled()) continue;
                    HudStyle.setWidgetScale(widget.getDraggable().getScale());
                    widget.render(data);
                }
                HudStyle.setWidgetScale(1.0f);
                if (edit > 0.01f) {
                    HudEditor.renderOverlay(data.matrixStack(), edit);
                }
            }
        }));
    }

    public void register(Widget ... widgets) {
        this.widgets.addAll(List.of(widgets));
    }

    @Generated
    public List<Widget> getWidgets() {
        return this.widgets;
    }

    @Generated
    public static WidgetManager getInstance() {
        return instance;
    }
}
