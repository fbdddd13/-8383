package hud;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import client.api.utils.animation.AnimationUtil;
import client.api.utils.animation.Easing;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import client.api.system.draggable.Draggable;
import client.api.system.interfaces.QuickImports;
import client.api.utils.color.UIColors;
import client.api.utils.render.RenderUtil;
import client.api.utils.render.fonts.Fonts;
import client.client.features.modules.render.InterfaceModule;

public final class HudEditor implements QuickImports {
    private static final float SNAP_DISTANCE = 4.0f;
    private static final float MARGIN = 3.0f;
    private static final float SPACING = 4.0f;
    private static final List<Float> GUIDES_X = new ArrayList<Float>();
    private static final List<Float> GUIDES_Y = new ArrayList<Float>();
    private static Widget scaleHintWidget;
    private static long scaleHintTime;

    private HudEditor() {
    }

    public static boolean isEditing() {
        return mc.currentScreen instanceof ChatScreen;
    }

    public static Widget widgetOf(Draggable draggable) {
        for (Widget widget : WidgetManager.getInstance().getWidgets()) {
            if (widget.isEnabled() && widget.getDraggable() == draggable) {
                return widget;
            }
        }
        return null;
    }

    public static boolean canDrag(Draggable draggable) {
        if (!isEditing()) {
            return true;
        }
        boolean isWidget = WidgetManager.getInstance().getWidgets().stream().anyMatch(w -> w.getDraggable() == draggable);
        return !isWidget || widgetOf(draggable) != null;
    }

    public static void clearGuides() {
        GUIDES_X.clear();
        GUIDES_Y.clear();
    }

    public static float[] snap(Draggable draggable, float targetX, float targetY) {
        clearGuides();
        InterfaceModule settings = InterfaceModule.getInstance();
        if (Screen.hasShiftDown()) {
            return new float[]{targetX, targetY};
        }
        float width = draggable.getWidth();
        float height = draggable.getHeight();
        float x = targetX;
        float y = targetY;
        if (settings.grid.getValue()) {
            float size = settings.gridSize.getValue();
            x = Math.round(x / size) * size;
            y = Math.round(y / size) * size;
        }
        List<float[]> linesX = new ArrayList<float[]>();
        List<float[]> linesY = new ArrayList<float[]>();
        float screenWidth = mc.getWindow().getScaledWidth();
        float screenHeight = mc.getWindow().getScaledHeight();
        if (settings.snapScreen.getValue()) {
            linesX.add(new float[]{MARGIN, 0, 0});
            linesX.add(new float[]{screenWidth / 2.0f, 1, screenWidth / 2.0f});
            linesX.add(new float[]{screenWidth - MARGIN, 2, screenWidth});
            linesY.add(new float[]{MARGIN, 0, 0});
            linesY.add(new float[]{screenHeight / 2.0f, 1, screenHeight / 2.0f});
            linesY.add(new float[]{screenHeight - MARGIN, 2, screenHeight});
        }
        if (settings.snapElements.getValue()) {
            for (Widget widget : WidgetManager.getInstance().getWidgets()) {
                Draggable other = widget.getDraggable();
                if (!widget.isEnabled() || other == draggable || other.getWidth() <= 0.0f) continue;
                float left = other.getX();
                float right = left + other.getWidth();
                float top = other.getY();
                float bottom = top + other.getHeight();
                for (int anchor = 0; anchor < 3; ++anchor) {
                    linesX.add(new float[]{left, anchor, left});
                    linesX.add(new float[]{(left + right) / 2.0f, anchor, (left + right) / 2.0f});
                    linesX.add(new float[]{right, anchor, right});
                    linesY.add(new float[]{top, anchor, top});
                    linesY.add(new float[]{(top + bottom) / 2.0f, anchor, (top + bottom) / 2.0f});
                    linesY.add(new float[]{bottom, anchor, bottom});
                }

                linesX.add(new float[]{right + SPACING, 0, right});
                linesX.add(new float[]{left - SPACING, 2, left});
                linesY.add(new float[]{bottom + SPACING, 0, bottom});
                linesY.add(new float[]{top - SPACING, 2, top});
            }
        }
        float[] snappedX = snapAxis(x, width, linesX);
        float[] snappedY = snapAxis(y, height, linesY);
        if (snappedX != null) {
            x = snappedX[0];
            GUIDES_X.add(snappedX[1]);
        }
        if (snappedY != null) {
            y = snappedY[0];
            GUIDES_Y.add(snappedY[1]);
        }
        return new float[]{x, y};
    }

    private static float[] snapAxis(float position, float size, List<float[]> lines) {
        float best = SNAP_DISTANCE;
        float[] result = null;
        for (float[] line : lines) {
            float anchor = position + size * 0.5f * line[1];
            float distance = Math.abs(line[0] - anchor);
            if (distance <= best) {
                best = distance;
                result = new float[]{position + (line[0] - anchor), line[2]};
            }
        }
        return result;
    }

    public static void renderGrid(MatrixStack ms, float alpha) {
        InterfaceModule settings = InterfaceModule.getInstance();
        float screenWidth = mc.getWindow().getScaledWidth();
        float screenHeight = mc.getWindow().getScaledHeight();
        float line = 0.5f;
        if (settings.grid.getValue()) {
            float size = Math.max(2.0f, settings.gridSize.getValue());
            Color color = new Color(255, 255, 255, (int)(14.0f * alpha));
            for (float gx = 0.0f; gx <= screenWidth; gx += size) {
                RenderUtil.RECT.draw(ms, gx, 0.0f, line, screenHeight, 0.0f, color);
            }
            for (float gy = 0.0f; gy <= screenHeight; gy += size) {
                RenderUtil.RECT.draw(ms, 0.0f, gy, screenWidth, line, 0.0f, color);
            }
        }
        if (settings.grid.getValue() || settings.snapScreen.getValue()) {
            Color center = new Color(255, 255, 255, (int)(30.0f * alpha));
            RenderUtil.RECT.draw(ms, screenWidth / 2.0f - line / 2.0f, 0.0f, line, screenHeight, 0.0f, center);
            RenderUtil.RECT.draw(ms, 0.0f, screenHeight / 2.0f - line / 2.0f, screenWidth, line, 0.0f, center);
        }
    }

    private static Widget dragging() {
        for (Widget widget : WidgetManager.getInstance().getWidgets()) {
            if (widget.isEnabled() && widget.getDraggable().isDragging()) {
                return widget;
            }
        }
        return null;
    }

    private static Widget hovered() {
        for (Widget widget : WidgetManager.getInstance().getWidgets()) {
            if (widget.isEnabled() && widget.getDraggable().isHovering()) {
                return widget;
            }
        }
        return null;
    }

    public static void renderUnderlay(MatrixStack ms, float alpha) {
        Widget dragging = dragging();
        Widget selected = menu != null ? menu.widget : null;
        Widget hovered = selected == null && dragging == null ? hovered() : null;
        if (dragging != null) {
            frame(ms, dragging.getDraggable(), UIColors.primary((int)(150.0f * alpha)));
        } else if (selected != null) {
            frame(ms, selected.getDraggable(), UIColors.primary((int)(110.0f * alpha)));
        } else if (hovered != null) {
            frame(ms, hovered.getDraggable(), new Color(255, 255, 255, (int)(45.0f * alpha)));
        }
    }

    private static void frame(MatrixStack ms, Draggable d, Color color) {
        float outline = 2.5f;
        RenderUtil.RECT.draw(ms, d.getX() - outline, d.getY() - outline, d.getWidth() + outline * 2.0f, d.getHeight() + outline * 2.0f, HudStyle.round() + outline, color);
    }

    public static void renderOverlay(MatrixStack ms, float alpha) {
        float screenWidth = mc.getWindow().getScaledWidth();
        float screenHeight = mc.getWindow().getScaledHeight();
        Widget dragging = dragging();
        Widget hovered = dragging == null ? hovered() : null;
        if (dragging == null) {
            clearGuides();
        }
        Color accent = UIColors.primary((int)(255.0f * alpha));
        Color glow = UIColors.primary((int)(70.0f * alpha));
        for (Float gx : GUIDES_X) {
            RenderUtil.RECT.draw(ms, gx - 1.5f, 0.0f, 3.0f, screenHeight, 1.5f, glow);
            RenderUtil.RECT.draw(ms, gx - 0.5f, 0.0f, 1.0f, screenHeight, 0.0f, accent);
        }
        for (Float gy : GUIDES_Y) {
            RenderUtil.RECT.draw(ms, 0.0f, gy - 1.5f, screenWidth, 3.0f, 1.5f, glow);
            RenderUtil.RECT.draw(ms, 0.0f, gy - 0.5f, screenWidth, 1.0f, 0.0f, accent);
        }
        Widget hint = dragging != null ? dragging : hovered;
        boolean recentScale = scaleHintWidget != null && System.currentTimeMillis() - scaleHintTime < 1200L;
        if (recentScale) {
            hint = scaleHintWidget;
        }
        if (hint != null && (recentScale || Math.abs(hint.getDraggable().getScale() - 1.0f) > 0.001f)) {
            Draggable d = hint.getDraggable();
            String text = Math.round(d.getScale() * 100.0f) + "%";
            float fontSize = 6.0f;
            float width = HudStyle.badgeWidth(Fonts.PS_MEDIUM, text, fontSize);
            float badgeY = d.getY() > 12.0f ? d.getY() - 6.0f : d.getY() + d.getHeight() + 6.0f;
            RenderUtil.RECT.draw(ms, d.getX() + d.getWidth() - width - 1.0f, badgeY - 4.5f, width + 2.0f, 9.0f, 2.5f, UIColors.widgetBlur((int)(230.0f * alpha)));
            HudStyle.badge(ms, Fonts.PS_MEDIUM, text, d.getX() + d.getWidth(), badgeY, fontSize, UIColors.textColor((int)(255.0f * alpha)), (int)(255.0f * alpha));
        }
        renderMenu(ms, alpha);
    }

    public record MenuOption(String label, Supplier<Boolean> selected, Runnable action, boolean radio) {
    }

    private static final class Menu {
        private final Widget widget;
        private final List<MenuOption> options;
        private final float x;
        private final float y;
        private final AnimationUtil animation = new AnimationUtil();

        private Menu(Widget widget, List<MenuOption> options, float x, float y) {
            this.widget = widget;
            this.options = options;
            this.x = x;
            this.y = y;
            this.animation.run(1.0, 160L, Easing.CUBIC_OUT);
        }
    }

    private static Menu menu;
    private static final float MENU_PAD = 5.0f;
    private static final float MENU_HEADER = 13.0f;
    private static final float MENU_ROW = 12.0f;
    private static final float MENU_FONT = 6.0f;

    private static float menuWidth(Menu m) {
        float width = Fonts.PS_MEDIUM.getWidth(m.widget.getName(), MENU_FONT) + MENU_PAD * 2.0f;
        for (MenuOption option : m.options) {
            width = Math.max(width, Fonts.PS_MEDIUM.getWidth(option.label(), MENU_FONT) + MENU_PAD * 2.0f + 14.0f);
        }
        return Math.max(90.0f, width);
    }

    private static float menuHeight(Menu m) {
        return MENU_HEADER + MENU_ROW * (float)m.options.size() + 4.0f;
    }

    private static float[] menuPosition(Menu m) {
        float width = menuWidth(m);
        float height = menuHeight(m);
        float x = Math.min(m.x, (float)mc.getWindow().getScaledWidth() - width - 3.0f);
        float y = Math.min(m.y, (float)mc.getWindow().getScaledHeight() - height - 3.0f);
        return new float[]{x, y, width, height};
    }

    private static float mouseX() {
        return (float)(mc.mouse.getX() / mc.getWindow().getScaleFactor());
    }

    private static float mouseY() {
        return (float)(mc.mouse.getY() / mc.getWindow().getScaleFactor());
    }

    private static void renderMenu(MatrixStack ms, float alpha) {
        if (menu == null) {
            return;
        }
        if (!isEditing()) {
            menu = null;
            return;
        }
        menu.animation.update();
        float anim = (float)menu.animation.getValue() * alpha;
        int a = (int)(anim * 255.0f);
        float[] p = menuPosition(menu);
        float x = p[0];
        float y = p[1] - 4.0f * (1.0f - anim);
        float width = p[2];
        RenderUtil.RECT.draw(ms, x - 0.75f, y - 0.75f, width + 1.5f, p[3] + 1.5f, HudStyle.round() + 0.75f, new Color(255, 255, 255, (int)(38.0f * anim)));
        RenderUtil.BLUR_RECT.draw(ms, x, y, width, p[3], HudStyle.round(), UIColors.widgetBlur(a));
        Fonts.PS_MEDIUM.drawText(ms, menu.widget.getName(), x + MENU_PAD, HudStyle.textY(y + MENU_HEADER / 2.0f, MENU_FONT), MENU_FONT, UIColors.inactiveTextColor(a));
        RenderUtil.RECT.draw(ms, x, y + MENU_HEADER, width, 0.5f, 0.0f, HudStyle.alpha(HudStyle.DIVIDER, a));
        float rowY = y + MENU_HEADER + 2.0f;
        float mx = mouseX();
        float my = mouseY();
        for (MenuOption option : menu.options) {
            boolean hover = mx >= x && mx <= x + width && my >= rowY && my < rowY + MENU_ROW;
            if (hover) {
                RenderUtil.RECT.draw(ms, x + 2.0f, rowY, width - 4.0f, MENU_ROW, 2.5f, new Color(255, 255, 255, (int)(16.0f * anim)));
            }
            float center = rowY + MENU_ROW / 2.0f;
            boolean selected = option.selected().get();
            float box = 6.0f;
            float boxX = x + MENU_PAD;
            float radius = option.radio() ? box / 2.0f : 1.5f;
            RenderUtil.RECT.draw(ms, boxX, center - box / 2.0f, box, box, radius, HudStyle.alpha(HudStyle.TRACK, a));
            if (selected) {
                float inner = option.radio() ? 3.0f : 4.0f;
                RenderUtil.RECT.draw(ms, boxX + (box - inner) / 2.0f, center - inner / 2.0f, inner, inner, option.radio() ? inner / 2.0f : 1.0f, UIColors.primary(a));
            }
            Fonts.PS_MEDIUM.drawText(ms, option.label(), boxX + box + 5.0f, HudStyle.textY(center, MENU_FONT), MENU_FONT, selected ? UIColors.textColor(a) : UIColors.inactiveTextColor(a));
            rowY += MENU_ROW;
        }
    }

    public static boolean onMouseButton(int button, int action) {
        if (!isEditing() || action != 1) {
            return false;
        }
        if (menu != null) {
            float[] p = menuPosition(menu);
            float mx = mouseX();
            float my = mouseY();
            if (mx >= p[0] && mx <= p[0] + p[2] && my >= p[1] && my <= p[1] + p[3]) {
                if (button == 0) {
                    float rowY = p[1] + MENU_HEADER + 2.0f;
                    for (MenuOption option : menu.options) {
                        if (my >= rowY && my < rowY + MENU_ROW) {
                            option.action().run();
                            break;
                        }
                        rowY += MENU_ROW;
                    }
                }
                return true;
            }
            menu = null;
            if (button == 0) {
                return true;
            }
        }
        if (button == 1) {
            Widget widget = hovered();
            if (widget != null && !widget.getMenuOptions().isEmpty()) {
                menu = new Menu(widget, widget.getMenuOptions(), mouseX() + 2.0f, mouseY() + 2.0f);
                return true;
            }
        }
        if (button == 2) {
            return onMiddleClick();
        }
        return false;
    }

    public static boolean onScroll(double amount) {
        if (!isEditing() || amount == 0.0) {
            return false;
        }
        for (Widget widget : WidgetManager.getInstance().getWidgets()) {
            if (!widget.isEnabled() || !widget.getDraggable().isHovering()) continue;
            Draggable d = widget.getDraggable();
            float step = Screen.hasControlDown() ? 0.01f : 0.05f;
            float next = Math.round((d.getScale() + (amount > 0.0 ? step : -step)) * 100.0f) / 100.0f;
            d.setScale(next);
            scaleHintWidget = widget;
            scaleHintTime = System.currentTimeMillis();
            return true;
        }
        return false;
    }

    public static boolean onMiddleClick() {
        if (!isEditing()) {
            return false;
        }
        for (Widget widget : WidgetManager.getInstance().getWidgets()) {
            if (!widget.isEnabled() || !widget.getDraggable().isHovering()) continue;
            widget.getDraggable().setScale(1.0f);
            scaleHintWidget = widget;
            scaleHintTime = System.currentTimeMillis();
            return true;
        }
        return false;
    }
}
