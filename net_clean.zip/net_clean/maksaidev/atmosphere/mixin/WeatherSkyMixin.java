package net.maksaidev.atmosphere.mixin;

import net.maksaidev.atmosphere.weather.WeatherConfig;
import net.maksaidev.atmosphere.weather.WeatherModule;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SkyRendering.class)
public abstract class WeatherSkyMixin {
    @Inject(method={"renderSky", "renderClouds"}, at={@At(value="HEAD")}, cancellable=true)
    private void maksatmosphere$customSun(CallbackInfo ci) {
        WeatherConfig c = WeatherModule.config();
        if (c != null && c.enabled && c.mode == WeatherConfig.Mode.SUNRISE) {
            ci.cancel();
        }
    }
}
