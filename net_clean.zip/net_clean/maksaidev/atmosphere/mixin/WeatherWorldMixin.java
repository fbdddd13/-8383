package net.maksaidev.atmosphere.mixin;

import net.maksaidev.atmosphere.weather.WeatherConfig;
import net.maksaidev.atmosphere.weather.WeatherModule;
import net.minecraft.world.World;
import net.minecraft.client.world.ClientLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(World.class)
public abstract class WeatherWorldMixin {
    @Inject(method={"getChunkSource"}, at={@At(value="HEAD")}, cancellable=true)
    private void maksatmosphere$visualRain(float delta, CallbackInfoReturnable<Float> cir) {
        WeatherConfig c;
        if (this instanceof ClientLevel && (c = WeatherModule.config()) != null && c.enabled && c.mode != WeatherConfig.Mode.OFF) {
            cir.setReturnValue((Object)Float.valueOf(c.mode == WeatherConfig.Mode.RAIN ? c.rainIntensity / 100.0f : 0.0f));
        }
    }
}
