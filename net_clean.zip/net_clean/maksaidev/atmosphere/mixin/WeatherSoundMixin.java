package net.maksaidev.atmosphere.mixin;

import net.maksaidev.atmosphere.weather.WeatherModule;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.client.sound.SoundSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(SoundSystem.class)
public abstract class WeatherSoundMixin {
    @Inject(method={"getSoundSystem(Lnet/minecraft/SoundManager;)Lnet/minecraft/SoundSystem$SoundListener;"}, at={@At(value="HEAD")}, cancellable=true)
    private void maksatmosphere$muteWinterAmbience(SoundManager sound, CallbackInfoReturnable<SoundSystem.SoundListener> cir) {
        if (WeatherModule.muteWinterAmbience(sound.getListener())) {
            cir.setReturnValue((Object)SoundSystem.SoundListener.EMPTY);
        }
    }
}
