package net.maksaidev.atmosphere;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.maksaidev.atmosphere.UiFont;
import net.maksaidev.atmosphere.UiShapes;
import net.maksaidev.atmosphere.UiTheme;
import net.maksaidev.atmosphere.weather.WeatherConfig;
import net.minecraft.sound.SoundEvent;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.client.gui.Click;
import net.minecraft.util.Util;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundEvents;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.registry.entry.RegistryEntry;

public final class MaksaiAtmosphereScreen
extends Screen {
    private static final int PANEL_W = 560;
    private static final int PAD = 14;
    private static final int ROW_H = 18;
    private static final int ROW_GAP = 5;
    private static final int COL_GAP = 16;
    private static final int CONTENT_Y = 44;
    private static final long OPEN_MS = 280L;
    private final Screen parent;
    private final List<ToggleRow> toggles = new ArrayList<ToggleRow>();
    private final List<SliderRow> sliders = new ArrayList<SliderRow>();
    private final List<Btn> buttons = new ArrayList<Btn>();
    private Btn doneBtn;
    private int panelX;
    private int panelY;
    private int panelH;
    private float openScale = 1.0f;
    private float openAlpha = 1.0f;
    private float fitScale = 1.0f;
    private long openedAtMs;
    private long lastAnimMs;
    private final Map<String, Float> toggleAnim = new HashMap<String, Float>();
    private SliderRow dragging;

    public MaksaiAtmosphereScreen(Screen parent) {
        super(Text.literal("Sl1ce X Maksai Atmosphere"));
        this.parent = parent;
    }

    protected void init() {
        this.lastAnimMs = this.openedAtMs = Util.getMeasuringTimeMs();
        this.rebuild();
    }

    private void rebuild() {
        int i;
        this.toggles.clear();
        this.sliders.clear();
        this.buttons.clear();
        this.doneBtn = null;
        this.dragging = null;
        this.panelX = (this.width - 560) / 2;
        int colW = 258;
        int leftBottom = this.buildWeatherLeft(colW);
        int rightBottom = this.buildWeatherRight(colW);
        int contentBottom = Math.max(leftBottom, rightBottom) + 18;
        this.panelH = contentBottom + 8 + 18 + 14;
        this.panelY = Math.max(8, (this.height - this.panelH) / 2);
        this.fitScale = Math.min(1.0f, (this.height - 12.0f) / Math.max(1.0f, this.panelH));
        for (i = 0; i < this.toggles.size(); ++i) {
            ToggleRow t = this.toggles.get(i);
            this.toggles.set(i, new ToggleRow(t.key(), t.label(), t.get(), t.set(), t.x1(), t.y1() + this.panelY, t.x2(), t.y2() + this.panelY));
        }
        for (i = 0; i < this.sliders.size(); ++i) {
            SliderRow s = this.sliders.get(i);
            this.sliders.set(i, new SliderRow(s.key(), s.label(), s.get(), s.set(), s.min(), s.max(), s.format(), s.x1(), s.y1() + this.panelY, s.x2(), s.y2() + this.panelY));
        }
        for (i = 0; i < this.buttons.size(); ++i) {
            Btn b = this.buttons.get(i);
            this.buttons.set(i, new Btn(b.label(), b.action(), b.x1(), b.y1() + this.panelY, b.x2(), b.y2() + this.panelY));
        }
        int pillW = 110;
        this.doneBtn = new Btn(() -> "Готово", this::close, this.panelX + (560 - pillW) / 2, contentBottom + 8 + this.panelY, this.panelX + (560 + pillW) / 2, contentBottom + 8 + this.panelY + 18);
    }

    private int buildWeatherLeft(int colW) {
        WeatherConfig cfg = WeatherConfig.get();
        int lx = this.panelX + 14;
        int y = 44;
        this.toggles.add(this.toggleW("w.enabled", "Эффекты", () -> cfg.enabled, v -> {
            cfg.enabled = v;
        }, lx, y, lx + colW, y + 18));
        this.buttons.add(new Btn(() -> "Погода: " + WeatherConfig.modeName(cfg.mode) + "  >", () -> {
            cfg.mode = cfg.mode.next();
            WeatherConfig.save();
            this.rebuild();
        }, lx, y += 23, lx + colW, y + 18));
        this.buttons.add(new Btn(() -> "Качество: " + WeatherConfig.qualityName(cfg.quality) + "  >", () -> {
            cfg.quality = cfg.quality.next();
            WeatherConfig.save();
        }, lx, y += 23, lx + colW, y + 18));
        List<Object> rows = this.weatherRows(cfg);
        int leftCount = (rows.size() + 1) / 2;
        return this.placeWeatherRows(rows, 0, leftCount, lx, y += 23, colW);
    }

    private int buildWeatherRight(int colW) {
        WeatherConfig cfg = WeatherConfig.get();
        int rx = this.panelX + 14 + colW + 16;
        List<Object> rows = this.weatherRows(cfg);
        int leftCount = (rows.size() + 1) / 2;
        return this.placeWeatherRows(rows, leftCount, rows.size(), rx, 44, colW);
    }

    private int placeWeatherRows(List<Object> rows, int from, int to, int x, int y, int w) {
        for (int i = from; i < to; ++i) {
            Object row = rows.get(i);
            if (row instanceof ToggleRow) {
                ToggleRow t = (ToggleRow)row;
                this.toggles.add(new ToggleRow(t.key(), t.label(), t.get(), t.set(), x, y, x + w, y + 18));
            } else if (row instanceof SliderRow) {
                SliderRow s = (SliderRow)row;
                this.sliders.add(new SliderRow(s.key(), s.label(), s.get(), s.set(), s.min(), s.max(), s.format(), x, y, x + w, y + 18));
            }
            y += 23;
        }
        return y;
    }

    private List<Object> weatherRows(WeatherConfig cfg) {
        ArrayList<Object> rows = new ArrayList<Object>();
        switch (cfg.mode) {
            case OFF: {
                rows.add(this.wt("Мокрая земля", () -> cfg.wetGround, v -> {
                    cfg.wetGround = v;
                }));
                rows.add(this.ws("Лужи", () -> cfg.puddles, v -> {
                    cfg.puddles = v.intValue();
                }));
                break;
            }
            case RAIN: {
                rows.add(this.ws("Сила дождя", () -> cfg.rainIntensity, v -> {
                    cfg.rainIntensity = v.intValue();
                }));
                rows.add(this.ws("Звук дождя", () -> cfg.rainSound, v -> {
                    cfg.rainSound = v.intValue();
                }));
                rows.add(this.ws("Лужи", () -> cfg.puddles, v -> {
                    cfg.puddles = v.intValue();
                }));
                rows.add(this.wt("Брызги", () -> cfg.splashes, v -> {
                    cfg.splashes = v;
                }));
                rows.add(this.ws("Количество всплесков", () -> cfg.splashDensity, v -> {
                    cfg.splashDensity = v.intValue();
                }));
                rows.add(this.ws("Видимость колец", () -> cfg.ringVisibility, v -> {
                    cfg.ringVisibility = v.intValue();
                }));
                rows.add(this.wt("Мокрая земля", () -> cfg.wetGround, v -> {
                    cfg.wetGround = v;
                }));
                rows.add(this.ws("Ветер", () -> cfg.wind, v -> {
                    cfg.wind = v.intValue();
                }));
                break;
            }
            case WINTER: {
                rows.add(this.ws("Плотность снега", () -> cfg.snowDensity, v -> {
                    cfg.snowDensity = v.intValue();
                }));
                rows.add(this.ws("Ветер", () -> cfg.wind, v -> {
                    cfg.wind = v.intValue();
                }));
                rows.add(this.wt("Снежный покров", () -> cfg.snowCover, v -> {
                    cfg.snowCover = v;
                }));
                rows.add(this.ws("Метель", () -> cfg.blizzard, v -> {
                    cfg.blizzard = v.intValue();
                }));
                break;
            }
            case SUNRISE: {
                rows.add(this.ws("Солнечный свет", () -> cfg.sunlight, v -> {
                    cfg.sunlight = v.intValue();
                }));
                rows.add(this.ws("Лучи солнца", () -> cfg.sunRays, v -> {
                    cfg.sunRays = v.intValue();
                }));
                rows.add(this.ws("Высота солнца", () -> cfg.sunHeight, v -> {
                    cfg.sunHeight = v.intValue();
                }));
                rows.add(this.ws("Роса", () -> cfg.dew, v -> {
                    cfg.dew = v.intValue();
                }));
                break;
            }
            case DUST: {
                rows.add(this.ws("Плотность пыли", () -> cfg.dustDensity, v -> {
                    cfg.dustDensity = v.intValue();
                }));
                rows.add(this.ws("Размер пыли", () -> cfg.dustSize, v -> {
                    cfg.dustSize = v.intValue();
                }));
                rows.add(this.ws("Свечение пыли", () -> cfg.dustLight, v -> {
                    cfg.dustLight = v.intValue();
                }));
                break;
            }
            case SAKURA: {
                rows.add(this.ws("Плотность лепестков", () -> cfg.sakuraDensity, v -> {
                    cfg.sakuraDensity = v.intValue();
                }));
                rows.add(this.ws("Размер лепестков", () -> cfg.sakuraSize, v -> {
                    cfg.sakuraSize = v.intValue();
                }));
                rows.add(this.ws("Время на земле", () -> cfg.sakuraGroundLife, v -> {
                    cfg.sakuraGroundLife = v.intValue();
                }));
                rows.add(this.ws("Ветер", () -> cfg.sakuraWind, v -> {
                    cfg.sakuraWind = v.intValue();
                }));
                rows.add(this.ws("Оттенок", () -> cfg.sakuraHue, v -> {
                    cfg.sakuraHue = v.intValue();
                }));
                rows.add(this.ws("Насыщенность", () -> cfg.sakuraSaturation, v -> {
                    cfg.sakuraSaturation = v.intValue();
                }));
                rows.add(this.ws("Порхание", () -> cfg.sakuraFlutter, v -> {
                    cfg.sakuraFlutter = v.intValue();
                }));
                rows.add(this.wt("Розовый тинт", () -> cfg.sakuraTint, v -> {
                    cfg.sakuraTint = v;
                }));
                rows.add(this.ws("Сила тинта", () -> cfg.sakuraTintStrength, v -> {
                    cfg.sakuraTintStrength = v.intValue();
                }));
                break;
            }
            case ECLIPSE: {
                rows.add(this.ws("Темнота", () -> cfg.eclipseDarkness, v -> {
                    cfg.eclipseDarkness = v.intValue();
                }));
                rows.add(this.ws("Корона", () -> cfg.eclipseCorona, v -> {
                    cfg.eclipseCorona = v.intValue();
                }));
                rows.add(this.ws("Звёзды", () -> cfg.eclipseStars, v -> {
                    cfg.eclipseStars = v.intValue();
                }));
                rows.add(this.ws("Космическая пыль", () -> cfg.eclipseDust, v -> {
                    cfg.eclipseDust = v.intValue();
                }));
                break;
            }
            case METEOR: {
                rows.add(this.ws("Частота метеоров", () -> cfg.meteorRate, v -> {
                    cfg.meteorRate = v.intValue();
                }));
                rows.add(this.ws("Яркость", () -> cfg.meteorBrightness, v -> {
                    cfg.meteorBrightness = v.intValue();
                }));
                rows.add(this.ws("Длина следа", () -> cfg.meteorTrail, v -> {
                    cfg.meteorTrail = v.intValue();
                }));
                rows.add(this.ws("Звёзды", () -> cfg.meteorStars, v -> {
                    cfg.meteorStars = v.intValue();
                }));
                rows.add(this.ws("Обломки", () -> cfg.meteorDebris, v -> {
                    cfg.meteorDebris = v.intValue();
                }));
                rows.add(this.ws("Размер метеоров", () -> cfg.meteorSize, v -> {
                    cfg.meteorSize = v.intValue();
                }));
                rows.add(this.ws("Разброс размеров", () -> cfg.meteorVariation, v -> {
                    cfg.meteorVariation = v.intValue();
                }));
                rows.add(this.ws("Близость", () -> cfg.meteorProximity, v -> {
                    cfg.meteorProximity = v.intValue();
                }));
                rows.add(this.ws("Туман", () -> cfg.meteorFog, v -> {
                    cfg.meteorFog = v.intValue();
                }));
                rows.add(this.ws("Дальность тумана", () -> cfg.meteorFogDistance, v -> {
                    cfg.meteorFogDistance = v.intValue();
                }));
                rows.add(this.ws("Свечение неба", () -> cfg.meteorSkyGlow, v -> {
                    cfg.meteorSkyGlow = v.intValue();
                }));
                rows.add(this.ws("Туманность", () -> cfg.meteorNebula, v -> {
                    cfg.meteorNebula = v.intValue();
                }));
                break;
            }
            case BLOOD_MOON: {
                rows.add(this.ws("Размер луны", () -> cfg.bloodMoonSize, v -> {
                    cfg.bloodMoonSize = v.intValue();
                }));
                rows.add(this.ws("Свечение луны", () -> cfg.bloodMoonGlow, v -> {
                    cfg.bloodMoonGlow = v.intValue();
                }));
                rows.add(this.ws("Красное небо", () -> cfg.bloodSky, v -> {
                    cfg.bloodSky = v.intValue();
                }));
                rows.add(this.ws("Облака", () -> cfg.bloodClouds, v -> {
                    cfg.bloodClouds = v.intValue();
                }));
                rows.add(this.ws("Красный туман", () -> cfg.bloodMist, v -> {
                    cfg.bloodMist = v.intValue();
                }));
                rows.add(this.ws("Земля в красном", () -> cfg.bloodGround, v -> {
                    cfg.bloodGround = v.intValue();
                }));
                rows.add(this.ws("Угли", () -> cfg.bloodEmbers, v -> {
                    cfg.bloodEmbers = v.intValue();
                }));
                rows.add(this.ws("Высота луны", () -> cfg.bloodHeight, v -> {
                    cfg.bloodHeight = v.intValue();
                }));
            }
        }
        return rows;
    }

    private ToggleRow wt(String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        return new ToggleRow("w." + label, label, get, v -> {
            set.accept(v);
            WeatherConfig.save();
        }, 0, 0, 0, 0);
    }

    private SliderRow ws(String label, Supplier<Double> get, Consumer<Double> set) {
        return new SliderRow("w." + label, label, get, v -> {
            set.accept(v);
            WeatherConfig.save();
        }, 0.0, 100.0, "%.0f%%", 0, 0, 0, 0);
    }

    private ToggleRow toggleW(String key, String label, Supplier<Boolean> get, Consumer<Boolean> set, int x1, int y1, int x2, int y2) {
        return new ToggleRow(key, label, get, v -> {
            set.accept(v);
            WeatherConfig.save();
        }, x1, y1, x2, y2);
    }

    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fillGradient(0, 0, this.width, this.height, -1879048192, -1342177280);
    }

    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        boolean hovered;
        this.renderBackground(context, mouseX, mouseY, delta);
        long now = Util.getMeasuringTimeMs();
        float openT = Math.min(1.0f, (float)(now - this.openedAtMs) / 280.0f);
        float eased = 1.0f - (1.0f - openT) * (1.0f - openT) * (1.0f - openT);
        this.openScale = (0.93f + 0.07f * eased) * this.fitScale;
        this.openAlpha = eased;
        float animDt = Math.min(0.1f, (float)(now - this.lastAnimMs) / 1000.0f);
        this.lastAnimMs = now;
        float cx = this.panelX + 280.0f;
        float cy = this.panelY + this.panelH / 2.0f;
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(cx, cy);
        context.getMatrices().scale(this.openScale, this.openScale);
        context.getMatrices().translate(-cx, -cy);
        int mx = this.tx(mouseX, cx);
        int my = this.ty(mouseY, cy);
        UiShapes.fillRoundedOutline(context, this.panelX, this.panelY, this.panelX + 560, this.panelY + this.panelH, 8, UiShapes.mulAlpha(UiTheme.rim(), this.openAlpha), UiShapes.mulAlpha(UiTheme.background(), this.openAlpha));
        UiFont.drawText(context, this.textRenderer, "Sl1ce X Maksai Atmosphere", this.panelX + 14, this.panelY + 10, UiShapes.mulAlpha(UiTheme.foreground(), this.openAlpha));
        UiFont.drawText(context, this.textRenderer, "порт SystemDlc", this.panelX + 14, this.panelY + 21, UiShapes.mulAlpha(UiTheme.mutedFg(), this.openAlpha));
        int swatchColor = WeatherConfig.modeColor(WeatherConfig.get().mode);
        UiShapes.fillRounded(context, this.panelX + 560 - 14 - 14, this.panelY + 10, this.panelX + 560 - 14, this.panelY + 24, 4, UiShapes.mulAlpha(0xFF000000 | swatchColor, this.openAlpha));
        context.fill(this.panelX + 14, this.panelY + 33, this.panelX + 560 - 14, this.panelY + 34, UiShapes.mulAlpha(UiTheme.rim(), this.openAlpha));
        for (ToggleRow t : this.toggles) {
            boolean on;
            float target;
            float cur;
            float next;
            hovered = mx >= t.x1 && mx < t.x2 && my >= t.y1 && my < t.y2;
            if (hovered) {
                UiShapes.fillRounded(context, t.x1 - 3, t.y1, t.x2 + 3, t.y2, 5, UiShapes.mulAlpha(UiTheme.surface(), this.openAlpha));
            }
            if (Math.abs((next = (cur = this.toggleAnim.getOrDefault(t.key, Float.valueOf(target = (on = t.get.get().booleanValue()) ? 1.0f : 0.0f)).floatValue()) + (target - cur) * Math.min(1.0f, animDt * 14.0f)) - target) < 0.01f) {
                next = target;
            }
            this.toggleAnim.put(t.key, Float.valueOf(next));
            this.drawCheckbox(context, t.x1, t.y1 + 3, next);
            UiFont.drawText(context, this.textRenderer, t.label, t.x1 + 18, t.y1 + 5, UiShapes.mulAlpha(hovered ? UiTheme.foreground() : UiTheme.mutedFg(), this.openAlpha));
        }
        for (Btn b : this.buttons) {
            hovered = mx >= b.x1 && mx < b.x2 && my >= b.y1 && my < b.y2;
            int fill = hovered ? UiShapes.lerp(UiTheme.elevated(), -1, 0.1f) : UiTheme.elevated();
            UiShapes.fillRoundedOutline(context, b.x1, b.y1, b.x2, b.y2, 5, UiShapes.mulAlpha(UiTheme.border(), this.openAlpha), UiShapes.mulAlpha(fill, this.openAlpha));
            UiFont.drawText(context, this.textRenderer, b.label.get(), b.x1 + 8, b.y1 + 5, UiShapes.mulAlpha(hovered ? UiTheme.foreground() : UiTheme.mutedFg(), this.openAlpha));
        }
        for (SliderRow s : this.sliders) {
            this.drawSlider(context, s, mx, my);
        }
        if (this.doneBtn != null) {
            Btn b = this.doneBtn;
            boolean hovered2 = mx >= b.x1 && mx < b.x2 && my >= b.y1 && my < b.y2;
            int fill = hovered2 ? UiShapes.lerp(UiTheme.primary(), -1, 0.15f) : UiTheme.primary();
            UiShapes.fillRounded(context, b.x1, b.y1, b.x2, b.y2, 6, UiShapes.mulAlpha(fill, this.openAlpha));
            UiFont.drawCentered(context, this.textRenderer, b.label.get(), (b.x1 + b.x2) / 2, b.y1 + 6, UiShapes.mulAlpha(-1, this.openAlpha));
        }
        context.getMatrices().popMatrix();
        int hintY = Math.min(this.height - 20, (int)(this.panelY + this.panelH * this.fitScale + 8.0f));
        UiFont.drawCentered(context, this.textRenderer, "9 режимов 3D-погоды: дождь с лужами, зима, рассвет, пыль, сакура, затмение, звёздный дождь, кровавая луна", this.width / 2, hintY, UiTheme.mutedFg());
        UiFont.drawCentered(context, this.textRenderer, "Меню открывается на L (меняется в Настройки → Управление)", this.width / 2, hintY + 11, UiTheme.mutedFg());
    }

    private int[] trackBounds(SliderRow s) {
        int w = s.x2 - s.x1;
        if (w < 90) {
            return new int[]{s.x1, s.x2 - 26};
        }
        int labelW = UiFont.w(this.textRenderer, s.label);
        return new int[]{s.x1 + Math.min(labelW + 8, Math.max(0, w - 70)), s.x2 - 30};
    }

    private void drawSlider(DrawContext context, SliderRow s, int mx, int my) {
        boolean hovered = mx >= s.x1 && mx < s.x2 && my >= s.y1 && my < s.y2;
        double value = s.get.get();
        double t = (value - s.min) / (s.max - s.min);
        if (t < 0.0) {
            t = 0.0;
        }
        if (t > 1.0) {
            t = 1.0;
        }
        int[] track = this.trackBounds(s);
        int trackY = s.y1 + 7;
        UiShapes.fillRounded(context, track[0], trackY, track[1], trackY + 4, 2, UiShapes.mulAlpha(UiTheme.elevated(), this.openAlpha));
        int fillTo = track[0] + Math.round((double)(track[1] - track[0]) * t);
        UiShapes.fillRounded(context, track[0], trackY, Math.max(fillTo, track[0] + 4), trackY + 4, 2, UiShapes.mulAlpha(hovered || this.dragging == s ? UiShapes.lerp(UiTheme.primary(), -1, 0.2f) : UiTheme.primary(), this.openAlpha));
        UiFont.drawText(context, this.textRenderer, s.label, s.x1, s.y1 + 5, UiShapes.mulAlpha(hovered ? UiTheme.foreground() : UiTheme.mutedFg(), this.openAlpha));
        String val = String.format(Locale.ROOT, s.format, value);
        UiFont.drawText(context, this.textRenderer, val, s.x2 - UiFont.w(this.textRenderer, val), s.y1 + 5, UiShapes.mulAlpha(UiTheme.foreground(), this.openAlpha));
    }

    private void drawCheckbox(DrawContext context, int x, int y, float t) {
        int size = 12;
        int fill = UiShapes.lerp(UiTheme.elevated(), UiTheme.primary(), t);
        UiShapes.fillRounded(context, x, y, x + size, y + size, 3, UiShapes.mulAlpha(UiTheme.border(), this.openAlpha));
        UiShapes.fillRounded(context, x + 1, y + 1, x + size - 1, y + size - 1, 2, UiShapes.mulAlpha(fill, this.openAlpha));
        if (t > 0.03f) {
            int c = UiShapes.mulAlpha(-1, this.openAlpha * t);
            context.fill(x + 3, y + 6, x + 4, y + 7, c);
            context.fill(x + 4, y + 7, x + 6, y + 9, c);
            context.fill(x + 6, y + 5, x + 7, y + 8, c);
            context.fill(x + 7, y + 4, x + 9, y + 6, c);
        }
    }

    private void dragSlider(SliderRow s, double mx) {
        int[] track = this.trackBounds(s);
        double t = (mx - track[0]) / (double)(track[1] - track[0]);
        if (t < 0.0) {
            t = 0.0;
        }
        if (t > 1.0) {
            t = 1.0;
        }
        s.set.accept(s.min + t * (s.max - s.min));
    }

    private int tx(double x, float cx) {
        return Math.round((x - cx) / this.openScale + cx);
    }

    private int ty(double y, float cy) {
        return Math.round((y - cy) / this.openScale + cy);
    }

    public boolean mouseClicked(Click click, boolean doubled) {
        float cx = this.panelX + 280.0f;
        float cy = this.panelY + this.panelH / 2.0f;
        double mx = this.tx(click.x(), cx);
        double my = this.ty(click.y(), cy);
        if (click.button() == 0) {
            for (ToggleRow t : this.toggles) {
                if (!(mx >= t.x1) || !(mx < t.x2) || !(my >= t.y1) || !(my < t.y2)) continue;
                t.set.accept(t.get.get() == false);
                this.clickSound();
                return true;
            }
            for (Btn b : this.buttons) {
                if (!(mx >= b.x1) || !(mx < b.x2) || !(my >= b.y1) || !(my < b.y2)) continue;
                b.action.run();
                this.clickSound();
                return true;
            }
            for (SliderRow s : this.sliders) {
                if (!(mx >= s.x1) || !(mx < s.x2) || !(my >= s.y1) || !(my < s.y2)) continue;
                this.dragging = s;
                this.dragSlider(s, mx);
                return true;
            }
            if (this.doneBtn != null && mx >= this.doneBtn.x1 && mx < this.doneBtn.x2 && my >= this.doneBtn.y1 && my < this.doneBtn.y2) {
                this.doneBtn.action.run();
                this.clickSound();
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (this.dragging != null && click.button() == 0) {
            float cx = this.panelX + 280.0f;
            double mx = this.tx(click.x(), cx);
            this.dragSlider(this.dragging, mx);
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    public boolean mouseReleased(Click click) {
        if (this.dragging != null && click.button() == 0) {
            this.dragging = null;
            this.clickSound();
            return true;
        }
        return super.mouseReleased(click);
    }

    public void close() {
        WeatherConfig.save();
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }

    private void clickSound() {
        try {
            MinecraftClient.getInstance().getSoundManager().play(SoundEvent.of(SoundEvents.UI_BUTTON_CLICK, 1.0f));
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private record Btn(Supplier<String> label, Runnable action, int x1, int y1, int x2, int y2) {
    }

    private record SliderRow(String key, String label, Supplier<Double> get, Consumer<Double> set, double min, double max, String format, int x1, int y1, int x2, int y2) {
    }

    private record ToggleRow(String key, String label, Supplier<Boolean> get, Consumer<Boolean> set, int x1, int y1, int x2, int y2) {
    }
}
