package net.maksaidev.atmosphere;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.maksaidev.atmosphere.MaksaiAtmosphereScreen;
import net.maksaidev.atmosphere.weather.WeatherModule;
import net.minecraft.util.Identifier;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

public final class MaksaiAtmosphereMod
implements ClientModInitializer {
    public static final String MOD_ID = "maksatmosphere";
    private static KeyBinding menuKey;

    public void onInitializeClient() {
        WeatherModule.init();
        KeyBinding.KeyBinding.Category category = KeyBinding.KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
        menuKey = KeyBindingHelper.registerKeyBinding((KeyBinding)new KeyBinding("key.maksatmosphere.menu", 76, category));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                MaksaiAtmosphereMod.openMenu(client);
            }
            WeatherModule.tick(client);
        });
    }

    private static void openMenu(MinecraftClient client) {
        if (client.currentScreen instanceof MaksaiAtmosphereScreen) {
            return;
        }
        client.setScreen((Screen)new MaksaiAtmosphereScreen(client.currentScreen));
    }
}
