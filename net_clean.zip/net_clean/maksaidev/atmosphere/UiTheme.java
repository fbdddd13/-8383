package net.maksaidev.atmosphere;

public final class UiTheme {
    private UiTheme() {
    }

    public static int background() {
        return -15856110;
    }

    public static int surface() {
        return -15263970;
    }

    public static int elevated() {
        return -14277073;
    }

    public static int border() {
        return -12763830;
    }

    public static int mutedFg() {
        return -6184531;
    }

    public static int primary() {
        return -10534416;
    }

    public static int foreground() {
        return -328966;
    }

    public static int rim() {
        return 0x14FFFFFF;
    }
}
