package net.maksaidev.atmosphere;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.RenderPipelines;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.class_327;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.class_9111;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.freetype.FT_Bitmap;
import org.lwjgl.util.freetype.FT_Face;
import org.lwjgl.util.freetype.FT_GlyphSlot;
import org.lwjgl.util.freetype.FT_Vector;
import org.lwjgl.util.freetype.FreeType;

public final class UiFont {
    private static final int BAKE = 18;
    private static final float SCALE = 0.5f;
    private static final int ATLAS_W = 1024;
    private static final int ATLAS_H = 512;
    private static final Identifier TEX = Identifier.of("maksatmosphere", "uniform_glyphs");
    private static final String[] CANDIDATES = new String[]{"segoeui.ttf", "arial.ttf", "tahoma.ttf", "calibri.ttf", "verdana.ttf"};
    private static final Map<Integer, Glyph> GLYPHS = new HashMap<Integer, Glyph>();
    private static volatile int state;
    private static float ascent;
    private static float spaceAdvance;

    private UiFont() {
    }

    public static boolean ready() {
        if (state == 0) {
            UiFont.init();
        }
        return state == 1;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static synchronized void init() {
        if (state != 0) {
            return;
        }
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client == null) return;
            if (client.method_1531() == null) {
                return;
            }
            byte[] bytes = null;
            try {
                String win = System.getenv("WINDIR");
                Path fonts = Path.of(win == null ? "C:/Windows" : win, "Fonts");
                for (String name : CANDIDATES) {
                    try {
                        Path p = fonts.resolve(name);
                        if (!Files.isRegularFile(p, new LinkOption[0])) continue;
                        bytes = Files.readAllBytes(p);
                        break;
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                }
            }
            catch (Throwable win) {
                // empty catch block
            }
            if (bytes == null) {
                state = 2;
                return;
            }
            class_1011 atlas = new class_1011(class_1011.class_1012.field_4997, 1024, 512, true);
            ByteBuffer buf = MemoryUtil.memAlloc(bytes.length);
            try {
                buf.put(bytes).flip();
                Object object = class_9111.field_51483;
                synchronized (object) {
                    FT_Face face;
                    try (MemoryStack stack = MemoryStack.stackPush();){
                        PointerBuffer pb = stack.mallocPointer(1);
                        if (FreeType.FT_New_Memory_Face(class_9111.method_56143(), (ByteBuffer)buf, 0L, (PointerBuffer)pb) != 0) {
                            state = 2;
                            return;
                        }
                        face = FT_Face.create(pb.get(0));
                    }
                    try {
                        FreeType.FT_Select_Charmap((FT_Face)face, FreeType.FT_ENCODING_UNICODE);
                        FreeType.FT_Set_Pixel_Sizes((FT_Face)face, 18, 18);
                        ascent = face.size().metrics().ascender() / 64.0f;
                        UiFont.bake(face, atlas);
                    }
                    finally {
                        FreeType.FT_Done_Face((FT_Face)face);
                    }
                }
            }
            finally {
                MemoryUtil.memFree((Buffer)buf);
            }
            if (GLYPHS.isEmpty()) {
                state = 2;
                return;
            }
            client.method_1531().method_4616(TEX, (class_1044)new SmoothTexture(atlas));
            state = 1;
            return;
        }
        catch (Throwable t) {
            state = 2;
        }
    }

    private static void bake(FT_Face face, class_1011 atlas) {
        int[] extra;
        int cp;
        ArrayList<Integer> codepoints = new ArrayList<Integer>();
        for (cp = 32; cp <= 126; ++cp) {
            codepoints.add(cp);
        }
        for (cp = 160; cp <= 255; ++cp) {
            codepoints.add(cp);
        }
        for (cp = 1024; cp <= 1119; ++cp) {
            codepoints.add(cp);
        }
        for (int cp2 : extra = new int[]{8211, 8212, 8216, 8217, 8220, 8221, 8226, 8230, 8381, 8470, 8594}) {
            codepoints.add(cp2);
        }
        int penX = 1;
        int penY = 1;
        int rowH = 0;
        Iterator iterator = codepoints.iterator();
        while (iterator.hasNext()) {
            ByteBuffer pixels;
            FT_GlyphSlot slot;
            int cp3 = iterator.next();
            int index = FreeType.FT_Get_Char_Index((FT_Face)face, cp3);
            if (index == 0 || FreeType.FT_Load_Glyph((FT_Face)face, index, 4) != 0 || (slot = face.glyph()) == null) continue;
            FT_Bitmap bitmap = slot.bitmap();
            int gw = bitmap.width();
            int gh = bitmap.rows();
            float advance = class_9111.method_56146((FT_Vector)slot.advance());
            if (cp3 == 32) {
                spaceAdvance = advance;
            }
            if (gw <= 0 || gh <= 0) {
                if (!(advance > 0.0f)) continue;
                GLYPHS.put(cp3, new Glyph(0, 0, 0, 0, 0.0f, 0.0f, advance));
                continue;
            }
            if (bitmap.pixel_mode() != 2) continue;
            if (penX + gw + 1 > 1024) {
                penX = 1;
                penY += rowH + 1;
                rowH = 0;
            }
            if (penY + gh + 1 > 512 || (pixels = bitmap.buffer(gw * gh)) == null) continue;
            for (int row = 0; row < gh; ++row) {
                for (int col = 0; col < gw; ++col) {
                    int cov = pixels.get(row * gw + col) & 0xFF;
                    if (cov == 0) continue;
                    atlas.method_61941(penX + col, penY + row, cov << 24 | 0xFFFFFF);
                }
            }
            GLYPHS.put(cp3, new Glyph(penX, penY, gw, gh, slot.bitmap_left(), slot.bitmap_top(), advance));
            penX += gw + 1;
            rowH = Math.max(rowH, gh);
        }
        if (spaceAdvance <= 0.0f) {
            spaceAdvance = 5.4f;
        }
    }

    private static Glyph glyph(int cp) {
        Glyph g = GLYPHS.get(cp);
        if (g == null) {
            g = GLYPHS.get(63);
        }
        return g;
    }

    private static float advance(int cp) {
        Glyph g = UiFont.glyph(cp);
        return g == null ? spaceAdvance : g.advance();
    }

    public static int w(class_327 fallback, String text) {
        if (!UiFont.ready()) {
            return fallback.method_1727(text);
        }
        float w = 0.0f;
        int i = 0;
        while (i < text.length()) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            w += UiFont.advance(cp);
        }
        return Math.round(w * 0.5f);
    }

    private static int shadowColor(int color) {
        return (color & 0xFCFCFC) >> 2 | color & 0xFF000000;
    }

    public static void drawText(DrawContext context, class_327 fallback, String text, int x, int y, int color) {
        if (!UiFont.ready()) {
            context.method_25303(fallback, text, x, y, color);
            return;
        }
        if (text.isEmpty() || (color & 0xFF000000) == 0) {
            return;
        }
        UiFont.render(context, text, x + 1, y + 1, UiFont.shadowColor(color));
        UiFont.render(context, text, x, y, color);
    }

    public static void drawCentered(DrawContext context, class_327 fallback, String text, int centerX, int y, int color) {
        UiFont.drawText(context, fallback, text, Math.round(centerX - UiFont.w(fallback, text) / 2.0f), y, color);
    }

    public static String trim(class_327 fallback, String text, int maxW) {
        float a;
        int cp;
        if (!UiFont.ready()) {
            return fallback.method_27523(text, maxW);
        }
        float w = 0.0f;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < text.length() && !(w + (a = UiFont.advance(cp = text.codePointAt(i)) * 0.5f) > maxW); i += Character.charCount(cp)) {
            w += a;
            sb.appendCodePoint(cp);
        }
        return sb.toString();
    }

    private static void render(DrawContext context, String text, float x, float y, int color) {
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(0.5f, 0.5f);
        float pen = 0.0f;
        int i = 0;
        while (i < text.length()) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            Glyph g = UiFont.glyph(cp);
            if (g == null) {
                pen += spaceAdvance;
                continue;
            }
            if (g.w() > 0) {
                context.method_25291(RenderPipelines.field_56883, TEX, Math.round(pen + g.bearingX()), Math.round(ascent - g.top()), g.u(), g.v(), g.w(), g.h(), 1024, 512, color);
            }
            pen += g.advance();
        }
        context.getMatrices().popMatrix();
    }

    private static final class SmoothTexture
    extends class_1043 {
        SmoothTexture(class_1011 image) {
            super(() -> "makspredictions-glyphs", image);
            this.field_63613 = RenderSystem.getSamplerCache().getSampler(FilterMode.LINEAR);
        }
    }

    private record Glyph(int u, int v, int w, int h, float bearingX, float top, float advance) {
    }
}
