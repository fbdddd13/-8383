package net.maksaidev.atmosphere;

import net.minecraft.client.gui.DrawContext;

public final class UiShapes {
    private UiShapes() {
    }

    public static void fillRounded(DrawContext context, int x1, int y1, int x2, int y2, int r, int color) {
        if (color >>> 24 == 0) {
            return;
        }
        if (r <= 0) {
            context.fill(x1, y1, x2, y2, color);
            return;
        }
        r = Math.min(r, Math.min(x2 - x1, y2 - y1) / 2);
        context.fill(x1 + r, y1, x2 - r, y2, color);
        context.fill(x1, y1 + r, x1 + r, y2 - r, color);
        context.fill(x2 - r, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; ++i) {
            int inset = UiShapes.cornerInset(r, i);
            if (inset >= r) continue;
            context.fill(x1 + inset, y1 + i, x1 + r, y1 + i + 1, color);
            context.fill(x2 - r, y1 + i, x2 - inset, y1 + i + 1, color);
            context.fill(x1 + inset, y2 - i - 1, x1 + r, y2 - i, color);
            context.fill(x2 - r, y2 - i - 1, x2 - inset, y2 - i, color);
        }
    }

    public static void fillRoundedOutline(DrawContext context, int x1, int y1, int x2, int y2, int r, int border, int fill) {
        UiShapes.fillRounded(context, x1, y1, x2, y2, r, border);
        UiShapes.fillRounded(context, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(0, r - 1), fill);
    }

    private static int cornerInset(int r, int row) {
        double dy = (double)(r - row) - 0.5;
        return Math.ceil(r - Math.sqrt(Math.max(0.0, (double)(r * r) - dy * dy)));
    }

    public static int withAlpha(int color, int alpha) {
        return alpha << 24 | color & 0xFFFFFF;
    }

    public static int mulAlpha(int color, float factor) {
        int a = color >>> 24;
        return (int)(a * Math.max(0.0f, Math.min(1.0f, factor))) << 24 | color & 0xFFFFFF;
    }

    public static int lerp(int from, int to, float t) {
        if (t <= 0.0f) {
            return from;
        }
        if (t >= 1.0f) {
            return to;
        }
        int a = UiShapes.lerpChannel(from >>> 24, to >>> 24, t);
        int r = UiShapes.lerpChannel(from >> 16 & 0xFF, to >> 16 & 0xFF, t);
        int g = UiShapes.lerpChannel(from >> 8 & 0xFF, to >> 8 & 0xFF, t);
        int b = UiShapes.lerpChannel(from & 0xFF, to & 0xFF, t);
        return a << 24 | r << 16 | g << 8 | b;
    }

    private static int lerpChannel(int a, int b, float t) {
        return a + (int)((float)(b - a) * t);
    }
}
