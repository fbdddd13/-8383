package net.maksaidev.atmosphere.weather;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import net.fabricmc.loader.api.FabricLoader;
import net.maksaidev.atmosphere.weather.WeatherModule;

public final class WeatherConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("maksatmosphere-weather.json");
    private static WeatherConfig instance;
    public boolean enabled = true;
    public Mode mode = Mode.OFF;
    public int rainIntensity = 90;
    public int rainSound = 60;
    public int puddles = 75;
    public boolean splashes = true;
    public int splashDensity = 75;
    public int ringVisibility = 100;
    public boolean wetGround = false;
    public int snowDensity = 100;
    public int wind = 30;
    public boolean snowCover = true;
    public int blizzard = 65;
    public Quality quality = Quality.BALANCED;
    public int sunlight = 75;
    public int sunRays = 65;
    public int sunHeight = 35;
    public int dew = 50;
    public int dustDensity = 65;
    public int dustSize = 50;
    public int dustLight = 70;
    public int sakuraDensity = 60;
    public int sakuraSize = 50;
    public int sakuraGroundLife = 50;
    public int sakuraWind = 30;
    public int sakuraHue = 96;
    public int sakuraSaturation = 45;
    public int sakuraFlutter = 55;
    public boolean sakuraTint = true;
    public int sakuraTintStrength = 60;
    public int eclipseDarkness = 70;
    public int eclipseCorona = 75;
    public int eclipseStars = 70;
    public int eclipseDust = 45;
    public int meteorRate = 60;
    public int meteorBrightness = 80;
    public int meteorTrail = 70;
    public int meteorStars = 70;
    public int meteorDebris = 50;
    public int meteorSize = 55;
    public int meteorVariation = 75;
    public int meteorProximity = 65;
    public int meteorFog = 60;
    public int meteorFogDistance = 45;
    public int meteorSkyGlow = 65;
    public int meteorNebula = 55;
    public int bloodMoonSize = 65;
    public int bloodMoonGlow = 70;
    public int bloodSky = 75;
    public int bloodClouds = 65;
    public int bloodMist = 55;
    public int bloodGround = 45;
    public int bloodEmbers = 35;
    public int bloodHeight = 58;

    public static WeatherConfig get() {
        if (instance == null) {
            instance = WeatherConfig.load();
        }
        return instance;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static WeatherConfig load() {
        if (!Files.exists(FILE, new LinkOption[0])) {
            return new WeatherConfig();
        }
        try (BufferedReader reader = Files.newBufferedReader(FILE);){
            WeatherConfig config = (WeatherConfig)GSON.fromJson((Reader)reader, WeatherConfig.class);
            if (config == null) {
                WeatherConfig weatherConfig2 = new WeatherConfig();
                return weatherConfig2;
            }
            config.validate();
            WeatherConfig weatherConfig = config;
            return weatherConfig;
        }
        catch (Exception ex) {
            WeatherModule.LOGGER.warn("[MaksaiAtmosphere] не удалось прочитать maksatmosphere-weather.json", (Throwable)ex);
            return new WeatherConfig();
        }
    }

    public static void save() {
        WeatherConfig config = WeatherConfig.get();
        config.validate();
        try {
            Files.createDirectories(FILE.getParent(), new FileAttribute[0]);
            try (BufferedWriter writer = Files.newBufferedWriter(FILE, new OpenOption[0]);){
                GSON.toJson((Object)config, (Appendable)writer);
            }
        }
        catch (IOException ex) {
            WeatherModule.LOGGER.warn("[MaksaiAtmosphere] не удалось сохранить maksatmosphere-weather.json", (Throwable)ex);
        }
    }

    private void validate() {
        if (this.mode == null) {
            this.mode = Mode.OFF;
        }
        if (this.quality == null) {
            this.quality = Quality.BALANCED;
        }
        this.rainIntensity = WeatherConfig.clamp(this.rainIntensity);
        this.rainSound = WeatherConfig.clamp(this.rainSound);
        this.puddles = WeatherConfig.clamp(this.puddles);
        this.splashDensity = WeatherConfig.clamp(this.splashDensity);
        this.ringVisibility = WeatherConfig.clamp(this.ringVisibility);
        this.snowDensity = WeatherConfig.clamp(this.snowDensity);
        this.wind = WeatherConfig.clamp(this.wind);
        this.blizzard = WeatherConfig.clamp(this.blizzard);
        this.sunlight = WeatherConfig.clamp(this.sunlight);
        this.sunRays = WeatherConfig.clamp(this.sunRays);
        this.sunHeight = WeatherConfig.clamp(this.sunHeight);
        this.dew = WeatherConfig.clamp(this.dew);
        this.dustDensity = WeatherConfig.clamp(this.dustDensity);
        this.dustSize = WeatherConfig.clamp(this.dustSize);
        this.dustLight = WeatherConfig.clamp(this.dustLight);
        this.sakuraDensity = WeatherConfig.clamp(this.sakuraDensity);
        this.sakuraSize = WeatherConfig.clamp(this.sakuraSize);
        this.sakuraGroundLife = WeatherConfig.clamp(this.sakuraGroundLife);
        this.sakuraWind = WeatherConfig.clamp(this.sakuraWind);
        this.sakuraHue = WeatherConfig.clamp(this.sakuraHue);
        this.sakuraSaturation = WeatherConfig.clamp(this.sakuraSaturation);
        this.sakuraFlutter = WeatherConfig.clamp(this.sakuraFlutter);
        this.sakuraTintStrength = WeatherConfig.clamp(this.sakuraTintStrength);
        this.eclipseDarkness = WeatherConfig.clamp(this.eclipseDarkness);
        this.eclipseCorona = WeatherConfig.clamp(this.eclipseCorona);
        this.eclipseStars = WeatherConfig.clamp(this.eclipseStars);
        this.eclipseDust = WeatherConfig.clamp(this.eclipseDust);
        this.meteorRate = WeatherConfig.clamp(this.meteorRate);
        this.meteorBrightness = WeatherConfig.clamp(this.meteorBrightness);
        this.meteorTrail = WeatherConfig.clamp(this.meteorTrail);
        this.meteorStars = WeatherConfig.clamp(this.meteorStars);
        this.meteorDebris = WeatherConfig.clamp(this.meteorDebris);
        this.meteorSize = WeatherConfig.clamp(this.meteorSize);
        this.meteorVariation = WeatherConfig.clamp(this.meteorVariation);
        this.meteorProximity = WeatherConfig.clamp(this.meteorProximity);
        this.meteorFog = WeatherConfig.clamp(this.meteorFog);
        this.meteorFogDistance = WeatherConfig.clamp(this.meteorFogDistance);
        this.meteorSkyGlow = WeatherConfig.clamp(this.meteorSkyGlow);
        this.meteorNebula = WeatherConfig.clamp(this.meteorNebula);
        this.bloodMoonSize = WeatherConfig.clamp(this.bloodMoonSize);
        this.bloodMoonGlow = WeatherConfig.clamp(this.bloodMoonGlow);
        this.bloodSky = WeatherConfig.clamp(this.bloodSky);
        this.bloodClouds = WeatherConfig.clamp(this.bloodClouds);
        this.bloodMist = WeatherConfig.clamp(this.bloodMist);
        this.bloodGround = WeatherConfig.clamp(this.bloodGround);
        this.bloodEmbers = WeatherConfig.clamp(this.bloodEmbers);
        this.bloodHeight = WeatherConfig.clamp(this.bloodHeight);
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(100, value));
    }

    public static String modeName(Mode mode) {
        return switch (mode.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> "Выкл";
            case 1 -> "Дождь";
            case 2 -> "Зима";
            case 3 -> "Рассвет";
            case 4 -> "Пыль";
            case 5 -> "Сакура";
            case 6 -> "Затмение";
            case 7 -> "Звёздный дождь";
            case 8 -> "Кровавая луна";
        };
    }

    public static String qualityName(Quality quality) {
        return switch (quality.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> "Быстро";
            case 1 -> "Баланс";
            case 2 -> "Высокое";
        };
    }

    public static int modeColor(Mode mode) {
        return switch (mode.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> 0x808890;
            case 1 -> 7244960;
            case 2 -> 14477556;
            case 3 -> 15769680;
            case 4 -> 12623968;
            case 5 -> 15769784;
            case 6 -> 7360688;
            case 7 -> 15761456;
            case 8 -> 12593208;
        };
    }

    public static enum Mode {
        OFF,
        RAIN,
        WINTER,
        SUNRISE,
        DUST,
        SAKURA,
        ECLIPSE,
        METEOR,
        BLOOD_MOON;


        public Mode next() {
            return Mode.values()[(this.ordinal() + 1) % Mode.values().length];
        }
    }

    public static enum Quality {
        FAST,
        BALANCED,
        HIGH;


        public Quality next() {
            return Quality.values()[(this.ordinal() + 1) % Quality.values().length];
        }
    }
}
