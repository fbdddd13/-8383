package net.maksaidev.atmosphere.weather;

import net.maksaidev.atmosphere.weather.WeatherConfig;
import net.maksaidev.atmosphere.weather.WeatherModule;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.util.Identifier;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundCategory;

public final class RainSound
extends MovingSoundInstance {
    RainSound() {
        super(SoundEvent.of(Identifier.of("maksatmosphere", "rain_continuous")), SoundCategory.AMBIENT, SoundManager.getCategory());
        this.repeat = true;
        this.repeatDelay = 0;
        this.volume = 0.01f;
        this.attenuationType = true;
    }

    public void stopSound() {
        this.stopSound();
    }

    public void tick() {
        WeatherConfig config = WeatherModule.config();
        if (config != null && config.enabled && config.mode == WeatherConfig.Mode.RAIN) {
            float target = config.rainSound / 100.0f * (config.rainIntensity / 100.0f);
            this.volume = Math.max(0.001f, target);
        } else {
            this.stopSound();
        }
    }
}
