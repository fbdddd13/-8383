package net.maksaidev.atmosphere.weather;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Map;
import net.maksaidev.atmosphere.weather.WeatherConfig;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.client.world.ClientLevel;
import org.lwjgl.system.MemoryUtil;

final class PrecipitationMesh
implements AutoCloseable {
    private static final int BUFFER_BYTES = 8000000;
    private static final int VERTEX_BYTES = 24;
    private static final long REFRESH_NS = 3000000000L;
    private static final float[][] CORNERS = new float[][]{{0.0f, 0.0f}, {0.0f, 1.0f}, {1.0f, 1.0f}, {0.0f, 0.0f}, {1.0f, 1.0f}, {1.0f, 0.0f}};
    private GpuBuffer buffer;
    private int vertexCount;
    private int originX;
    private int originZ;
    private int lastRadius;
    private long nextRefresh;
    private ClientLevel lastWorld;
    private WeatherConfig.Mode lastMode;
    private WeatherConfig.Quality lastQuality;
    private int lastDensity = -1;
    private int cameraY;
    private final Map<Long, int[]> cavities = new HashMap<Long, int[]>();
    private final BlockPos.BlockPos.Mutable probe = new BlockPos.BlockPos.Mutable();
    private final ByteBuffer bytes = MemoryUtil.memAlloc(8000000).order(ByteOrder.nativeOrder());

    PrecipitationMesh() {
    }

    void update(ClientLevel world, Vec3d camera, int radius, WeatherConfig config) {
        int density;
        WeatherConfig.Mode mode = config.mode;
        mode = = WeatherConfig.Mode.DUST || mode == WeatherConfig.Mode.SUNRISE || mode == WeatherConfig.Mode.ECLIPSE || mode == WeatherConfig.Mode.METEOR || mode == WeatherConfig.Mode.BLOOD_MOON;
        mode = = WeatherConfig.Mode.SAKURA;
        switch (mode) {
            case SAKURA: {
                int n = config.sakuraDensity;
                break;
            }
            case WINTER: {
                int n = config.snowDensity;
                break;
            }
            case DUST: {
                int n = config.dustDensity;
                break;
            }
            case SUNRISE: {
                int n = config.dew;
                break;
            }
            case ECLIPSE: {
                int n = config.eclipseDust;
                break;
            }
            case METEOR: {
                int n = Math.max(config.meteorRate, config.meteorDebris);
                break;
            }
            case BLOOD_MOON: {
                int n = config.bloodEmbers;
                break;
            }
            default: {
                int n = density = config.rainIntensity;
            }
        }
        if (mode == WeatherConfig.Mode.OFF || density == 0) {
            this.vertexCount = 0;
            this.lastDensity = -1;
            return;
        }
        if (motes) {
            radius = Math.min(radius, 64);
        }
        if (sakura) {
            radius = Math.min(radius, 80);
        }
        int ox = Math.floorDiv(Math.floor(camera.x), 16) * 16;
        int oz = Math.floorDiv(Math.floor(camera.z), 16) * 16;
        long now = System.nanoTime();
        if (this.buffer == null || world != this.lastWorld || mode != this.lastMode || ox != this.originX || oz != this.originZ || this.cameraY != Math.floor(camera.y) || radius != this.lastRadius || this.lastQuality != config.quality || this.lastDensity != density || now >= this.nextRefresh) {
            this.cameraY = Math.floor(camera.y);
            this.cavities.clear();
            this.originX = ox;
            this.originZ = oz;
            this.lastRadius = radius;
            this.lastWorld = world;
            this.lastMode = mode;
            this.lastQuality = config.quality;
            this.lastDensity = density;
            this.nextRefresh = now + 3000000000L;
            this.bytes.clear();
            mode = = WeatherConfig.Mode.WINTER;
            int quality = config.quality.ordinal();
            this.addBand(this.bytes, world, mode, 0, Math.min(32, radius), 2, sakura ? 9 + quality * 4 : (motes ? 10 + quality * 3 : (snow ? 14 + quality * 4 : 6 + quality * 2)));
            if (radius > 32) {
                this.addBand(this.bytes, world, mode, 32, Math.min(96, radius), 6, sakura ? 3 + quality : (motes ? 3 : (snow ? 8 + quality * 2 : 4 + quality)));
            }
            int farStep = Math.max(16, Math.ceil(radius / 24.0));
            if (radius > 96) {
                this.addBand(this.bytes, world, mode, 96, radius, farStep, snow ? 6 : 4);
            }
            this.bytes.flip();
            this.vertexCount = this.bytes.remaining() / 24;
            if (this.buffer == null) {
                this.buffer = RenderSystem.getDevice().createBuffer(() -> "MaksaiAtmosphere drop seeds", 40, this.bytes.capacity());
            }
            if (this.vertexCount > 0) {
                RenderSystem.getDevice().createCommandEncoder().writeToBuffer(this.buffer.slice(0L, this.bytes.remaining()), this.bytes);
            }
        }
    }

    private void addBand(ByteBuffer out, ClientLevel world, WeatherConfig.Mode mode, int inner, int outer, int step, int layers) {
        Heightmap.Heightmap.Type heightmap = mode == WeatherConfig.Mode.WINTER ? Heightmap.Heightmap.Type.WORLD_SURFACE : Heightmap.Heightmap.Type.WORLD_SURFACE;
        int sx = Math.floorDiv(this.originX - outer, step) * step;
        int sz = Math.floorDiv(this.originZ - outer, step) * step;
        for (int x = sx; x < this.originX + outer; x += step) {
            for (int z = sz; z < this.originZ + outer; z += step) {
                int dx = x - this.originX;
                int dz = z - this.originZ;
                int distance = dx * dx + dz * dz;
                if (distance < inner * inner || distance > outer * outer || !world.isChunkLoaded(x >> 4, z >> 4)) continue;
                for (int layer = 0; layer < layers; ++layer) {
                    if (out.remaining() < 144) {
                        return;
                    }
                    int hash = PrecipitationMesh.hash(x, z, layer);
                    int densitySeed = PrecipitationMesh.hash(x + 37, z - 61, layer + 19) & 0xFF;
                    if (densitySeed / 255.0f > this.lastDensity / 100.0f) continue;
                    float px = x + (float)(hash & 0xFF) / 255.0f * step;
                    float pz = z + (float)(hash >>> 8 & 0xFF) / 255.0f * step;
                    int ground = world.getTopY(heightmap, Math.floor(px), Math.floor(pz));
                    int ceiling = ground + 96;
                    if (ground > this.cameraY) {
                        int bz;
                        int bx = Math.floor(px);
                        long key = bx << 32 ^ (long)(bz = Math.floor(pz)) & 0xFFFFFFFFL;
                        int[] cavity = this.cavities.get(key);
                        if (cavity == null) {
                            int floor = world.getBottomY();
                            int roof = ground;
                            if (!world.getBlockState((BlockPos)this.probe.set(bx, this.cameraY, bz)).isAir()) {
                                cavity = new int[]{this.cameraY, this.cameraY};
                            } else {
                                for (int y = this.cameraY - 1; y >= floor; --y) {
                                    if (world.getBlockState((BlockPos)this.probe.set(bx, y, bz)).isAir()) continue;
                                    floor = y + 1;
                                    break;
                                }
                                for (int yx = this.cameraY + 1; yx <= roof; ++yx) {
                                    if (world.getBlockState((BlockPos)this.probe.set(bx, yx, bz)).isAir()) continue;
                                    roof = yx;
                                    break;
                                }
                                cavity = new int[]{floor, roof};
                            }
                            this.cavities.put(key, cavity);
                        }
                        if ((ceiling = cavity[1]) <= (ground = cavity[0])) continue;
                    }
                    for (float[] corner : CORNERS) {
                        out.putFloat(px - this.originX).putFloat(ground).putFloat(pz - this.originZ);
                        out.putFloat(ceiling * 2.0f + corner[0]).putFloat(corner[1]);
                        out.put((byte)(hash >>> 16)).put((byte)(hash >>> 24)).put(PrecipitationMesh.hash(x + 37, z - 61, layer + 19)).put((byte)-1);
                    }
                    if (mode != WeatherConfig.Mode.RAIN || layer >= (inner == 0 ? 2 : 1) || inner >= 96) continue;
                    for (int jet = 0; jet < 3 && out.remaining() >= 144; ++jet) {
                        for (float[] corner : CORNERS) {
                            out.putFloat(px - this.originX).putFloat(ground).putFloat(pz - this.originZ);
                            out.putFloat(ceiling * 2.0f + corner[0]).putFloat(corner[1]);
                            out.put((byte)(hash >>> 16)).put((byte)(hash >>> 24)).put(hash).put((byte)(jet * 32));
                        }
                    }
                }
            }
        }
    }

    private static int hash(int x, int z, int layer) {
        int n = x * 374761393 + z * 668265263 + layer * 1274126177;
        n = (n ^ n >>> 13) * 1274126177;
        return n ^ n >>> 16;
    }

    GpuBuffer buffer() {
        return this.buffer;
    }

    int vertexCount() {
        return this.vertexCount;
    }

    int originX() {
        return this.originX;
    }

    int originZ() {
        return this.originZ;
    }

    @Override
    public void close() {
        if (this.buffer != null) {
            this.buffer.close();
            this.buffer = null;
        }
        MemoryUtil.memFree((Buffer)this.bytes);
    }
}
