package net.maksaidev.atmosphere.weather;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.maksaidev.atmosphere.weather.RainSound;
import net.maksaidev.atmosphere.weather.WeatherConfig;
import net.maksaidev.atmosphere.weather.WeatherRenderer;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class WeatherModule {
    public static final Logger LOGGER = LoggerFactory.getLogger("maksatmosphere");
    private static final WeatherRenderer RENDERER = new WeatherRenderer();
    private static WeatherConfig config;
    private static RainSound sound;
    private static boolean wasWinter;

    private WeatherModule() {
    }

    public static void init() {
        config = WeatherConfig.get();
        WorldRenderEvents.BEFORE_ENTITIES.register(RENDERER::captureTerrain);
        WorldRenderEvents.END_MAIN.register(RENDERER::render);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> RENDERER.close());
    }

    public static WeatherConfig config() {
        return WeatherConfig.get();
    }

    public static void tick(MinecraftClient client) {
        boolean rain;
        boolean winter;
        WeatherConfig c = WeatherModule.config();
        winter = c.enabled && c.mode == WeatherConfig.Mode.WINTER;
        if (winter && !wasWinter) {
            for (Identifier id : client.getSoundManager().getSoundIds()) {
                if (!WeatherModule.muteWinterAmbience(id)) continue;
                client.getSoundManager().stop(id, null);
            }
        }
        wasWinter = winter;
        rain = client.world != null && client.player != null && c.enabled && c.mode == WeatherConfig.Mode.RAIN && c.rainIntensity > 0 && c.rainSound > 0;
        if (rain) {
            if (sound == null || sound.isDone() || !client.getSoundManager().isPlaying((SoundManager)sound)) {
                sound = new RainSound();
                client.getSoundManager().play((SoundManager)sound);
            }
        } else if (sound != null) {
            sound.stopSound();
            sound = null;
        }
    }

    public static boolean muteWinterAmbience(Identifier id) {
        WeatherConfig c = config;
        if (c == null || !c.enabled || c.mode != WeatherConfig.Mode.WINTER) {
            return false;
        }
        String path = id.getPath();
        return id.getNamespace().equals("minecraft") && (path.equals("ambient.cave") || path.startsWith("ambient.nether_wastes.") || path.startsWith("ambient.soul_sand_valley.") || path.startsWith("ambient.crimson_forest.") || path.startsWith("ambient.warped_forest.") || path.startsWith("ambient.basalt_deltas.") || path.startsWith("music.nether."));
    }
}
