package net.maksaidev.atmosphere.weather;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.lang.reflect.Method;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.maksaidev.atmosphere.weather.PrecipitationMesh;
import net.maksaidev.atmosphere.weather.WeatherConfig;
import net.maksaidev.atmosphere.weather.WeatherModule;
import net.minecraft.Uniforms;
import net.minecraft.RenderPipelines;
import net.minecraft.GpuSampler;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.SimpleFramebuffer;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.lwjgl.system.MemoryUtil;

public final class WeatherRenderer
implements AutoCloseable {
    private static final RenderPipeline MATERIALS = WeatherRenderer.build(true);
    private static final RenderPipeline PRECIPITATION = WeatherRenderer.build(false);
    private SimpleFramebuffer scene;
    private SimpleFramebuffer terrain;
    private GpuBuffer uniforms;
    private GpuBuffer triangle;
    private final PrecipitationMesh mesh = new PrecipitationMesh();
    private final ByteBuffer data = MemoryUtil.memAlloc(512).order(ByteOrder.nativeOrder());
    private final Matrix4f inverseProjection = new Matrix4f();
    private final Matrix4f inverseView = new Matrix4f();
    private final long start = System.nanoTime();
    private boolean captured;

    private static RenderPipeline build(boolean materials) {
        RenderPipeline.Builder builder = RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(Identifier.of("maksatmosphere", (materials ? "weather_materials" : "weather_precipitation"))).withVertexShader(Identifier.of("maksatmosphere", (materials ? "weather/fullscreen" : "weather/precipitation"))).withFragmentShader(Identifier.of("maksatmosphere", (materials ? "weather/materials" : "weather/precipitation"))).withUniform("Weather", Uniforms.WEATHER).withDepthWrite(false).withCull(false);
        if (materials) {
            builder.withSampler("SceneColor").withSampler("SceneDepth").withSampler("TerrainDepth").withVertexFormat(VertexFormats.POSITION_COLOR_TEXTURE, VertexFormat.class_5596.QUADS).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST);
        } else {
            builder.withVertexFormat(VertexFormats.POSITION_TEXTURE, VertexFormat.class_5596.QUADS).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withBlend(BlendFunction.TRANSLUCENT);
        }
        return WeatherRenderer.register(builder.build());
    }

    private static RenderPipeline register(RenderPipeline pipeline) {
        for (String name : new String[]{"register", "method_67887"}) {
            try {
                Method m = RenderPipelines.class.getDeclaredMethod(name, RenderPipeline.class);
                m.setAccessible(true);
                return (RenderPipeline)m.invoke(null, pipeline);
            }
            catch (Throwable throwable) {
            }
        }
        return pipeline;
    }

    private static boolean active() {
        WeatherConfig c = WeatherModule.config();
        return c != null && c.enabled && (c.mode != WeatherConfig.Mode.OFF || c.wetGround);
    }

    private static boolean materialsNeeded() {
        WeatherConfig c = WeatherModule.config();
        if (c == null || !c.enabled) {
            return false;
        }
        return switch (c.mode) {
            default -> throw new MatchException(null, null);
            case WeatherConfig.Mode.OFF -> c.wetGround;
            case WeatherConfig.Mode.RAIN, WeatherConfig.Mode.WINTER, WeatherConfig.Mode.SUNRISE, WeatherConfig.Mode.DUST -> true;
            case WeatherConfig.Mode.SAKURA -> {
                if (c.sakuraTint && c.sakuraTintStrength > 0) {
                    yield true;
                }
                yield false;
            }
            case WeatherConfig.Mode.ECLIPSE, WeatherConfig.Mode.METEOR, WeatherConfig.Mode.BLOOD_MOON -> true;
        };
    }

    public void captureTerrain(WorldRenderContext context) {
        this.captured = false;
        if (WeatherRenderer.active()) {
            Framebuffer target = MinecraftClient.getInstance().getFramebuffer();
            this.ensureTargets(target);
            if (WeatherRenderer.materialsNeeded()) {
                this.terrain.beginWrite(target);
            }
            this.captured = true;
        }
    }

    private void ensureTargets(Framebuffer target) {
        if (this.scene == null) {
            this.scene = new SimpleFramebuffer("MaksaiAtmosphere weather scene", target.width, target.height, true);
            this.terrain = new SimpleFramebuffer("MaksaiAtmosphere weather terrain mask", target.width, target.height, true);
        } else if (this.scene.width != target.width || this.scene.height != target.height) {
            this.scene.resize(target.width, target.height);
            this.terrain.resize(target.width, target.height);
        }
        if (this.uniforms == null) {
            this.uniforms = RenderSystem.getDevice().createBuffer(() -> "MaksaiAtmosphere weather uniforms", 136, 512L);
            ByteBuffer vertices = MemoryUtil.memAlloc(36).order(ByteOrder.nativeOrder());
            vertices.putFloat(-1.0f).putFloat(-1.0f).putFloat(0.0f);
            vertices.putFloat(3.0f).putFloat(-1.0f).putFloat(0.0f);
            vertices.putFloat(-1.0f).putFloat(3.0f).putFloat(0.0f).flip();
            this.triangle = RenderSystem.getDevice().createBuffer(() -> "MaksaiAtmosphere fullscreen triangle", 32, vertices);
            MemoryUtil.memFree((Buffer)vertices);
        }
    }

    public void render(WorldRenderContext context) {
        RenderPass pass;
        if (!WeatherRenderer.active() || !this.captured) {
            return;
        }
        this.captured = false;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }
        Framebuffer target = client.getFramebuffer();
        WeatherConfig c = WeatherModule.config();
        Camera camera = client.gameRenderer.getCamera();
        Vec3d cameraPos = context.worldState() != null && context.worldState().camera != null && context.worldState().camera.pos != null ? context.worldState().camera.pos : camera.getPos();
        int radius = client.options.getViewDistance() * 16;
        this.mesh.update(client.world, cameraPos, radius, c);
        this.data.clear();
        float fov = (client.options.getFov().getValue()).intValue();
        Matrix4f projectionMatrix = client.gameRenderer.getProjectionMatrix(fov);
        Quaternionf rotation = camera.getRotation().conjugate(new Quaternionf());
        Matrix4f positionMatrix = new Matrix4f().rotation((Quaternionfc)rotation);
        projectionMatrix.get(0, this.data);
        this.inverseProjection.set((Matrix4fc)projectionMatrix).invert().get(64, this.data);
        positionMatrix.get(128, this.data);
        this.inverseView.set((Matrix4fc)positionMatrix).invert().get(192, this.data);
        this.data.position(256);
        this.data.putFloat(cameraPos.x).putFloat(cameraPos.y).putFloat(cameraPos.z).putFloat((float)(System.nanoTime() - this.start) / 1.0E9f);
        this.data.putFloat(c.mode == WeatherConfig.Mode.RAIN ? c.rainIntensity / 100.0f : 0.0f).putFloat(c.mode == WeatherConfig.Mode.WINTER && c.snowCover ? 1.0f : 0.0f).putFloat((c.mode == WeatherConfig.Mode.OFF || c.mode == WeatherConfig.Mode.RAIN) && c.wetGround ? 1.0f : 0.0f).putFloat(c.puddles / 100.0f);
        this.data.putFloat(target.width).putFloat(target.height).putFloat(c.splashes ? 1.0f : 0.0f).putFloat(c.wind / 100.0f);
        float sunAngle = context.worldState() != null && context.worldState().sun != null ? context.worldState().sun.angle : (float)((double)(client.world.getTimeOfDay() % 24000L) / 24000.0);
        float daylight = Math.max(0.08, Math.min(1.0, Math.cos(sunAngle * Math.PI * 2.0) * 1.5 + 0.25));
        this.data.putFloat(daylight).putFloat(radius).putFloat(c.snowDensity / 100.0f).putFloat(c.mode.ordinal());
        this.data.putFloat(this.mesh.originX()).putFloat(0.0f).putFloat(this.mesh.originZ()).putFloat(0.0f);
        this.data.putFloat(c.quality.ordinal()).putFloat(c.mode == WeatherConfig.Mode.WINTER ? c.blizzard / 100.0f : 0.0f).putFloat(c.splashes ? c.splashDensity / 100.0f : 0.0f).putFloat(c.ringVisibility / 100.0f);
        this.data.putFloat(c.sunlight / 100.0f).putFloat(c.sunRays / 100.0f).putFloat(c.dew / 100.0f).putFloat(c.dustDensity / 100.0f);
        this.data.putFloat(c.dustLight / 100.0f).putFloat(0.0f).putFloat(c.sunHeight / 100.0f).putFloat(c.dustSize / 100.0f);
        this.data.putFloat(c.sakuraDensity / 100.0f).putFloat(c.sakuraSize / 100.0f).putFloat(c.sakuraGroundLife * 0.3f).putFloat(c.sakuraWind / 100.0f);
        this.data.putFloat(c.sakuraHue / 100.0f).putFloat(c.sakuraSaturation / 100.0f).putFloat(c.sakuraTint ? c.sakuraTintStrength / 100.0f : 0.0f).putFloat(c.sakuraFlutter / 100.0f);
        this.data.putFloat(c.eclipseDarkness / 100.0f).putFloat(c.eclipseCorona / 100.0f).putFloat(c.eclipseStars / 100.0f).putFloat(c.eclipseDust / 100.0f);
        this.data.putFloat(c.meteorRate / 100.0f).putFloat(c.meteorBrightness / 100.0f).putFloat(c.meteorTrail / 100.0f).putFloat(c.meteorStars / 100.0f);
        this.data.putFloat(c.meteorDebris / 100.0f).putFloat(c.meteorSize / 100.0f).putFloat(c.meteorVariation / 100.0f).putFloat(c.meteorProximity / 100.0f);
        this.data.putFloat(c.bloodMoonSize / 100.0f).putFloat(c.bloodMoonGlow / 100.0f).putFloat(c.bloodSky / 100.0f).putFloat(c.bloodClouds / 100.0f);
        this.data.putFloat(c.bloodMist / 100.0f).putFloat(c.bloodGround / 100.0f).putFloat(c.bloodEmbers / 100.0f).putFloat(c.bloodHeight / 100.0f);
        this.data.putFloat(c.meteorFog / 100.0f).putFloat(c.meteorFogDistance / 100.0f).putFloat(c.meteorSkyGlow / 100.0f).putFloat(c.meteorNebula / 100.0f).flip();
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        encoder.writeToBuffer(this.uniforms.slice(), this.data);
        if (WeatherRenderer.materialsNeeded()) {
            encoder.copyTextureToTexture(target.getColorAttachment(), this.scene.getColorAttachment(), 0, 0, 0, 0, 0, target.width, target.height);
            this.scene.beginWrite(target);
            pass = encoder.createRenderPass(() -> "MaksaiAtmosphere weather materials and reflections", target.getColorAttachment(), OptionalInt.empty());
            try {
                pass.setPipeline(MATERIALS);
                pass.setUniform("Weather", this.uniforms);
                GpuSampler sampler = RenderSystem.getSamplerCache().getSampler(FilterMode.NEAREST);
                pass.bindTexture("SceneColor", this.scene.getColorAttachment(), sampler);
                pass.bindTexture("SceneDepth", this.scene.getDepthAttachment(), sampler);
                pass.bindTexture("TerrainDepth", this.terrain.getDepthAttachment(), sampler);
                pass.setVertexBuffer(0, this.triangle);
                pass.draw(0, 3);
            }
            finally {
                if (pass != null) {
                    pass.close();
                }
            }
        }
        if (this.mesh.buffer() != null && this.mesh.vertexCount() > 0 && c.mode != WeatherConfig.Mode.OFF) {
            pass = encoder.createRenderPass(() -> "MaksaiAtmosphere physical precipitation", target.getColorAttachment(), OptionalInt.empty(), target.getDepthAttachment(), OptionalDouble.empty());
            try {
                pass.setPipeline(PRECIPITATION);
                pass.setUniform("Weather", this.uniforms);
                pass.setVertexBuffer(0, this.mesh.buffer());
                pass.draw(0, this.mesh.vertexCount());
            }
            finally {
                if (pass != null) {
                    pass.close();
                }
            }
        }
    }

    @Override
    public void close() {
        this.mesh.close();
        if (this.uniforms != null) {
            this.uniforms.close();
            this.uniforms = null;
        }
        if (this.triangle != null) {
            this.triangle.close();
            this.triangle = null;
        }
        if (this.scene != null) {
            this.scene.delete();
            this.scene = null;
        }
        if (this.terrain != null) {
            this.terrain.delete();
            this.terrain = null;
        }
        MemoryUtil.memFree((Buffer)this.data);
    }
}
